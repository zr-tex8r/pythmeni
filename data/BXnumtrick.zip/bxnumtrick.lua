--
-- bxnumtrick.lua
--
bxnumtrick = {}
local p = bxnumtrick

local tok_escape = token.create("bxnt@escape")
local tok_num = token.create("bxnt@num")
local c_id_assign_int = token.command_id("assign_int")
local c_id_char_given = token.command_id("char_given")

local function dump_tok(t)
  print("<"..token.command_name(t)..":"..t[1].."/"..t[2].."/"..t[3]..">")
end

local function error_scan()
  tex.error("Missing number of a permitted form, treated as zero",
            { "A number should have been here; I inserted `0'." })
end

local function get_expd_next()
  local next = token.get_next()
  while token.is_expandable(next) do
    token.expand(next)
    next = token.get_next()
  end
  return next
end

local function grab_decimal(next, res)
  table.insert(res, next)
  while true do
    next = get_expd_next()
    if not (next[1] == 12 and 0x30 <= next[2] and next[2] <= 0x39) then
      break
    end
    table.insert(res, next)
  end
  if next[1] == 10 then next = nil end
  return true, next
end

local function grab_hexa(next, res)
  local ok = false
  table.insert(res, next)
  while true do
    next = get_expd_next()
    if not ((next[1] == 12 and (0x30 <= next[2] and next[2] <= 0x39)) or
            ((next[1] == 12 or next[1] == 11) and
             (0x41 <= next[2] and next[2] <= 0x46))) then
      break
    end
    ok = true
    table.insert(res, next)
  end
  if next[1] == 10 then next = nil end
  return ok, next
end

local function grab_octal(next, res)
  local ok = false
  table.insert(res, next)
  while true do
    next = get_expd_next()
    if not (next[1] == 12 and (0x30 <= next[2] and next[2] <= 0x37)) then
      break
    end
    ok = true
    table.insert(res, next)
  end
  if next[1] == 10 then next = nil end
  return ok, next
end

local function scan_with(delay, scanner)
  local function proc()
    if delay ~= 0 then
      if delay > 0 then delay = delay - 1 end
      return token.get_next()
    else
      local cont, back = scanner()
      if not cont then
        assert(callback.register("token_filter", nil))
      end
      return back
    end
  end
  assert(callback.register("token_filter", proc))
end

function p.brace()
  scan_with(1, function()
    local next = token.get_next()
    if next[1] == 1 then
      return false, { tok_escape, next }
    elseif next[1] == 10 then
      return true, { next }
    else
      return false, { next }
    end
  end)
end

function p.number()
  scan_with(1, function()
    local next = get_expd_next()
    local res, ok = { tok_num }, false
    while true do
      if next[1] == 12 and (next[2] == 0x2B or next[2] == 0x2D) then
        table.insert(res, next)
      elseif next[1] ~= 10 then
        break
      end
      next = get_expd_next()
    end
    if next[1] == 12 and 0x30 <= next[2] and next[2] <= 0x39 then
      ok, next = grab_decimal(next, res)
    elseif next[1] == 12 and next[2] == 0x22 then
      ok, next = grab_hexa(next, res)
    elseif next[1] == 12 and next[2] == 0x27 then
      ok, next = grab_octal(next, res)
    elseif next[1] == 12 and next[2] == 0x60 then
      ok, next = grab_charnum(next, res)
    elseif next[1] == c_id_assign_int or next[1] == c_id_char_given then
      table.insert(res, next)
      ok, next = true, nil
    end
    if ok then
       table.insert(res, tok_num)
    else
       error_scan()
       res = { tok_escape }
    end
     if next then table.insert(res, next) end
     return false, res
  end)
end

-- EOF
