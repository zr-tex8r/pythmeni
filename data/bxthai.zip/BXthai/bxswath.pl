#!/usr/local/bin/perl
# bxswath.pl
#
use strict;
use Encode qw(encode decode);
my $prog_name = "bxswath";
my $version = "0.1";
my $mod_date = "2008/03/28";
# customizable settings
my $tempbase = "__${prog_name}_$$";  # temporary base name
my $swath = "swath";                 # swath command name
my $swath_opt = "-f latex";          # swath options (but -d)
my $swath_dd = undef;                # swath data dir
# 
my ($sw_win, $sw_enc, $rx_split);

sub main {
  my ($txt, $txt1, $cnkn); local ($_, $/);
  read_option();
  #
  $txt = <STDIN>;
  if ($sw_enc == 2) { # --tis
    $txt = tex_escape(exec_swath($txt));
  } else {
    $txt = decode('utf8', $txt); $txt =~ s/^\x{FEFF}//;
    ($txt1, $cnkn) = split_text($txt);
    $txt1 = exec_swath(encode('TIS620', $txt1));
    if ($sw_enc == 1) { $txt1 = tex_escape($txt1); }
    else { $txt1 = decode('TIS620', $txt1); }
    $txt = encode('utf8', join_text($txt1, $cnkn));
  }
  print($txt);
}

sub show_usage {
  print <<"END"; exit;
$prog_name ver.$version [$mod_date]
Usage: $prog_name [-t/--tis|-u/--unicode|--unitotis]
  --unicode (-u)  input UTF-8 / output UTF-8 (default)
  --tis (-t)      input TIS-620 / output TeX-escsped TIS-620
  --unitotis      input UTF-8 / output TeX-escsped TIS-620
END
}

sub read_option {
  my ($t, @a, $opt, $rx_path, $xnam, $xdir);
  # read options
  $sw_enc = 0;
  while ($ARGV[0] =~ /^-/) {
    $opt = shift(@ARGV);
    if ($opt =~ /^--?h(?:elp)?$/) {
      show_usage();
    } elsif ($opt eq "-u" || $opt eq "--unicode") {
      $sw_enc = 0;
    } elsif ($opt eq "--unitotis") {
      $sw_enc = 1;
    } elsif ($opt eq "-t" || $opt eq "--tis") {
      $sw_enc = 2;
    } elsif ($opt eq "--win") {
      $sw_win = 1;
    } elsif ($opt eq "--no-win") {
      $sw_win = 0;
    } else { error("invalid option: $opt"); }
  }
  (!@ARGV) or error("this program is used as filter");
  # check if I'm on Windows
  if (!defined $sw_win) {
    $sw_win = ($^O eq 'MSWin32') ? 1 : 0;
  }
  if ($sw_win) { $rx_path = qr/;/; $xnam = "swath.exe"; }
  else         { $rx_path = qr/:/; $xnam = "swath"; }
  # set $swath_dd properly
  if (-d $ENV{WORDSEGDATA}) {
    undef $swath_dd;
  } elsif (defined $swath_dd) { # nop
    (-d $swath_dd)
      or error("directory not found", $swath_dd);
  } else {
    $t = $ENV{PATH}; @a = map { upath($_) } (split($rx_path, $t));
    foreach $t (@a) {
      if (-x "$t/$xnam") { $xdir = $t; last; }
    }
    (defined $xdir)
      or error("directory not found", $swath_dd);
    if (-d ($swath_dd = "$xdir/swathdata")) { }
    elsif (-d ($swath_dd = "$xdir/data")) { }
  }
  if (defined $swath_dd) { $swath_opt .= " -d $swath_dd"; }
  # set splitter regex
  set_rx_split();
}

sub split_text {
  my ($txt) = @_; my ($txt1, @cnkt, @cnkn);
  $txt = "A${txt}B"; 
  while ($txt =~ m/$rx_split/g) {
    if (defined $1) { push(@cnkt, $1); }
    else { push(@cnkn, $2); }
  }
  $txt1 = join("~", @cnkt);
  (($txt1 =~ s/^A(.*)B$/$1/s) && ($#cnkt - $#cnkn == 1))
    or error("assertion failed (1)", $#cnkt, $#cnkn);
  return ($txt1, \@cnkn);
}

sub join_text {
  my ($txt, $cnkn) = @_; my (@cnkt, @cnka);
  @cnkt = split(m/\~/, $txt);
  @cnka = map { $cnkt[$_], $cnkn->[$_] } (0 .. $#cnkt);
  return join('', @cnka);
}

sub exec_swath {
  my ($txt) = @_; my ($htmp); local ($/);
  open($htmp, '>', "$tempbase.in")
    or error("failed to create temporary file", "$tempbase.in");
  print $htmp ($txt); close($htmp);
  system("$swath $swath_opt < $tempbase.in > $tempbase.out");
  open($htmp, '<', "$tempbase.out")
    or error("failed to open temporary file", "$tempbase.out");
  $txt = <$htmp>; close($htmp);
  unlink("$tempbase.in", "$tempbase.out");
  ($txt ne "") or error("failed in swath process");
  return $txt;
}

sub set_rx_split {
  my ($t);
  $t = join('', map { chr($_) }  # ~(0x7e) has special meaning
                    (0x01 .. 0x7d, 0xa1 .. 0xda, 0xdf .. 0xfb));
  $t = decode("TIS620", $t); $t = "([\Q$t\E]+)|([^\Q$t\E]+)";
  $rx_split = qr/$t/;
}

sub tex_escape {
  local ($_) = @_;
  s/([\x80-\xff])/sprintf("^^%02x", ord($1))/ge;
  return $_;
}

sub upath {
  local ($_) = @_;
  if (!$sw_win) { return $_; }
  $_ = decode('cp932', $_); s|\\|/|g; $_ = encode('cp932', $_);
  return $_;
}

sub error {
  print STDERR (join(": ", $prog_name, @_), "\n");
  exit(-1);
}

#### go to main
main();
# EOF
