@echo off
xelatex --no-pdf yato.tex
xelatex --no-pdf yato.tex
xdvipdfmx -o yato-texconf10.pdf yato.xdv
for %%x in (aux log nav out snm toc vrb xdv) do (
  if exist yato.%%x del yato.%%x
)
