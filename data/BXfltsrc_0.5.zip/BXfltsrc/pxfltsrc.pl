#!/usr/bin/perl
# pxfltsrc.pl
#
use strict;
use Encode qw(encode decode);
my $prog_name = 'pxfltsrc';
my $version = '0.5';
my $mod_date = '2011/03/01';
#### USER SETTINGS
# ALLOW_EXT_FILTER: Whether or not the invocation of external filters
#   (which is innately insecure) is allowed; valid values are: 'yes',
#   'no', and 'auto'. The value 'auto' means that external filters
#   are allowed unless the web2c parameter 'PXFLTSRC_NO_EXT_FILTER'
#   (set either in texmf.cnf or as environment variable) is set to
#   some non-empty value.
use constant ALLOW_EXT_FILTER => 'auto';

#### globals
my $tempbase = '_pxfl_';
#
my ($mode, $ansfile, $hanswer);
my (%dict, %dictaj, %xcode, @conv, $rxtarget, $rxtgtaj, $rxtgtajx);
my ($swlax, $swuseux, $swuseaj, $swuseajx);
my ($swbx, $swextfilt);
my $BC1 = "\x{FDD1}"; # a not-a-char used as flag
my $BC2 = "\x{FDD2}"; # a not-a-char used as flag
use constant {
  EUC => 0, SJIS => 1, CP932 => 2, JIS => 3, UTF8 => 4, 
  THRU => 5, BYTE => 6, AUTO => 7,
};
my @encname = (
  'eucjp', 'shiftjis', 'cp932', 'iso-2022-jp', 'utf-8',
);
my %partable = (
  ultn1   => ['u', 0],
  ugrek   => ['u', 1],
  cgrek   => ['c', 1],
  ucyrl   => ['u', 2],
  ccyrl   => ['c', 2],
  upnct   => ['u', 3],
  umsym   => ['u', 4],
  uxsym   => ['u', 5],
  uhwka   => ['u', 6],
  chwka   => ['c', 6],
  ukanji  => ['u', 7],
  ufull   => ['u', 8],
  cxkana  => ['c', 10],
  jis     => ['i', JIS],
  sjis    => ['i', SJIS],
  euc     => ['i', EUC],
  utf8    => ['i', UTF8],
  winj    => ['i', CP932],
  byte    => ['i', BYTE],
  thru    => ['i', THRU],
  inauto  => ['i', AUTO],
  outjis  => ['o', JIS],
  outsjis => ['o', SJIS],
  outeuc  => ['o', EUC],
  oututf8 => ['o', UTF8],
  lax     => ['s', \$swlax],
  useux   => ['s', \$swuseux],
  useaj   => ['s', \$swuseaj],
  useajx  => ['s', \$swuseajx],
);
# 
my @checkdbc = (
  qr/^[\x8e\xa1-\xfe][\xa1-\xfe]/,                #EUC
  qr/^[\x81-\x9f\xe0-\xfc][\x40-\x7e\x80-\xfc]/,  #SJIS
  qr/^[\x81-\x9f\xe0-\xfc][\x40-\x7e\x80-\xfc]/,  #CP932
);
my @range = (
  [ 0x0080, 0x00FF ],  # 0: ltn1: Latin-1 Supplement
  [ 0x0370, 0x03FF ],  # 1: grek: Greek and Coptic
  [ 0x0400, 0x04FF ],  # 2: cyrl: Cyrillic
  [ 0x2000, 0x206F ],  # 3: pnct: General Punctuation
  [ 0x2190, 0x23FF ],  # 4: msym: (mathmatical symbols)
  [ 0x2100, 0x214F, 0x25A0, 0x26FF ], # 5: xsym: (other symbols)
  [ 0xFF60, 0xFF9F ],  # 6: hwka: (halfwidth katakana)
  [ 0x4E00, 0x9FA5 ],  # 7: kanji: CJK Unified Ideograph (3.2)
  [ 0x80, 0x10FFEF ],  # 8: full: all non-ASCII characters
);
my @namegen = (
  undef,
  ['ZTSgrk', (undef) x 33, qw(Alpha Beta Gamma Delta Epsilon Zeta),
   qw(Eta Theta Iota Kappa Lambda Mu Nu Xi Omicron Pi Rho), undef,
   qw(Sigma Tau Upsilon Phi Chi Psi Omega), (undef) x 7,
   qw(alpha beta gamma delta epsilon zeta eta theta iota kappa),
   qw(lambda mu nu xi omicron pi rho), undef, qw(sigma tau upsilon),
   qw(phi chi psi omega) ],
  ['ZTScyr', undef, qw(Yo), (undef) x 14, qw(A B V G D E Zh Z I),
   qw(Ishrt K L M N O P R S T U F H C Ch Sh Shch Hrdsn Ery Sftsn),
   qw(Erev Yu Ya a b v g d e zh z i ishrt k l m n o p r s t u),
   qw(f h c ch sh shch hrdsn ery sftsn), undef, qw(yo) ],
  undef, undef, undef,
  ['ZTShwk', undef, qw( period bracketleft bracketright comma),
    qw(middledot wo asmall ismall usmall esmall osmall yasmall),
    qw(yusmall yosmall tusmall prolongmark a i u e o ka ki ku ke),
    qw(ko sa si su se so ta ti tu te to na ni nu ne no ha hi hu he),
    qw(ho ma mi mu me mo ya yu yo ra ri ru re ro wa n voicedmark),
    qw(semivoicedmark) ],
);
my %cchrgen = (
  10 => [
  ["hirkasvd",        0x82F5, 0xA4F7, 0x304B, 0x309A], # 1-04-87
  ["hirkisvd",        0x82F6, 0xA4F8, 0x304D, 0x309A], # 1-04-88
  ["hirkusvd",        0x82F7, 0xA4F9, 0x304F, 0x309A], # 1-04-89
  ["hirkesvd",        0x82F8, 0xA4FA, 0x3051, 0x309A], # 1-04-90
  ["hirkosvd",        0x82F9, 0xA4FB, 0x3053, 0x309A], # 1-04-91
  ["katkasvd",        0x8397, 0xA5F7, 0x30AB, 0x309A], # 1-05-87
  ["katkisvd",        0x8398, 0xA5F8, 0x30AD, 0x309A], # 1-05-88
  ["katkusvd",        0x8399, 0xA5F9, 0x30AF, 0x309A], # 1-05-89
  ["katkesvd",        0x839A, 0xA5FA, 0x30B1, 0x309A], # 1-05-90
  ["katkosvd",        0x839B, 0xA5FB, 0x30B3, 0x309A], # 1-05-91
  ["katsesvd",        0x839C, 0xA5FC, 0x30BB, 0x309A], # 1-05-92
  ["kattusvd",        0x839D, 0xA5FD, 0x30C4, 0x309A], # 1-05-93
  ["kattosvd",        0x839E, 0xA5FE, 0x30C8, 0x309A], # 1-05-94
  ["katsmallhusvd",   0x83F6, 0xA6F8, 0x31F7, 0x309A], # 1-06-88
  ],
  11 => [
  ["lataegrave"   ,   0x8663, 0xABC4, 0x00E6, 0x0300], # 1-11-36
  ["latopenograve",   0x8667, 0xABC8, 0x0254, 0x0300], # 1-11-40
  ["latopenoacute",   0x8668, 0xABC9, 0x0254, 0x0301], # 1-11-41
  ["latturnvgrave",   0x8669, 0xABCA, 0x028C, 0x0300], # 1-11-42
  ["latturnvacute",   0x866A, 0xABCB, 0x028C, 0x0301], # 1-11-43
  ["latschwagrave",   0x866B, 0xABCC, 0x0259, 0x0300], # 1-11-44
  ["latschwaacute",   0x866C, 0xABCD, 0x0259, 0x0301], # 1-11-45
  ["latschwahkgrave", 0x866D, 0xABCE, 0x025A, 0x0300], # 1-11-46
  ["latschwahkacute", 0x866E, 0xABCF, 0x025A, 0x0301], # 1-11-47
  ["symrising",       0x8685, 0xABE5, 0x02E9, 0x02E5], # 1-11-69
  ["symfalling",      0x8686, 0xABE6, 0x02E5, 0x02E9], # 1-11-70
  ],
);
my %ucs2aj = (
  0x2000b=>13839, 0x20089=>17233, 0x2008a=>14108, 0x200a2=>17240,
  0x200a4=>17243, 0x200b0=>14209, 0x200f5=>20057, 0x20158=>20075,
  0x201a2=>13857, 0x20213=>17259, 0x2032b=>17282, 0x20371=>17291,
  0x20381=>17289, 0x203f9=>17295, 0x2044a=>17297, 0x20509=>17299,
  0x205b1=>20080, 0x205d6=>17308, 0x20611=>14294, 0x20628=>14105,
  0x206ec=>20083, 0x2074f=>17312, 0x20807=>17319, 0x2083a=>17321,
  0x208b9=>17327, 0x2090e=>13523, 0x2097c=>17331, 0x2099d=>17332,
  0x20a64=>13755, 0x20ad3=>17337, 0x20b1d=>17340, 0x20b9f=>13803,
  0x20bb7=>13706, 0x20d45=>17359, 0x20d58=>20090, 0x20de1=>17373,
  0x20e64=>17388, 0x20e6d=>17380, 0x20e95=>17379, 0x20f5f=>17391,
  0x21201=>17414, 0x2123d=>13953, 0x21255=>17415, 0x21274=>17421,
  0x2127b=>17417, 0x212d7=>17429, 0x212e4=>17428, 0x212fd=>17435,
  0x2131b=>16816, 0x21336=>17437, 0x21344=>17438, 0x213c4=>17449,
  0x2146d=>17462, 0x2146e=>16821, 0x215d7=>17472, 0x21647=>17480,
  0x216b4=>16838, 0x21706=>17492, 0x21742=>17493, 0x218bd=>16833,
  0x219c3=>17525, 0x21a1a=> 7825, 0x21c56=>17539, 0x21d2d=>17544,
  0x21d45=>17545, 0x21d62=>17547, 0x21d78=>17546, 0x21d92=>17556,
  0x21d9c=>17552, 0x21da1=>17551, 0x21db7=>17559, 0x21de0=>17561,
  0x21e33=>17562, 0x21e34=>16845, 0x21f1e=>17575, 0x21f76=>17582,
  0x21ffa=>17585, 0x2217b=>17599, 0x22218=>19105, 0x2231e=>17605,
  0x223ad=>17608, 0x22609=>15443, 0x226f3=>17632, 0x2285b=>17647,
  0x228ab=>17653, 0x2298f=>17657, 0x22ab8=>17667, 0x22b46=>17680,
  0x22ba6=>17683, 0x22c1d=>17682, 0x22c24=>17686, 0x22de1=>17710,
  0x22e42=>20124, 0x22feb=>20130, 0x231b6=>17744, 0x231c3=>17742,
  0x231c4=>16888, 0x231f5=>17743, 0x23372=>17761, 0x233d0=>17768,
  0x233d2=>17764, 0x233d3=>17763, 0x233d5=>17770, 0x233da=>17772,
  0x233df=>17774, 0x233e4=>17769, 0x233fe=>15422, 0x2344a=>17782,
  0x2344b=>17784, 0x23451=>17783, 0x23465=>17788, 0x234e4=>17814,
  0x2355a=>17815, 0x23594=>17827, 0x235c4=>16905, 0x23638=>17843,
  0x23639=>17841, 0x2363a=>15393, 0x23647=>17842, 0x2370c=>17863,
  0x2371c=>17854, 0x2373f=>16914, 0x23763=>16916, 0x23764=>17867,
  0x237e7=>17875, 0x237ff=>17874, 0x23824=>17880, 0x2383d=>17885,
  0x23a98=>17897, 0x23c7f=>17910, 0x23cbe=>14293, 0x23cfe=>13904,
  0x23d00=>17925, 0x23d0e=>18394, 0x23d40=>17942, 0x23dd3=>17945,
  0x23df9=>17944, 0x23dfa=>17943, 0x23f7e=>17983, 0x2404b=>20168,
  0x24096=>17998, 0x24103=>18003, 0x241c6=>18015, 0x241fe=>18018,
  0x242ee=>14282, 0x243bc=>18039, 0x243d0=> 7838, 0x24629=>18049,
  0x246a5=>18055, 0x247f1=>16970, 0x24896=>18077, 0x24a4d=>18104,
  0x24b56=>18117, 0x24b6f=>18119, 0x24c16=>18124, 0x24d14=>13995,
  0x24e04=>20058, 0x24e0e=>18158, 0x24e37=>18162, 0x24e6a=>18167,
  0x24e8b=>18170, 0x24ff2=>20059, 0x2504a=>18181, 0x25055=>18183,
  0x25122=>18185, 0x251a9=>18190, 0x251cd=>18193, 0x251e5=>18192,
  0x2521e=>18195, 0x2524c=>18197, 0x2542e=>18209, 0x2548e=>17005,
  0x254d9=>18217, 0x2550e=>17009, 0x255a7=>18229, 0x2567f=>14075,
  0x25771=>17018, 0x257a9=>18248, 0x257b4=>18249, 0x25874=> 7670,
  0x259c4=>17024, 0x259cc=>20112, 0x259d4=>18268, 0x25ae3=>18277,
  0x25ae4=>18276, 0x25af1=>18278, 0x25bb2=>18293, 0x25c4b=>18302,
  0x25c64=>18303, 0x25da1=>17033, 0x25e2e=>18318, 0x25e56=>18319,
  0x25e62=>18322, 0x25e65=>18320, 0x25ec2=>18327, 0x25ed8=>18325,
  0x25ee8=>18329, 0x25f23=>18330, 0x25f5c=>18332, 0x25fd4=>18339,
  0x25fe0=>18338, 0x25ffb=>18345, 0x2600c=>18344, 0x26017=>18352,
  0x26060=>18355, 0x260ed=>18365, 0x26270=>18385, 0x26286=>18386,
  0x2634c=>20311, 0x26402=>18398, 0x2667e=>18416, 0x266b0=>14100,
  0x2671d=>18430, 0x268dd=>18444, 0x268ea=>18446, 0x26951=>13646,
  0x2696f=>18450, 0x26999=>14134, 0x269dd=>18452, 0x26a1e=>18455,
  0x26a58=>18459, 0x26a8c=>18463, 0x26ab7=>18466, 0x26aff=>17063,
  0x26c29=>17478, 0x26c73=>18506, 0x26c9e=>20206, 0x26cdd=>18515,
  0x26e40=>17089, 0x26e65=>18528, 0x26f94=>18544, 0x26ff8=>18553,
  0x270f4=>17103, 0x2710d=>18571, 0x27139=>18574, 0x273da=>18611,
  0x273db=>18610, 0x273fe=>18617, 0x27410=>18620, 0x27449=>18624,
  0x27614=>18638, 0x27615=>18637, 0x27631=>18640, 0x27684=>17117,
  0x27693=>18645, 0x2770e=>18650, 0x27723=>18652, 0x27752=>18656,
  0x27985=>18672, 0x279b4=>20133, 0x27a84=>18684, 0x27bb3=>18699,
  0x27bbe=>18701, 0x27bc7=>18702, 0x27c3c=>20220, 0x27cb8=>18708,
  0x27d73=>20060, 0x27da0=>18716, 0x27e10=>18718, 0x27fb7=>13898,
  0x2808a=>18727, 0x280bb=>18733, 0x28277=>17140, 0x28282=>18745,
  0x282f3=>18747, 0x283cd=>17146, 0x2840c=>18754, 0x28455=>18757,
  0x2856b=>18770, 0x286d7=>18784, 0x286fa=>18787, 0x28946=>18812,
  0x28949=>18811, 0x2896b=>18817, 0x28987=>14253, 0x28988=>18824,
  0x28a1e=>18843, 0x28a29=>18844, 0x28a43=>18848, 0x28a71=>18847,
  0x28a99=>18855, 0x28acd=>18856, 0x28add=>18863, 0x28ae4=>18862,
  0x28bc1=>18874, 0x28bef=>18875, 0x28cdd=> 7641, 0x28d10=>18882,
  0x28d71=>18883, 0x28dfb=>18885, 0x28e17=>14256, 0x28e1f=>18886,
  0x28e36=>18890, 0x28e89=>18893, 0x28eeb=>18895, 0x28ef6=> 7673,
  0x28f32=>18897, 0x28ff8=>18903, 0x292a0=>18917, 0x292b1=>18918,
  0x29490=>18935, 0x295cf=>18944, 0x2967f=>13849, 0x296f0=>18959,
  0x29719=>18962, 0x29750=>18966, 0x298c6=>18983, 0x29a72=>19001,
  0x29d4b=>13717, 0x29ddb=>19026, 0x29e15=>19036, 0x29e3d=>20315,
  0x29e49=>19038, 0x29e8a=>19037, 0x29ec4=>19046, 0x29edb=>19054,
  0x29ee9=>19051, 0x29fce=>19071, 0x29fd7=>19071, 0x2a01a=>19077,
  0x2a02f=>19075, 0x2a082=>19084, 0x2a0f9=>19083, 0x2a190=>17227,
  0x2a2b2=>20072, 0x2a38c=>19109, 0x2a437=>19111, 0x2a5f1=>19123,
  0x2a602=>19125, 0x2a61a=>20316, 0x2a6b2=>19129, 0x2f804=>15388,
  0x2f80f=> 7814, 0x2f815=>20061, 0x2f818=> 7817, 0x2f81a=>13954,
  0x2f822=>13684, 0x2f828=>13807, 0x2f82c=>14109, 0x2f833=>13719,
  0x2f83f=>13815, 0x2f846=>20062, 0x2f852=>13841, 0x2f862=>13998,
  0x2f86d=>14121, 0x2f873=>13832, 0x2f877=> 7754, 0x2f884=> 7734,
  0x2f899=>20063, 0x2f89a=>13928, 0x2f8a6=>20064, 0x2f8ac=>13750,
  0x2f8b2=>13867, 0x2f8b6=>14129, 0x2f8d3=> 7816, 0x2f8db=>14140,
  0x2f8dc=> 7695, 0x2f8e1=>14291, 0x2f8e5=>20065, 0x2f8ea=>13679,
  0x2f8ed=> 7665, 0x2f8fc=>13656, 0x2f903=>13768, 0x2f90b=>13801,
  0x2f90f=>13932, 0x2f91a=>13916, 0x2f920=> 7839, 0x2f921=>13809,
  0x2f945=>13357, 0x2f947=>13854, 0x2f96c=>14180, 0x2f995=>13670,
  0x2f9d0=>14068, 0x2f9de=>20066, 0x2f9df=>14069, 0x2f9f4=>15269,
);

my ($IV0, $IV1, $IV2, $IV3, $IV4, $IV5, $IV6, $IV7,
    $IV8, $IV9, $IV10, $IV11, $IV12, $IV13, $IV14, $IV15)
  = map { chr($_) } (0xe0100 .. 0xe010f); # VS17..VS32
my %ucsivs2aj; # The value is written in <DATA> section.
my $rxivrng = qr/[$IV0-$IV15]/;

####------------------------------------ main procedure

sub main {
  read_option();
  if ($mode eq 'start') { proc_start(); }
  elsif ($mode eq 'dobase') { proc_do(1); }
  elsif ($mode eq 'do') { proc_do(0); }
  elsif ($mode eq 'end') { proc_end(); }
  elsif ($mode eq 'clean') { proc_clean(); }
  elsif ($mode eq 'filter') { proc_filter(); }
} 

####------------------------------------ 'start'

sub proc_start {
  find_encoding();
  finish("*OK");
}

sub find_encoding {
  my ($f); my ($lin, $r, $hin, $hout);
  $f = "${tempbase}_0.tex";
  if ($swbx) {
    $r = 'byte';
  } else {
    if (!-f $f) { return; }
    open($hin, '<', $f)
      or error("cannot open input file: $f");
    $lin = <$hin>; chomp($lin);
    $r = ($lin eq "\x1b\x24\x42\x30\x6c\x1b\x28\x42") ? 'jis' :
         ($lin eq "\x88\xea") ? 'sjis' :
         ($lin eq "\xb0\xec") ? 'euc' :
         ($lin eq "\xe4\xb8\x80") ? 'utf8' : 
         error("unknown source encoding");
    close($hin);
  }
  open($hout, '>', $f)
    or error("cannot open output file: $f");
  print $hout ('\filterinencoding', "{$r}\n");
  close($hout);
}

####------------------------------------ 'do'

sub proc_do {
  my ($swbas) = @_; local ($_);
  my ($t, $lin, $ofn, $ifn, $par, $swskp, $hin, $hout, @lins); 
  ($ofn, $ifn, $par) = @ARGV; $ofn = "${tempbase}_$ofn.tex";
  $par =~ s/\^,/,/g; # adjustment for runscr.exe
  if (($t) = $ifn =~ m/^\*(.*)/) {
    undef $ifn;
    open($hin, '<', "$t.log")
      or error("cannot open log file: $t.log");
    foreach (1 .. 10) {
      if (!defined($lin = <$hin>)) { finish("*DK"); }
      if ($lin =~ m/^\((\S+)/ && -f $t) { $ifn = $t; last; }
    }
    (defined $ifn) or error("cannot find source file name");
    close($hin);
  } else {
    if ($ifn =~ m/\.tex$/i && !-f $ifn) { $ifn .= ".tex"; }
  }
  open($hin, '<', $ifn)
    or error("cannot open input file: $ifn");
  $swskp = $swbas;
  while ($lin = <$hin>) {
    if ($swskp) {
      if ($lin =~ m/^\s*\\(pxflstart|filterstart)[^A-Za-z]/) {
        $swskp = 0; push(@lins, $lin);
      }
    } elsif ($swbas && $lin =~ m/^\s*\\end\s*{document}/) {
      $t = '\csname pxfl@enddoctrue\endcsname';
      push(@lins, "$t\n"); last;
    } else { push(@lins, $lin); }
  }
  close($hin);
  $t = convert(join('', @lins), $par);
  open($hout, '>', $ofn)
    or error("cannot open output file: $ofn");
  print $hout ($t);
  close($hout);
  finish("*OK");
}

sub convert {
  my ($txt, $par) = @_; my ($e, $c, $t, $u, @v, $es, $us);
  my ($rxdb, $enc, $oenc, @ext);
  #
  $enc = BYTE; $oenc = JIS; @conv = ();
  @v = split(/,/, $par);
  foreach (@v) {
    if (($t) = m/^\+(.*)/) {
      ($swextfilt) or error("external filters are disabled", $t);
      push(@ext, $t);
    } elsif (defined($e = $partable{$_})) {
      $t = $e->[0];
      if ($t eq 'u' || $t eq 'c') { $conv[$e->[1]] = $t; }
      elsif ($t eq 'i') { $enc = $e->[1]; }
      elsif ($t eq 'o') { $oenc = $e->[1]; }
      elsif ($t eq 's') { ${$e->[1]} = 1; }
    } else { alert("invalid parameter: $_"); }
  }
  if ($swbx) { $oenc = UTF8; }
  if ($enc == AUTO) { $enc = judge_encode($txt); }
  $rxdb = $checkdbc[$enc]; @v = ();
  make_xcode_table($enc);
  if (@conv) { make_conv_table(); }
  if ($swuseajx) { make_convajx_table(); $swuseaj = 1; }
  if ($swuseaj) { make_convaj_table(); }
  L1:{
    # step 1 : decode input text
    if (!$swbx && ($enc == BYTE || $enc == JIS)) {
      $txt =~ s/([\x80-\xff])/texesc($1)/ge;
    } 
    if ($enc == BYTE || $enc == THRU) { last L1; }
    while (1) {
      push(@v, decode($encname[$enc], $txt, Encode::FB_QUIET));
      if ($txt eq '') { last; }
      $u = (defined $rxdb && $txt =~ $rxdb) ? 2 : 1;
      $es = substr($txt, 0, $u);
      if (!defined($us = decode_ex($enc, $es))) {
        $us = ($swlax) ? texesc($es) : texwarn($es);
      }
      push(@v, $us); $txt = substr($txt, $u);
    }
    $txt = join('', @v); @v = ();
    # step 2 : replace target characters
    if ($swuseajx) {
      $txt =~ s/$rxtgtajx/repl_convajx($1)/ge;
      $txt =~ s/$rxivrng//g;
    }
    if ($swuseaj) {
      $txt =~ s/$rxtgtaj/$dictaj{$1}/ge;
    }
    if (defined $rxtarget) {
      $txt =~ s/$rxtarget/convert_one($1)/ge;
    }
    # step 3 : convert to output encoding
    if ($oenc == JIS || $oenc == SJIS || $oenc == EUC) {
                  # avoid buggy behaviour of Perl
      $txt =~ s/^\x{FEFF}?/\x80\x01\x02\x03/;
      $txt =~ s[([^\x00-\x7f$BC1$BC2])]{
        (length(encode($encname[SJIS], $1)) == 2) ? $1 : # in JISX0208
          format_utf8($1)
      }ge;
      $txt =~ s/^(.*?)\x02\x03//;
    }
      # process blocker characters
    $txt =~ s[$BC1(\s*[\r\n]|.|\z)]{
      (($t = $1) =~ m/[\x21-\x3f\x5b-\x60\x7b-\x7f\r\n]/) ? $t :
        "\\pxflI{}$t"
    }ges;
    $txt =~ s/$BC2(\s*[\r\n])/\%$1/g; $txt =~ s/$BC2//g;
    $txt = encode($encname[$oenc], $txt);
  }
  # step 4 : apply external filters
  if (@ext) { $txt = ext_filter($txt, \@ext); }
  return $txt;
}

sub convert_one {
  my ($c) = @_; my ($t);
  if (defined($t = $dict{$c})) { return $t; }
  if ($swbx && !$swuseux) { return $c; }
  return ($dict{$c} = format_utf8($c));
}

sub judge_encode {
  my ($txt) = @_;
  my ($sc, $sh, $sb, $e, $s, $os, $oe, $t, @v);
  if ($txt =~ /^\xef\xbb\xbf/) { return UTF8; }
  if ($txt =~ /\x1b\x24[\x40\x42]/) { return JIS; }
  if ($txt !~ /[\x80-\xff]/) { return BYTE; }
  $os = 0; $oe = BYTE;
  foreach $e (UTF8, EUC, SJIS) {
    for (@v = (), $sb = 0, $t = $txt; ; ) {
      push(@v, decode($encname[$e], $t, Encode::FB_QUIET));
      if ($t eq '') { last; }
      $t = substr($t, 1); ++$sb;
    }
    $t = join('', @v);
    $t =~ s/[\x{FF61}-\x{FF9F}]//g; $sc = length($t);
    $t =~ s/[^\x{3041}-\x{3093}]//g; $sh = length($t);
    $s = $sc + $sh * 4 - $sb * 10;
    #alert("$e = $s ($sc,$sh,$sb)");
    if ($s >= $os) { $os = $s; $oe = $e; }
  }
  return $oe;
}

sub ext_filter {
  my ($txt, $ext) = @_; local ($/);
  my ($hin, $hout, $ifn, $ofn, @v, $cmd);
  $ifn = "${tempbase}_ti.tex"; $ofn = "${tempbase}_to.tex";
  @v = @$ext; $v[0] .= " < $ifn"; $v[$#v] .= " > $ofn";
  foreach (@v) {
    if (m/^((\S+)\.(pl|perl))(\s|$)/ && !-x $1)
    { $_ = "perl -S $_"; }
  }
  $cmd = join(" | ", @v);
  L1: {
    open($hin, '>', $ifn) or last L1;
    print $hin ($txt); close($hin);
    (system($cmd) == 0) or last L1;
    open($hout, '<', $ofn) or last L1;
    $txt = <$hout>; close($hout);
    unlink($ifn, $ofn);
    return $txt;
  }
  error("failed in processing external filters");
}

# Here shiftjisx0213 strings are decoded via eucjisx0213. Note
# that Encode::decode('eucjp') can handle JISX0213 (and 0212)
# whereas Encode::decode('shiftjis') cannot.

# $euchb[N] is high byte of euc-jisx0213 strings corresponding to
# plane 2 row N+1 characters.
my @euchb = (
  0xa1, 0xa8, 0xa3, 0xa4, 0xa5, 0xac, 0xad, 0xae,
  0xaf, 0xee .. 0xfe
);
## sjisx_to_eucx($bstr)
# Convert a shiftjisx0213 encoded string $bstr to eucjisx0213.
sub sjisx_to_eucx {
  my ($t) = @_; my ($h, $l, $s);
  ($h, $l) = unpack("CC", $t);
  $l += ($l >= 128) ? 96 : 97;
  $h = ($h - (($h >= 224) ? 193 : 129)) * 2 + 161;
  if ($l >= 255) { $l -= 94; ++$h; }
  if ($h >= 255) { $s = 1; $h = $euchb[$h - 255]; }
  $t = pack("C*", ($s) ? (143) : (), $h, $l);
  return $t;
}

## make_xcode_table($enc)
# Make table %xcode for decoding JIS-composite characters.
sub make_xcode_table {
  my ($enc) = @_; my ($k, $e, $s);
  $s = ($enc == SJIS) ? 1 : ($enc == EUC) ? 2 : return;
  foreach $k (keys %cchrgen) {
    foreach $e (@{$cchrgen{$k}}) {
      $xcode{pack('n', $e->[$s])} = chr($e->[3]) . chr($e->[4]);
    }
  }
}

## decode_ex($enc, $bstr)
# Decodes nonstandard characters (including JISX0213 chars).
sub decode_ex {
  my ($enc, $str) = @_; my ($t);
  if ($enc == SJIS) {
    $t = decode($encname[EUC], sjisx_to_eucx($str));
    if ($t ne "\x{FFFD}") { return $t; }
  }
  if (%xcode) {
    if (defined($t = $xcode{$str})) { return $t; }
  }
  return;
}

sub make_conv_table {
  my ($c, $j, $k, $t, $u, $swu, $pfx, $urng, @v, @us, @ns);
  my (@gus, $gurng);
  %dict = ($BC1, '', $BC2, ''); @gus = ($BC1, $BC2); $gurng = [];
  foreach $k (0 .. $#conv) {
    ($conv[$k]) or next; $swu = ($conv[$k] eq 'u'); 
    @us = @ns = (); undef $pfx; undef $urng;
    if (defined($t = $range[$k])) {
      $urng = $t; add_range($gurng, $t);
      if (defined($t = $namegen[$k])) { ($pfx, @ns) = @$t; }
    } elsif (defined($t = $cchrgen{$k})) {
      $pfx = "ZTS";
      foreach $u (@$t) {
        push(@us, chr($u->[3]) . chr($u->[4]));
        push(@ns, $u->[0]);
      }
      push(@gus, @us);
    }
    ($swu || @ns) or error("*INTERNAL10*");
    (defined $urng || @us) or error("*INTERNAL11*");
    if (!$swu && @ns) {
      $j = 0;
      if (@us) {
        foreach $c (@us) {
          $t = $ns[$j++];
          if (defined $t) { $dict{$c} = "\\$pfx$t$BC1"; }
        }
      } elsif (defined $urng) {
        for (@v = @$urng; @v; ) {
          ($t, $u) = splice(@v, 0, 2);
          foreach $c ($t .. $u) {
            $t = $ns[$j++];
            if (defined $t) { $dict{chr($c)} = "\\$pfx$t"; }
          }
        }
      }
    }
  }
  $rxtarget = rx_generate($gurng, \@gus);
  #
  #binmode(STDOUT, ':utf8');
  #print($rxtarget, "\n");
  #foreach $c (sort { $a cmp $b } (keys %dict)) {
  #  printf("[%s] => [%s]\n", $c, $dict{$c});
  #}
  #exit;
}

sub add_range {
  my ($info, $rng) = @_;  my ($s, $e, $r, @v, $e1, $s1);
  my ($phase, @ninfo);
  for (@v = @$rng; @v; ) {
    ($s, $e) = splice(@v, 0, 2); @ninfo = (); $phase = 0;
    foreach $r (@$info) {
      ($s1, $e1) = @$r;
      if ($phase == 1 || $e1 < $s - 1) {
        push(@ninfo, $r);
      } elsif ($e + 1 < $s1) {
        if ($phase == 0) { push(@ninfo, [$s, $e]); }
        push(@ninfo, $r); $phase = 1;
      } else {
        if ($s > $s1) { $s = $s1; }
        if ($e < $e1) { $e = $e1; }
      } 
    }
    if ($phase == 0) { push(@ninfo, [$s, $e]); }
    @$info = @ninfo;
  }
}

sub rx_generate {
  my ($info, $us) = @_; my ($t, $u, $c, @rs, @w);
  foreach $c (@$info) {
    push(@rs, chr($c->[0]) . '-' . chr($c->[1]));
  }
  $u = join('', @rs);
  if ($u eq "\x{80}-\x{10FFFF}") { $u = "^\\x00-\\x7F"; }
  $t = join('|', (@rs) ? "[$u]" : (), @$us); 
  if ($t ne '') { $rxtarget = qr/($t)/; }
}

sub make_convaj_table {
  my ($uc, $u, @v);
  foreach $uc (keys %ucs2aj) {
    $dictaj{chr($uc)} = sprintf("\\AJ{%d}$BC2", $ucs2aj{$uc});
  }
  @v = sort { $a cmp $b } (keys %dictaj); $u = join('', @v);
  $rxtgtaj = qr/([$u])/;
}

sub make_convajx_table {
  my ($uc, $u, @v);
  load_extra();
  @v = sort { $a cmp $b } (keys %ucsivs2aj); $u = join('|', @v);
  $rxtgtajx = qr/($u)/;
}
sub repl_convajx {
  my ($t) = @_;
  return sprintf("\\AJ{%d}$BC2", $ucsivs2aj{$t});
}

sub format_utf8 {
  my ($txt) = @_;
  if (!$swuseux) { return texesc(encode($encname[UTF8], $txt)); }
  $txt  = join('', map { sprintf("\\Ux{%04X}$BC2", ord($_)) }
                       (split(m//, $txt)));
  return $txt;
}

# texesc($bstr)
# Turns a binary string into tex-escaped (^^ab) form.
sub texesc {
  return join('', map { sprintf("^^%02x", ord($_)) }
                      (split(//, $_[0])));
}

## texwarn($bstr)
# Turns each byte in $bstr into \pxflWarn.
sub texwarn {
  return join('', map { sprintf("\\pxflWarn{%02X}", ord($_)) }
                      (split(//, $_[0])));
}

####------------------------------------ 'end'

sub proc_end {
  my ($no); $no = shift(@ARGV);
  foreach (0 .. $no) { unlink("${tempbase}_$_.tex"); }
  close($hanswer); unlink($ansfile); exit;
}

####------------------------------------ 'clean'

sub proc_clean {
  my ($t, $rx, @v);
  $rx = qr/^\Q$tempbase\E\d+(\.out|_(\d+|ti|to)\.tex)/;
  @v = grep { /$rx/ } (glob("${tempbase}*.*"));
  foreach $t (@v) {
    (unlink($t)) or next;
    alert("temporary file removed: $t");
  }
  finish();
}

####------------------------------------ 'filter'

sub proc_filter {
  my ($par, $t); local ($_, $/);
  $par = shift(@ARGV);
  while ($t = <>) {
    print(convert($t, $par));
  }
}

####------------------------------------ interface

# In invocation from TeX, the command line is of either one of the
# following forms:
# pxfltsrc ::<temp_base> [BX} start
# pxfltsrc ::<temp_base> [BX} do <out_id> <in_file> <par_list>
# pxfltsrc ::<temp_base> [BX} end <last_out_id>
# pxfltsrc ::<temp_base> [BX} clean

sub read_option {
  my ($par, $opt, $clean);
  $swextfilt = allow_ext_filter();
  if (!@ARGV) {
    show_usage();
  } elsif ($ARGV[0] =~ m/^\::(.*)/) { # called from TeX
    $tempbase = $1; $ansfile = "$tempbase.out";
    shift(@ARGV); $mode = shift(@ARGV);
    if ($mode eq 'BX') { $swbx = 1; $mode = shift(@ARGV); }
    open($hanswer, '>', $ansfile)
      or error("cannot open output file: $ansfile");
  } else { # manual mode
    while ($ARGV[0] =~ m/^[\+\-]/) {
      $opt = shift(@ARGV);
      if ($opt =~ m/^-(?:h|-?help)$/) {
        show_usage();
      } elsif ($opt =~ m/^-(?:b|-bx)$/) {
        $swbx = 1;
      } elsif ($opt =~ m/^(?:\+|--par\b[:=]?)(.*)/) {
        $par = $1;
      } else {
        error("unknown option", $opt);
      }
    }
    if ($par eq 'clean') { # clean
      $mode = "clean";
      ($#ARGV <= 0) or error("wrong number of arguments");
      if (@ARGV) { $tempbase = shift(@ARGV); }
    } else { # filter
      $mode = "filter";
      unshift(@ARGV, $par);
    }
  }
}

sub show_usage {
  my ($t, @a);
  $t = join(' ', sort { $a cmp $b } (keys %partable));
  if (!$swextfilt) {
    $t .= "\n(Currently external filters are disabled.)";
  }
  print(<<"END"); exit();
This is $prog_name v$version <$mod_date> by 'ZR'
Usage: $prog_name [-b/--bx] +<directive>,... [<source_file>...]
       $prog_name +clean [<prefix>]
  -b  --bx  'bxfltsrc' mode
Available directives:
$t
END
}

sub allow_ext_filter {
  my ($t);
  if (lc(ALLOW_EXT_FILTER) eq 'yes') { return 1; }
  elsif (lc(ALLOW_EXT_FILTER) eq 'no') { return ''; }
  else {
    $t = `kpsewhich -var-value=PXFLTSRC_NO_EXT_FILTER`;
    return ($t =~ m/^\s*0?\s*$/);
  }
}

sub uni_dump {
  my ($t, $n) = @_;
  if (!defined $n) { $n = 40; }
  $t = substr($t, 0, $n);
  $t = join(',', map { sprintf("%X", ord($_)) } (split(//, $t)));
  if (length($t) >= $n - 2) { $t = substr($t, 0, $n - 2) . ".."; }
  return $t;
}

sub finish {
  if (defined $_[0]) {
    if (defined $hanswer) { print $hanswer ($_[0], "\n"); }
  } else {
    if (defined $hanswer) { close($hanswer); unlink($ansfile); }
  }
  exit;
}

sub alert {
  print STDERR (join(": ", $prog_name, "warning", @_), "\n");
}

sub error {
  print STDERR (join(": ", $prog_name, @_), "\n");
  if ($hanswer) { finish("*NG"); } else { exit; }
}

#### go to main
main();
####------------------------------------ extra code
sub load_extra {
  local ($_, $/);
  $_ = <DATA>; eval($_);
}
__DATA__
%ucsivs2aj = (
"\x{3402}$IV0"=>13698, "\x{3402}$IV1"=>13697, "\x{3402}$IV2"=>13699,
"\x{4E08}$IV0"=>2510, "\x{4E08}$IV1"=>13463, "\x{4E0E}$IV0"=>3881,
"\x{4E0E}$IV1"=>20073, "\x{4E19}$IV0"=>3594, "\x{4E19}$IV1"=>14009,
"\x{4E26}$IV0"=>3602, "\x{4E26}$IV1"=>20074, "\x{4E30}$IV0"=>14301,
"\x{4E30}$IV1"=>15386, "\x{4E39}$IV0"=>2926, "\x{4E39}$IV1"=>13914,
"\x{4E3B}$IV0"=>2323, "\x{4E3B}$IV1"=>13812, "\x{4E73}$IV0"=>3285,
"\x{4E73}$IV1"=>13968, "\x{4EA1}$IV0"=>3682, "\x{4EA1}$IV1"=>14031,
"\x{4EA4}$IV0"=>1958, "\x{4EA4}$IV1"=>13439, "\x{4ECA}$IV0"=>2067,
"\x{4ECA}$IV1"=>13780, "\x{4F34}$IV0"=>3408, "\x{4F34}$IV1"=>13984,
"\x{4F4F}$IV0"=>2373, "\x{4F4F}$IV1"=>13820, "\x{4F60}$IV0"=>14316,
"\x{4F60}$IV1"=>15388, "\x{4F73}$IV0"=>1346, "\x{4F73}$IV1"=>20076,
"\x{4F75}$IV0"=>3595, "\x{4F75}$IV1"=>13383, "\x{4F7F}$IV0"=>2198,
"\x{4F7F}$IV1"=>13450, "\x{4FAE}$IV0"=>3552, "\x{4FAE}$IV1"=>13382,
"\x{4FB5}$IV0"=>2549, "\x{4FB5}$IV1"=>13851, "\x{4FBF}$IV0"=>3624,
"\x{4FBF}$IV1"=>13506, "\x{5024}$IV0"=>2955, "\x{5024}$IV1"=>13919,
"\x{5026}$IV0"=>1863, "\x{5026}$IV1"=>7674, "\x{5049}$IV0"=>1170,
"\x{5049}$IV1"=>13409, "\x{504F}$IV0"=>3616, "\x{504F}$IV1"=>14014,
"\x{5056}$IV0"=>4176, "\x{5056}$IV1"=>20077, "\x{5065}$IV0"=>1864,
"\x{5065}$IV1"=>13435, "\x{5085}$IV0"=>4181, "\x{5085}$IV1"=>13520,
"\x{5091}$IV0"=>1852, "\x{5091}$IV1"=>13433, "\x{5091}$IV2"=>13743,
"\x{50C5}$IV0"=>1735, "\x{50C5}$IV1"=>7662, "\x{50CA}$IV0"=>4185,
"\x{50CA}$IV1"=>7982, "\x{50CA}$IV2"=>14101, "\x{50CF}$IV0"=>2814,
"\x{50CF}$IV1"=>13474, "\x{50E7}$IV0"=>2768, "\x{50E7}$IV1"=>13360,
"\x{50ED}$IV0"=>4191, "\x{50ED}$IV1"=>20078, "\x{50F2}$IV0"=>16786,
"\x{50F2}$IV1"=>21164, "\x{511A}$IV0"=>4202, "\x{511A}$IV1"=>14102,
"\x{5132}$IV0"=>3813, "\x{5132}$IV1"=>7798, "\x{5146}$IV0"=>3001,
"\x{5146}$IV1"=>13477, "\x{514D}$IV0"=>3796, "\x{514D}$IV1"=>13389,
"\x{514E}$IV0"=>3136, "\x{514E}$IV1"=>13949, "\x{5154}$IV0"=>7814,
"\x{5154}$IV1"=>4212, "\x{5154}$IV2"=>14103, "\x{5168}$IV0"=>2742,
"\x{5168}$IV1"=>13890, "\x{516B}$IV0"=>3392, "\x{516B}$IV1"=>20079,
"\x{516C}$IV0"=>1964, "\x{516C}$IV1"=>13440, "\x{5177}$IV0"=>1769,
"\x{5177}$IV1"=>13733, "\x{517C}$IV0"=>1865, "\x{517C}$IV1"=>13748,
"\x{5189}$IV0"=>4222, "\x{5189}$IV1"=>7815, "\x{518D}$IV0"=>20061,
"\x{518D}$IV1"=>2102, "\x{5192}$IV0"=>3695, "\x{5192}$IV1"=>14038,
"\x{5193}$IV0"=>4225, "\x{5193}$IV1"=>13521, "\x{5195}$IV0"=>7816,
"\x{5195}$IV1"=>4226, "\x{5195}$IV2"=>14104, "\x{51A4}$IV0"=>4228,
"\x{51A4}$IV1"=>7817, "\x{51AC}$IV0"=>13954, "\x{51AC}$IV1"=>3161,
"\x{51B4}$IV0"=>2131, "\x{51B4}$IV1"=>13404, "\x{51B4}$IV2"=>13787,
"\x{51CB}$IV0"=>3002, "\x{51CB}$IV1"=>7742, "\x{51DB}$IV0"=>4242,
"\x{51DB}$IV1"=>13522, "\x{51DE}$IV0"=>20300, "\x{51DE}$IV1"=>20307,
"\x{51DE}$IV2"=>14352, "\x{51DE}$IV3"=>20081, "\x{51DE}$IV4"=>8542,
"\x{51E1}$IV0"=>3724, "\x{51E1}$IV1"=>14041, "\x{51FD}$IV0"=>3381,
"\x{51FD}$IV1"=>20082, "\x{5203}$IV0"=>2581, "\x{5203}$IV1"=>13858,
"\x{5206}$IV0"=>3580, "\x{5206}$IV1"=>13499, "\x{5224}$IV0"=>3409,
"\x{5224}$IV1"=>13985, "\x{5238}$IV0"=>1866, "\x{5238}$IV1"=>13749,
"\x{524A}$IV0"=>2143, "\x{524A}$IV1"=>13789, "\x{524D}$IV0"=>2738,
"\x{524D}$IV1"=>13889, "\x{5264}$IV0"=>2126, "\x{5264}$IV1"=>20084,
"\x{5271}$IV0"=>4274, "\x{5271}$IV1"=>20085, "\x{5272}$IV0"=>13684,
"\x{5272}$IV1"=>1474, "\x{5272}$IV2"=>20086, "\x{5275}$IV0"=>2769,
"\x{5275}$IV1"=>7723, "\x{528D}$IV0"=>4271, "\x{528D}$IV1"=>14106,
"\x{52C7}$IV0"=>3856, "\x{52C7}$IV1"=>14070, "\x{52C9}$IV0"=>13385,
"\x{52C9}$IV1"=>3625, "\x{52D7}$IV0"=>4285, "\x{52D7}$IV1"=>14107,
"\x{52DD}$IV0"=>2441, "\x{52DD}$IV1"=>13829, "\x{52E2}$IV0"=>2638,
"\x{52E2}$IV1"=>13866, "\x{52E4}$IV0"=>1736, "\x{52E4}$IV1"=>13338,
"\x{52FA}$IV0"=>13807, "\x{52FA}$IV1"=>2311, "\x{5300}$IV0"=>8403,
"\x{5300}$IV1"=>14287, "\x{5305}$IV0"=>3649, "\x{5305}$IV1"=>14019,
"\x{5307}$IV0"=>20301, "\x{5307}$IV1"=>8404, "\x{5315}$IV0"=>4301,
"\x{5315}$IV1"=>7983, "\x{5316}$IV0"=>1341, "\x{5316}$IV1"=>13665,
"\x{5339}$IV0"=>3478, "\x{5339}$IV1"=>13994, "\x{533F}$IV0"=>3223,
"\x{533F}$IV1"=>20087, "\x{5340}$IV0"=>4308, "\x{5340}$IV1"=>13524,
"\x{534A}$IV0"=>3410, "\x{534A}$IV1"=>13986, "\x{5351}$IV0"=>13378,
"\x{5351}$IV1"=>3440, "\x{535A}$IV0"=>3364, "\x{535A}$IV1"=>13976,
"\x{5365}$IV0"=>19207, "\x{5365}$IV1"=>21235, "\x{5371}$IV0"=>1577,
"\x{5371}$IV1"=>13696, "\x{5378}$IV0"=>1335, "\x{5378}$IV1"=>13663,
"\x{537F}$IV0"=>13719, "\x{537F}$IV1"=>1698, "\x{537F}$IV2"=>7661,
"\x{53A9}$IV0"=>1243, "\x{53A9}$IV1"=>7640, "\x{53A9}$IV2"=>7964,
"\x{53A9}$IV3"=>13412, "\x{53A9}$IV4"=>13647, "\x{53A9}$IV5"=>20271,
"\x{53C9}$IV0"=>2085, "\x{53C9}$IV1"=>20281, "\x{53CA}$IV0"=>1652,
"\x{53CA}$IV1"=>13710, "\x{53CE}$IV0"=>2345, "\x{53CE}$IV1"=>13455,
"\x{53D7}$IV0"=>2337, "\x{53D7}$IV1"=>13813, "\x{53DB}$IV0"=>3412,
"\x{53DB}$IV1"=>7978, "\x{53DF}$IV0"=>4332, "\x{53DF}$IV1"=>14111,
"\x{53E0}$IV0"=>19219, "\x{53E0}$IV1"=>21248, "\x{53F1}$IV0"=>2276,
"\x{53F1}$IV1"=>7692, "\x{53F2}$IV0"=>2201, "\x{53F2}$IV1"=>13451,
"\x{540F}$IV0"=>3939, "\x{540F}$IV1"=>13513, "\x{5438}$IV0"=>1653,
"\x{5438}$IV1"=>13711, "\x{5440}$IV0"=>4341, "\x{5440}$IV1"=>20089,
"\x{5448}$IV0"=>3076, "\x{5448}$IV1"=>13942, "\x{5468}$IV0"=>13815,
"\x{5468}$IV1"=>2346, "\x{54AC}$IV0"=>4368, "\x{54AC}$IV1"=>20277,
"\x{54B2}$IV0"=>2137, "\x{54B2}$IV1"=>13788, "\x{54E8}$IV0"=>2445,
"\x{54E8}$IV1"=>7703, "\x{5510}$IV0"=>3164, "\x{5510}$IV1"=>13955,
"\x{5533}$IV0"=>4397, "\x{5533}$IV1"=>7819, "\x{5533}$IV2"=>14113,
"\x{5539}$IV0"=>4387, "\x{5539}$IV1"=>7818, "\x{5544}$IV0"=>2895,
"\x{5544}$IV1"=>7730, "\x{5546}$IV0"=>2446, "\x{5546}$IV1"=>13830,
"\x{5553}$IV0"=>1810, "\x{5553}$IV1"=>13738, "\x{5561}$IV0"=>20308,
"\x{5561}$IV1"=>14393, "\x{5584}$IV0"=>2739, "\x{5584}$IV1"=>20062,
"\x{559C}$IV0"=>1578, "\x{559C}$IV1"=>20091, "\x{559D}$IV0"=>1475,
"\x{559D}$IV1"=>7651, "\x{55A9}$IV0"=>4411, "\x{55A9}$IV1"=>7984,
"\x{55A9}$IV2"=>13526, "\x{55AB}$IV0"=>1636, "\x{55AB}$IV1"=>13707,
"\x{55AB}$IV2"=>20092, "\x{55B0}$IV0"=>1772, "\x{55B0}$IV1"=>7664,
"\x{55E4}$IV0"=>4419, "\x{55E4}$IV1"=>7820, "\x{55E4}$IV2"=>14114,
"\x{5605}$IV0"=>19255, "\x{5605}$IV1"=>21293, "\x{5606}$IV0"=>13366,
"\x{5606}$IV1"=>2928, "\x{5609}$IV0"=>1349, "\x{5609}$IV1"=>20093,
"\x{5632}$IV0"=>4433, "\x{5632}$IV1"=>7821, "\x{5642}$IV0"=>1247,
"\x{5642}$IV1"=>7642, "\x{564C}$IV0"=>2747, "\x{564C}$IV1"=>7721,
"\x{5668}$IV0"=>1579, "\x{5668}$IV1"=>13333, "\x{5674}$IV0"=>3582,
"\x{5674}$IV1"=>13500, "\x{5678}$IV0"=>3245, "\x{5678}$IV1"=>7762,
"\x{56A5}$IV0"=>4446, "\x{56A5}$IV1"=>7822, "\x{56AE}$IV0"=>4447,
"\x{56AE}$IV1"=>7985, "\x{56AE}$IV2"=>20094, "\x{56AE}$IV3"=>20095,
"\x{56C0}$IV0"=>4454, "\x{56C0}$IV1"=>14116, "\x{56C1}$IV0"=>4452,
"\x{56C1}$IV1"=>13527, "\x{56CE}$IV0"=>4456, "\x{56CE}$IV1"=>20098,
"\x{56EE}$IV0"=>4460, "\x{56EE}$IV1"=>20099, "\x{570D}$IV0"=>4468,
"\x{570D}$IV1"=>13528, "\x{5747}$IV0"=>1737, "\x{5747}$IV1"=>13432,
"\x{576A}$IV0"=>3062, "\x{576A}$IV1"=>13940, "\x{57CE}$IV0"=>13841,
"\x{57CE}$IV1"=>2515, "\x{57D6}$IV0"=>4499, "\x{57D6}$IV1"=>20100,
"\x{57F4}$IV0"=>2533, "\x{57F4}$IV1"=>13464, "\x{57F4}$IV2"=>13843,
"\x{580B}$IV0"=>4501, "\x{580B}$IV1"=>7823, "\x{5819}$IV0"=>4502,
"\x{5819}$IV1"=>7986, "\x{5835}$IV0"=>3138, "\x{5835}$IV1"=>7753,
"\x{583D}$IV0"=>4511, "\x{583D}$IV1"=>20101, "\x{5840}$IV0"=>3597,
"\x{5840}$IV1"=>13384, "\x{5858}$IV0"=>3166, "\x{5858}$IV1"=>7757,
"\x{5859}$IV0"=>3405, "\x{5859}$IV1"=>20102, "\x{585A}$IV0"=>3049,
"\x{585A}$IV1"=>7746, "\x{585A}$IV2"=>8422, "\x{589C}$IV0"=>3042,
"\x{589C}$IV1"=>13937, "\x{58A8}$IV0"=>13387, "\x{58A8}$IV1"=>3709,
"\x{58AB}$IV0"=>4516, "\x{58AB}$IV1"=>13529, "\x{5906}$IV0"=>17469,
"\x{5906}$IV1"=>21371, "\x{591B}$IV0"=>4541, "\x{591B}$IV1"=>7987,
"\x{5927}$IV0"=>2887, "\x{5927}$IV1"=>13909, "\x{594F}$IV0"=>2775,
"\x{594F}$IV1"=>20103, "\x{5951}$IV0"=>1814, "\x{5951}$IV1"=>13739,
"\x{5951}$IV2"=>20104, "\x{5953}$IV0"=>8426, "\x{5953}$IV1"=>14289,
"\x{5960}$IV0"=>4556, "\x{5960}$IV1"=>20105, "\x{5962}$IV0"=>4555,
"\x{5962}$IV1"=>20106, "\x{5973}$IV0"=>2433, "\x{5973}$IV1"=>13828,
"\x{5984}$IV0"=>3805, "\x{5984}$IV1"=>14055, "\x{59A5}$IV0"=>2853,
"\x{59A5}$IV1"=>13903, "\x{59C9}$IV0"=>2206, "\x{59C9}$IV1"=>13452,
"\x{59DA}$IV0"=>4572, "\x{59DA}$IV1"=>13530, "\x{59EC}$IV0"=>13997,
"\x{59EC}$IV1"=>13998, "\x{59FF}$IV0"=>2207, "\x{59FF}$IV1"=>13792,
"\x{59FF}$IV2"=>13793, "\x{5A1C}$IV0"=>4576, "\x{5A1C}$IV1"=>14118,
"\x{5A29}$IV0"=>3626, "\x{5A29}$IV1"=>7791, "\x{5A36}$IV0"=>4583,
"\x{5A36}$IV1"=>13531, "\x{5A66}$IV0"=>3530, "\x{5A66}$IV1"=>14002,
"\x{5A9B}$IV0"=>3492, "\x{5A9B}$IV1"=>7784, "\x{5ABE}$IV0"=>4588,
"\x{5ABE}$IV1"=>7824, "\x{5ABE}$IV2"=>13532, "\x{5AC2}$IV0"=>4590,
"\x{5AC2}$IV1"=>14119, "\x{5ACC}$IV0"=>1871, "\x{5ACC}$IV1"=>7675,
"\x{5ADA}$IV0"=>17510, "\x{5ADA}$IV1"=>20107, "\x{5B5A}$IV0"=>4612,
"\x{5B5A}$IV1"=>20108, "\x{5B73}$IV0"=>4617, "\x{5B73}$IV1"=>20109,
"\x{5B7C}$IV0"=>14472, "\x{5B7C}$IV1"=>20110, "\x{5BB3}$IV0"=>1424,
"\x{5BB3}$IV1"=>13421, "\x{5BB3}$IV2"=>13675, "\x{5BB3}$IV3"=>20111,
"\x{5BB5}$IV0"=>2452, "\x{5BB5}$IV1"=>13831, "\x{5BC3}$IV0"=>4626,
"\x{5BC3}$IV1"=>14121, "\x{5BD2}$IV0"=>1508, "\x{5BD2}$IV1"=>13688,
"\x{5BDB}$IV0"=>1518, "\x{5BDB}$IV1"=>8436, "\x{5BE7}$IV0"=>13971,
"\x{5BE7}$IV1"=>3297, "\x{5BE8}$IV0"=>5262, "\x{5BE8}$IV1"=>14146,
"\x{5C06}$IV0"=>13832, "\x{5C06}$IV1"=>2453, "\x{5C0A}$IV0"=>2842,
"\x{5C0A}$IV1"=>13901, "\x{5C0A}$IV2"=>13902, "\x{5C0B}$IV0"=>2584,
"\x{5C0B}$IV1"=>13859, "\x{5C0E}$IV0"=>3211, "\x{5C0E}$IV1"=>13962,
"\x{5C0F}$IV0"=>2454, "\x{5C0F}$IV1"=>13833, "\x{5C0F}$IV2"=>13834,
"\x{5C28}$IV0"=>4647, "\x{5C28}$IV1"=>7988, "\x{5C51}$IV0"=>1781,
"\x{5C51}$IV1"=>7666, "\x{5C60}$IV0"=>3141, "\x{5C60}$IV1"=>7754,
"\x{5C64}$IV0"=>2778, "\x{5C64}$IV1"=>13361, "\x{5C6E}$IV0"=>16837,
"\x{5C6E}$IV1"=>4658, "\x{5D29}$IV0"=>3656, "\x{5D29}$IV1"=>14020,
"\x{5D4E}$IV0"=>4695, "\x{5D4E}$IV1"=>13533, "\x{5D87}$IV0"=>4700,
"\x{5D87}$IV1"=>13534, "\x{5DB2}$IV0"=>15269, "\x{5DB2}$IV1"=>15405,
"\x{5DC9}$IV0"=>4711, "\x{5DC9}$IV1"=>13535, "\x{5DCC}$IV0"=>1564,
"\x{5DCC}$IV1"=>13427, "\x{5DD3}$IV0"=>4713, "\x{5DD3}$IV1"=>13536,
"\x{5DE1}$IV0"=>2414, "\x{5DE1}$IV1"=>13823, "\x{5DE8}$IV0"=>1674,
"\x{5DE8}$IV1"=>13714, "\x{5DF7}$IV0"=>1981, "\x{5DF7}$IV1"=>7679,
"\x{5DFD}$IV0"=>7734, "\x{5DFD}$IV1"=>2917, "\x{5E06}$IV0"=>3413,
"\x{5E06}$IV1"=>13987, "\x{5E1D}$IV0"=>3079, "\x{5E1D}$IV1"=>13943,
"\x{5E30}$IV0"=>1596, "\x{5E30}$IV1"=>13429, "\x{5E3D}$IV0"=>3687,
"\x{5E3D}$IV1"=>14032, "\x{5E43}$IV0"=>4728, "\x{5E43}$IV1"=>20113,
"\x{5E54}$IV0"=>4732, "\x{5E54}$IV1"=>14125, "\x{5E63}$IV0"=>3598,
"\x{5E63}$IV1"=>14010, "\x{5E64}$IV0"=>4735, "\x{5E64}$IV1"=>7827,
"\x{5E73}$IV0"=>3599, "\x{5E73}$IV1"=>14011, "\x{5E7E}$IV0"=>1586,
"\x{5E7E}$IV1"=>13700, "\x{5E96}$IV0"=>3657, "\x{5E96}$IV1"=>7792,
"\x{5EA7}$IV0"=>2098, "\x{5EA7}$IV1"=>20114, "\x{5EAD}$IV0"=>3081,
"\x{5EAD}$IV1"=>13481, "\x{5EC9}$IV0"=>14095, "\x{5EC9}$IV1"=>4031,
"\x{5ECA}$IV0"=>4051, "\x{5ECA}$IV1"=>20303, "\x{5ECA}$IV2"=>13401,
"\x{5ECB}$IV0"=>15390, "\x{5ECB}$IV1"=>14510, "\x{5ECF}$IV0"=>4747,
"\x{5ECF}$IV1"=>7990, "\x{5ED0}$IV0"=>4746, "\x{5ED0}$IV1"=>7989,
"\x{5EDF}$IV0"=>3506, "\x{5EDF}$IV1"=>7786, "\x{5EE0}$IV0"=>2459,
"\x{5EE0}$IV1"=>7704, "\x{5EE3}$IV0"=>4749, "\x{5EE3}$IV1"=>14127,
"\x{5EE3}$IV2"=>20115, "\x{5EF6}$IV0"=>1286, "\x{5EF6}$IV1"=>13415,
"\x{5EF6}$IV2"=>13654, "\x{5EF7}$IV0"=>3082, "\x{5EF7}$IV1"=>13482,
"\x{5EFA}$IV0"=>1872, "\x{5EFA}$IV1"=>13436, "\x{5EFB}$IV0"=>1398,
"\x{5EFB}$IV1"=>13673, "\x{5F0A}$IV0"=>3600, "\x{5F0A}$IV1"=>14012,
"\x{5F2D}$IV0"=>4772, "\x{5F2D}$IV1"=>13537, "\x{5F31}$IV0"=>2321,
"\x{5F31}$IV1"=>13811, "\x{5F38}$IV0"=>4773, "\x{5F38}$IV1"=>20116,
"\x{5F45}$IV0"=>8370, "\x{5F45}$IV1"=>14286, "\x{5F50}$IV0"=>14521,
"\x{5F50}$IV1"=>15391, "\x{5F62}$IV0"=>1815, "\x{5F62}$IV1"=>20063,
"\x{5F69}$IV0"=>2108, "\x{5F69}$IV1"=>13783, "\x{5F6B}$IV0"=>3010,
"\x{5F6B}$IV1"=>13928, "\x{5F80}$IV0"=>1311, "\x{5F80}$IV1"=>13661,
"\x{5F98}$IV0"=>4796, "\x{5F98}$IV1"=>13538, "\x{5FA1}$IV0"=>1946,
"\x{5FA1}$IV1"=>20117, "\x{5FAE}$IV0"=>3469, "\x{5FAE}$IV1"=>13992,
"\x{5FB5}$IV0"=>13368, "\x{5FB5}$IV1"=>13929, "\x{5FBD}$IV0"=>1605,
"\x{5FBD}$IV1"=>7658, "\x{5FCD}$IV0"=>3292, "\x{5FCD}$IV1"=>13969,
"\x{5FD8}$IV0"=>3688, "\x{5FD8}$IV1"=>14033, "\x{5FD9}$IV0"=>3689,
"\x{5FD9}$IV1"=>14034, "\x{5FDD}$IV0"=>4806, "\x{5FDD}$IV1"=>20118,
"\x{6025}$IV0"=>1656, "\x{6025}$IV1"=>13712, "\x{6050}$IV0"=>1706,
"\x{6050}$IV1"=>13721, "\x{6062}$IV0"=>1402, "\x{6062}$IV1"=>7648,
"\x{6062}$IV2"=>20269, "\x{6065}$IV0"=>2959, "\x{6065}$IV1"=>13476,
"\x{6075}$IV0"=>1817, "\x{6075}$IV1"=>13740, "\x{6094}$IV0"=>13326,
"\x{6094}$IV1"=>1401, "\x{6097}$IV0"=>4845, "\x{6097}$IV1"=>7828,
"\x{6097}$IV2"=>14128, "\x{609E}$IV0"=>14541, "\x{609E}$IV1"=>21558,
"\x{60A4}$IV0"=>14542, "\x{60A4}$IV1"=>15392, "\x{60B2}$IV0"=>3445,
"\x{60B2}$IV1"=>13491, "\x{60C5}$IV0"=>2520, "\x{60C5}$IV1"=>13842,
"\x{60D8}$IV0"=>4858, "\x{60D8}$IV1"=>13539, "\x{6108}$IV0"=>3848,
"\x{6108}$IV1"=>7802, "\x{6109}$IV0"=>3847, "\x{6109}$IV1"=>14067,
"\x{610F}$IV0"=>1177, "\x{610F}$IV1"=>13639, "\x{613D}$IV0"=>4882,
"\x{613D}$IV1"=>13540, "\x{6148}$IV0"=>2250, "\x{6148}$IV1"=>20064,
"\x{614C}$IV0"=>1988, "\x{614C}$IV1"=>13764, "\x{614E}$IV0"=>2555,
"\x{614E}$IV1"=>13356, "\x{6162}$IV0"=>3755, "\x{6162}$IV1"=>20119,
"\x{6167}$IV0"=>1819, "\x{6167}$IV1"=>7669, "\x{6167}$IV2"=>13741,
"\x{6168}$IV0"=>1426, "\x{6168}$IV1"=>13328, "\x{6168}$IV2"=>13422,
"\x{6168}$IV3"=>13676, "\x{6168}$IV4"=>13677, "\x{6168}$IV5"=>13678,
"\x{618E}$IV0"=>13363, "\x{618E}$IV1"=>2816, "\x{6190}$IV0"=>4033,
"\x{6190}$IV1"=>14096, "\x{61A4}$IV0"=>3584, "\x{61A4}$IV1"=>13501,
"\x{61B2}$IV0"=>1873, "\x{61B2}$IV1"=>13750, "\x{61B2}$IV2"=>20120,
"\x{61F2}$IV0"=>3012, "\x{61F2}$IV1"=>13369, "\x{61F2}$IV2"=>13930,
"\x{61F2}$IV3"=>21072, "\x{61F8}$IV0"=>1874, "\x{61F8}$IV1"=>20121,
"\x{61FE}$IV0"=>4928, "\x{61FE}$IV1"=>13541, "\x{6210}$IV0"=>2642,
"\x{6210}$IV1"=>13867, "\x{623B}$IV0"=>3821, "\x{623B}$IV1"=>14059,
"\x{623F}$IV0"=>3690, "\x{623F}$IV1"=>14035, "\x{6240}$IV0"=>2420,
"\x{6240}$IV1"=>13826, "\x{6241}$IV0"=>4943, "\x{6241}$IV1"=>7991,
"\x{6247}$IV0"=>2708, "\x{6247}$IV1"=>13883, "\x{6248}$IV0"=>6938,
"\x{6248}$IV1"=>7874, "\x{6249}$IV0"=>3446, "\x{6249}$IV1"=>7779,
"\x{6249}$IV2"=>13492, "\x{6268}$IV0"=>4949, "\x{6268}$IV1"=>13542,
"\x{6271}$IV0"=>1147, "\x{6271}$IV1"=>13637, "\x{62B1}$IV0"=>3658,
"\x{62B1}$IV1"=>14021, "\x{62CC}$IV0"=>4969, "\x{62CC}$IV1"=>14130,
"\x{62CF}$IV0"=>4963, "\x{62CF}$IV1"=>13543, "\x{62D0}$IV0"=>1405,
"\x{62D0}$IV1"=>7649, "\x{62D2}$IV0"=>1675, "\x{62D2}$IV1"=>13715,
"\x{62D4}$IV0"=>14129, "\x{62D4}$IV1"=>4957, "\x{62F3}$IV0"=>1875,
"\x{62F3}$IV1"=>7969, "\x{62F7}$IV0"=>2043, "\x{62F7}$IV1"=>13448,
"\x{633A}$IV0"=>3086, "\x{633A}$IV1"=>20286, "\x{633D}$IV0"=>3432,
"\x{633D}$IV1"=>7778, "\x{634C}$IV0"=>2169, "\x{634C}$IV1"=>13405,
"\x{6357}$IV0"=>3033, "\x{6357}$IV1"=>7743, "\x{6367}$IV0"=>3659,
"\x{6367}$IV1"=>13507, "\x{6368}$IV0"=>2298, "\x{6368}$IV1"=>13804,
"\x{6369}$IV0"=>4999, "\x{6369}$IV1"=>7829, "\x{636E}$IV0"=>2622,
"\x{636E}$IV1"=>13469, "\x{6372}$IV0"=>1876, "\x{6372}$IV1"=>7676,
"\x{6383}$IV0"=>2783, "\x{6383}$IV1"=>13891, "\x{6388}$IV0"=>2340,
"\x{6388}$IV1"=>13814, "\x{6392}$IV0"=>3337, "\x{6392}$IV1"=>13487,
"\x{63A1}$IV0"=>2110, "\x{63A1}$IV1"=>13784, "\x{63A7}$IV0"=>1991,
"\x{63A7}$IV1"=>13766, "\x{63C3}$IV0"=>2839, "\x{63C3}$IV1"=>7975,
"\x{63C6}$IV0"=>5003, "\x{63C6}$IV1"=>14132, "\x{63F4}$IV0"=>1289,
"\x{63F4}$IV1"=>13655, "\x{6406}$IV0"=>5011, "\x{6406}$IV1"=>7830,
"\x{640F}$IV0"=>5018, "\x{640F}$IV1"=>13545, "\x{641C}$IV0"=>4986,
"\x{641C}$IV1"=>14131, "\x{6428}$IV0"=>5017, "\x{6428}$IV1"=>14133,
"\x{6442}$IV0"=>2689, "\x{6442}$IV1"=>13470, "\x{6469}$IV0"=>3726,
"\x{6469}$IV1"=>14039, "\x{646F}$IV0"=>5020, "\x{646F}$IV1"=>20264,
"\x{647A}$IV0"=>2630, "\x{647A}$IV1"=>7713, "\x{64B0}$IV0"=>2709,
"\x{64B0}$IV1"=>7716, "\x{64E2}$IV0"=>3105, "\x{64E2}$IV1"=>7749,
"\x{64F2}$IV0"=>5048, "\x{64F2}$IV1"=>13546, "\x{64F6}$IV0"=>5046,
"\x{64F6}$IV1"=>20126, "\x{651D}$IV0"=>5015, "\x{651D}$IV1"=>13544,
"\x{654F}$IV0"=>13381, "\x{654F}$IV1"=>3524, "\x{655D}$IV0"=>5070,
"\x{655D}$IV1"=>13547, "\x{655E}$IV0"=>5069, "\x{655E}$IV1"=>20129,
"\x{6562}$IV0"=>1526, "\x{6562}$IV1"=>13425, "\x{6577}$IV0"=>3537,
"\x{6577}$IV1"=>14003, "\x{6583}$IV0"=>5074, "\x{6583}$IV1"=>7832,
"\x{6587}$IV0"=>3592, "\x{6587}$IV1"=>20131, "\x{6589}$IV0"=>2666,
"\x{6589}$IV1"=>20132, "\x{658E}$IV0"=>2120, "\x{658E}$IV1"=>20134,
"\x{6590}$IV0"=>3449, "\x{6590}$IV1"=>13493, "\x{659C}$IV0"=>2300,
"\x{659C}$IV1"=>13805, "\x{65A7}$IV0"=>3538, "\x{65A7}$IV1"=>20289,
"\x{65BC}$IV0"=>1305, "\x{65BC}$IV1"=>13660, "\x{65C5}$IV0"=>3969,
"\x{65C5}$IV1"=>14088, "\x{65DF}$IV0"=>19435, "\x{65DF}$IV1"=>21694,
"\x{65E1}$IV0"=>5089, "\x{65E1}$IV1"=>20137, "\x{65E2}$IV0"=>13334,
"\x{65E2}$IV1"=>1591, "\x{660E}$IV0"=>3788, "\x{660E}$IV1"=>14052,
"\x{661E}$IV0"=>20304, "\x{661E}$IV1"=>8476, "\x{665F}$IV0"=>5109,
"\x{665F}$IV1"=>13548, "\x{665F}$IV2"=>14136, "\x{665F}$IV3"=>14137,
"\x{6666}$IV0"=>1408, "\x{6666}$IV1"=>7650, "\x{6667}$IV0"=>5107,
"\x{6667}$IV1"=>20138, "\x{6669}$IV0"=>3433, "\x{6669}$IV1"=>13989,
"\x{666E}$IV0"=>3539, "\x{666E}$IV1"=>20139, "\x{6674}$IV0"=>8481,
"\x{6674}$IV1"=>2646, "\x{6677}$IV0"=>16889, "\x{6677}$IV1"=>14609,
"\x{6681}$IV0"=>1727, "\x{6681}$IV1"=>13728, "\x{6691}$IV0"=>2421,
"\x{6691}$IV1"=>13352, "\x{6696}$IV0"=>2950, "\x{6696}$IV1"=>13918,
"\x{6697}$IV0"=>1161, "\x{6697}$IV1"=>13638, "\x{66B5}$IV0"=>17755,
"\x{66B5}$IV1"=>21722, "\x{66C1}$IV0"=>5119, "\x{66C1}$IV1"=>7992,
"\x{66C1}$IV2"=>20140, "\x{66D9}$IV0"=>2422, "\x{66D9}$IV1"=>7699,
"\x{66DC}$IV0"=>3893, "\x{66DC}$IV1"=>14077, "\x{66F4}$IV0"=>1995,
"\x{66F4}$IV1"=>13441, "\x{66F5}$IV0"=>5133, "\x{66F5}$IV1"=>14139,
"\x{66F8}$IV0"=>2427, "\x{66F8}$IV1"=>13827, "\x{66FB}$IV0"=>8369,
"\x{66FB}$IV1"=>14285, "\x{66FC}$IV0"=>4333, "\x{66FC}$IV1"=>14112,
"\x{6700}$IV0"=>2103, "\x{6700}$IV1"=>20143, "\x{6708}$IV0"=>1860,
"\x{6708}$IV1"=>13746, "\x{6709}$IV0"=>3863, "\x{6709}$IV1"=>14071,
"\x{670B}$IV0"=>3662, "\x{670B}$IV1"=>14022, "\x{670D}$IV0"=>3568,
"\x{670D}$IV1"=>14007, "\x{6715}$IV0"=>3035, "\x{6715}$IV1"=>13935,
"\x{6715}$IV2"=>13936, "\x{6717}$IV0"=>20305, "\x{6717}$IV1"=>4053,
"\x{6717}$IV2"=>8489, "\x{6717}$IV3"=>14098, "\x{671B}$IV0"=>3692,
"\x{671B}$IV1"=>14036, "\x{671B}$IV2"=>14037, "\x{671D}$IV0"=>3015,
"\x{671D}$IV1"=>13931, "\x{671F}$IV0"=>1592, "\x{671F}$IV1"=>13702,
"\x{6753}$IV0"=>2313, "\x{6753}$IV1"=>7695, "\x{6756}$IV0"=>2523,
"\x{6756}$IV1"=>20282, "\x{675E}$IV0"=>5148, "\x{675E}$IV1"=>14140,
"\x{6761}$IV0"=>2522, "\x{6761}$IV1"=>20144, "\x{677E}$IV0"=>2470,
"\x{677E}$IV1"=>13461, "\x{67A6}$IV0"=>5160, "\x{67A6}$IV1"=>7833,
"\x{67A9}$IV0"=>5155, "\x{67A9}$IV1"=>13549, "\x{67C4}$IV0"=>3601,
"\x{67C4}$IV1"=>20145, "\x{67CA}$IV0"=>3476, "\x{67CA}$IV1"=>7781,
"\x{67D4}$IV0"=>2378, "\x{67D4}$IV1"=>13457, "\x{67E7}$IV0"=>5178,
"\x{67E7}$IV1"=>13550, "\x{67F1}$IV0"=>2986, "\x{67F1}$IV1"=>13925,
"\x{6801}$IV0"=>14066, "\x{6801}$IV1"=>8494, "\x{6802}$IV0"=>3050,
"\x{6802}$IV1"=>20146, "\x{6813}$IV0"=>2710, "\x{6813}$IV1"=>7717,
"\x{681F}$IV0"=>17786, "\x{681F}$IV1"=>20065, "\x{6821}$IV0"=>1997,
"\x{6821}$IV1"=>13442, "\x{6843}$IV0"=>3175, "\x{6843}$IV1"=>13484,
"\x{6852}$IV0"=>14291, "\x{6852}$IV1"=>8492, "\x{685D}$IV0"=>3743,
"\x{685D}$IV1"=>13509, "\x{685D}$IV2"=>14046, "\x{687A}$IV0"=>14632,
"\x{687A}$IV1"=>14064, "\x{687A}$IV2"=>14065, "\x{6881}$IV0"=>3978,
"\x{6881}$IV1"=>14089, "\x{6885}$IV0"=>13375, "\x{6885}$IV1"=>3349,
"\x{688D}$IV0"=>5207, "\x{688D}$IV1"=>14142, "\x{6897}$IV0"=>1998,
"\x{6897}$IV1"=>20279, "\x{689B}$IV0"=>5198, "\x{689B}$IV1"=>7835,
"\x{689D}$IV0"=>5197, "\x{689D}$IV1"=>14141, "\x{68A2}$IV0"=>2471,
"\x{68A2}$IV1"=>7705, "\x{68C8}$IV0"=>8367, "\x{68C8}$IV1"=>14284,
"\x{68DA}$IV0"=>2920, "\x{68DA}$IV1"=>7736, "\x{690D}$IV0"=>2536,
"\x{690D}$IV1"=>13465, "\x{690D}$IV2"=>13845, "\x{6930}$IV0"=>5248,
"\x{6930}$IV1"=>13552, "\x{693D}$IV0"=>5246, "\x{693D}$IV1"=>20147,
"\x{695E}$IV0"=>5250, "\x{695E}$IV1"=>20148, "\x{6962}$IV0"=>3266,
"\x{6962}$IV1"=>7768, "\x{696B}$IV0"=>5240, "\x{696B}$IV1"=>13551,
"\x{696F}$IV0"=>2407, "\x{696F}$IV1"=>13460, "\x{6982}$IV0"=>1427,
"\x{6982}$IV1"=>13403, "\x{6982}$IV2"=>13423, "\x{6982}$IV3"=>13680,
"\x{698A}$IV0"=>2135, "\x{698A}$IV1"=>7686, "\x{6994}$IV0"=>4055,
"\x{6994}$IV1"=>7812, "\x{69A7}$IV0"=>5267, "\x{69A7}$IV1"=>13553,
"\x{69BB}$IV0"=>5265, "\x{69BB}$IV1"=>14147, "\x{69C1}$IV0"=>5258,
"\x{69C1}$IV1"=>13722, "\x{69CB}$IV0"=>1999, "\x{69CB}$IV1"=>13767,
"\x{69CC}$IV0"=>3044, "\x{69CC}$IV1"=>7744, "\x{69D9}$IV0"=>3736,
"\x{69D9}$IV1"=>14045, "\x{69EA}$IV0"=>13329, "\x{69EA}$IV1"=>13679,
"\x{69FE}$IV0"=>17850, "\x{69FE}$IV1"=>21791, "\x{6A0B}$IV0"=>3465,
"\x{6A0B}$IV1"=>7780, "\x{6A3D}$IV0"=>2924, "\x{6A3D}$IV1"=>7738,
"\x{6A44}$IV0"=>5294, "\x{6A44}$IV1"=>13554, "\x{6A55}$IV0"=>19467,
"\x{6A55}$IV1"=>21797, "\x{6A5F}$IV0"=>1595, "\x{6A5F}$IV1"=>13703,
"\x{6A73}$IV0"=>8505, "\x{6A73}$IV1"=>14292, "\x{6A8E}$IV0"=>1949,
"\x{6A8E}$IV1"=>13438, "\x{6A90}$IV0"=>5306, "\x{6A90}$IV1"=>13555,
"\x{6A9C}$IV0"=>5179, "\x{6A9C}$IV1"=>20150, "\x{6ADB}$IV0"=>7665,
"\x{6ADB}$IV1"=>1779, "\x{6ADB}$IV2"=>13737, "\x{6B04}$IV0"=>13392,
"\x{6B04}$IV1"=>3933, "\x{6B1D}$IV0"=>1239, "\x{6B1D}$IV1"=>7639,
"\x{6B21}$IV0"=>2253, "\x{6B21}$IV1"=>13799, "\x{6B21}$IV2"=>13800,
"\x{6B24}$IV0"=>14678, "\x{6B24}$IV1"=>15394, "\x{6B4E}$IV0"=>2933,
"\x{6B4E}$IV1"=>13915, "\x{6B96}$IV0"=>2537, "\x{6B96}$IV1"=>13846,
"\x{6BBA}$IV0"=>13344, "\x{6BBA}$IV1"=>2164, "\x{6BBB}$IV0"=>1450,
"\x{6BBB}$IV1"=>13424, "\x{6C08}$IV0"=>5376, "\x{6C08}$IV1"=>7993,
"\x{6C08}$IV2"=>13556, "\x{6C13}$IV0"=>5377, "\x{6C13}$IV1"=>13557,
"\x{6C38}$IV0"=>1260, "\x{6C38}$IV1"=>20154, "\x{6C3A}$IV0"=>20309,
"\x{6C3A}$IV1"=>14690, "\x{6C72}$IV0"=>1660, "\x{6C72}$IV1"=>7966,
"\x{6CAA}$IV0"=>14153, "\x{6CAA}$IV1"=>14152, "\x{6CAA}$IV2"=>20155,
"\x{6CBF}$IV0"=>13656, "\x{6CBF}$IV1"=>1290, "\x{6CBF}$IV2"=>13416,
"\x{6CE1}$IV0"=>3664, "\x{6CE1}$IV1"=>7793, "\x{6CE8}$IV0"=>2987,
"\x{6CE8}$IV1"=>13926, "\x{6CE8}$IV2"=>12869, "\x{6D3E}$IV0"=>3327,
"\x{6D3E}$IV1"=>13486, "\x{6D3E}$IV2"=>13974, "\x{6D69}$IV0"=>2002,
"\x{6D69}$IV1"=>13768, "\x{6D6E}$IV0"=>3540, "\x{6D6E}$IV1"=>14004,
"\x{6D77}$IV0"=>13327, "\x{6D77}$IV1"=>1410, "\x{6D78}$IV0"=>2561,
"\x{6D78}$IV1"=>13853, "\x{6D88}$IV0"=>2475, "\x{6D88}$IV1"=>13836,
"\x{6DE4}$IV0"=>5448, "\x{6DE4}$IV1"=>20157, "\x{6DEB}$IV0"=>1216,
"\x{6DEB}$IV1"=>7637, "\x{6DFB}$IV0"=>3124, "\x{6DFB}$IV1"=>13948,
"\x{6E08}$IV0"=>2113, "\x{6E08}$IV1"=>20159, "\x{6E1A}$IV0"=>7700,
"\x{6E1A}$IV1"=>2423, "\x{6E23}$IV0"=>5459, "\x{6E23}$IV1"=>7994,
"\x{6E23}$IV2"=>13558, "\x{6E2F}$IV0"=>2003, "\x{6E2F}$IV1"=>13769,
"\x{6E6E}$IV0"=>5453, "\x{6E6E}$IV1"=>7837, "\x{6E72}$IV0"=>5456,
"\x{6E72}$IV1"=>20160, "\x{6E7E}$IV0"=>4087, "\x{6E7E}$IV1"=>13519,
"\x{6E9D}$IV0"=>2004, "\x{6E9D}$IV1"=>7681, "\x{6EA2}$IV0"=>1202,
"\x{6EA2}$IV1"=>7635, "\x{6EA2}$IV2"=>21071, "\x{6EBA}$IV0"=>3112,
"\x{6EBA}$IV1"=>7750, "\x{6ECB}$IV0"=>2254, "\x{6ECB}$IV1"=>13801,
"\x{6ECB}$IV2"=>20161, "\x{6ED5}$IV0"=>5483, "\x{6ED5}$IV1"=>20162,
"\x{6EDB}$IV0"=>19503, "\x{6EDB}$IV1"=>20163, "\x{6EEC}$IV0"=>5491,
"\x{6EEC}$IV1"=>7995, "\x{6EFE}$IV0"=>5493, "\x{6EFE}$IV1"=>13560,
"\x{6F11}$IV0"=>5489, "\x{6F11}$IV1"=>13559, "\x{6F11}$IV2"=>14149,
"\x{6F22}$IV0"=>1533, "\x{6F22}$IV1"=>13332, "\x{6F23}$IV0"=>7809,
"\x{6F23}$IV1"=>4034, "\x{6F3E}$IV0"=>5500, "\x{6F3E}$IV1"=>13561,
"\x{6F51}$IV0"=>7776, "\x{6F51}$IV1"=>13982, "\x{6F54}$IV0"=>1855,
"\x{6F54}$IV1"=>13744, "\x{6F5B}$IV0"=>5509, "\x{6F5B}$IV1"=>20164,
"\x{6F5B}$IV2"=>20165, "\x{6F64}$IV0"=>2411, "\x{6F64}$IV1"=>20166,
"\x{6F6E}$IV0"=>13932, "\x{6F6E}$IV1"=>3016, "\x{6F74}$IV0"=>5543,
"\x{6F74}$IV1"=>20167, "\x{6F98}$IV0"=>13884, "\x{6F98}$IV1"=>14151,
"\x{6FEF}$IV0"=>2901, "\x{6FEF}$IV1"=>7731, "\x{6FF9}$IV0"=>15395,
"\x{6FF9}$IV1"=>14741, "\x{7015}$IV0"=>3520, "\x{7015}$IV1"=>7787,
"\x{701B}$IV0"=>5541, "\x{701B}$IV1"=>14154, "\x{701E}$IV0"=>3244,
"\x{701E}$IV1"=>7761, "\x{7026}$IV0"=>2995, "\x{7026}$IV1"=>7741,
"\x{7027}$IV0"=>2893, "\x{7027}$IV1"=>13911, "\x{704A}$IV0"=>20306,
"\x{704A}$IV1"=>14744, "\x{7058}$IV0"=>3263, "\x{7058}$IV1"=>7767,
"\x{7070}$IV0"=>1411, "\x{7070}$IV1"=>13674, "\x{7078}$IV0"=>1662,
"\x{7078}$IV1"=>20270, "\x{707C}$IV0"=>2314, "\x{707C}$IV1"=>7696,
"\x{70AD}$IV0"=>2936, "\x{70AD}$IV1"=>13916, "\x{7149}$IV0"=>7810,
"\x{7149}$IV1"=>4035, "\x{714E}$IV0"=>2717, "\x{714E}$IV1"=>7718,
"\x{7152}$IV0"=>14762, "\x{7152}$IV1"=>21933, "\x{7159}$IV0"=>1294,
"\x{7159}$IV1"=>13657, "\x{7162}$IV0"=>5572, "\x{7162}$IV1"=>14155,
"\x{716E}$IV0"=>13347, "\x{716E}$IV1"=>2301, "\x{717D}$IV0"=>2718,
"\x{717D}$IV1"=>7719, "\x{717D}$IV2"=>7972, "\x{7194}$IV0"=>3898,
"\x{7194}$IV1"=>7805, "\x{71B3}$IV0"=>15397, "\x{71B3}$IV1"=>14766,
"\x{71D0}$IV0"=>3997, "\x{71D0}$IV1"=>14090, "\x{71FF}$IV0"=>5595,
"\x{71FF}$IV1"=>13562, "\x{7228}$IV0"=>7839, "\x{7228}$IV1"=>5599,
"\x{722B}$IV0"=>14772, "\x{722B}$IV1"=>15398, "\x{7235}$IV0"=>13809,
"\x{7235}$IV1"=>2315, "\x{7235}$IV2"=>13808, "\x{7236}$IV0"=>3541,
"\x{7236}$IV1"=>13497, "\x{723A}$IV0"=>3832, "\x{723A}$IV1"=>20294,
"\x{723B}$IV0"=>5604, "\x{723B}$IV1"=>14156, "\x{723E}$IV0"=>2256,
"\x{723E}$IV1"=>20169, "\x{724C}$IV0"=>3341, "\x{724C}$IV1"=>7771,
"\x{7259}$IV0"=>1383, "\x{7259}$IV1"=>7965, "\x{72E1}$IV0"=>5629,
"\x{72E1}$IV1"=>20278, "\x{731C}$IV0"=>5635, "\x{731C}$IV1"=>14158,
"\x{732A}$IV0"=>8548, "\x{732A}$IV1"=>2996, "\x{7336}$IV0"=>3867,
"\x{7336}$IV1"=>14072, "\x{7336}$IV2"=>14073, "\x{7337}$IV0"=>3868,
"\x{7337}$IV1"=>7804, "\x{7337}$IV2"=>14074, "\x{7387}$IV0"=>3952,
"\x{7387}$IV1"=>14085, "\x{738B}$IV0"=>1318, "\x{738B}$IV1"=>13729,
"\x{73CA}$IV0"=>2183, "\x{73CA}$IV1"=>7691, "\x{73CA}$IV2"=>20172,
"\x{73CE}$IV0"=>5656, "\x{73CE}$IV1"=>7840, "\x{73E5}$IV0"=>5659,
"\x{73E5}$IV1"=>13563, "\x{73ED}$IV0"=>3421, "\x{73ED}$IV1"=>13489,
"\x{7422}$IV0"=>7732, "\x{7422}$IV1"=>2902, "\x{7432}$IV0"=>5667,
"\x{7432}$IV1"=>13564, "\x{745F}$IV0"=>5671, "\x{745F}$IV1"=>13565,
"\x{7462}$IV0"=>16977, "\x{7462}$IV1"=>8561, "\x{74B0}$IV0"=>1536,
"\x{74B0}$IV1"=>13689, "\x{74BD}$IV0"=>2257, "\x{74BD}$IV1"=>20173,
"\x{74CA}$IV0"=>5684, "\x{74CA}$IV1"=>14159, "\x{74D8}$IV0"=>18115,
"\x{74D8}$IV1"=>22006, "\x{74DC}$IV0"=>1245, "\x{74DC}$IV1"=>13648,
"\x{74E0}$IV0"=>5688, "\x{74E0}$IV1"=>13566, "\x{74EF}$IV0"=>14160,
"\x{74EF}$IV1"=>22010, "\x{7504}$IV0"=>5698, "\x{7504}$IV1"=>7841,
"\x{750C}$IV0"=>5701, "\x{750C}$IV1"=>13567, "\x{750D}$IV0"=>5703,
"\x{750D}$IV1"=>7842, "\x{7511}$IV0"=>2059, "\x{7511}$IV1"=>7684,
"\x{7511}$IV2"=>13778, "\x{7511}$IV3"=>20284, "\x{7515}$IV0"=>5704,
"\x{7515}$IV1"=>7843, "\x{7515}$IV2"=>20267, "\x{7526}$IV0"=>5707,
"\x{7526}$IV1"=>20283, "\x{7554}$IV0"=>3422, "\x{7554}$IV1"=>13988,
"\x{755D}$IV0"=>2634, "\x{755D}$IV1"=>20174, "\x{75BC}$IV0"=>5741,
"\x{75BC}$IV1"=>20175, "\x{75C5}$IV0"=>3508, "\x{75C5}$IV1"=>14001,
"\x{7608}$IV0"=>16987, "\x{7608}$IV1"=>20177, "\x{7626}$IV0"=>13893,
"\x{7626}$IV1"=>7725, "\x{7652}$IV0"=>3850, "\x{7652}$IV1"=>7803,
"\x{7664}$IV0"=>16988, "\x{7664}$IV1"=>20178, "\x{7669}$IV0"=>5777,
"\x{7669}$IV1"=>20179, "\x{7672}$IV0"=>5782, "\x{7672}$IV1"=>13568,
"\x{7684}$IV0"=>3108, "\x{7684}$IV1"=>13945, "\x{7693}$IV0"=>5792,
"\x{7693}$IV1"=>7844, "\x{76C6}$IV0"=>3725, "\x{76C6}$IV1"=>13508,
"\x{76CA}$IV0"=>1273, "\x{76CA}$IV1"=>8571, "\x{76D4}$IV0"=>16994,
"\x{76D4}$IV1"=>22045, "\x{76DB}$IV0"=>2653, "\x{76DB}$IV1"=>13868,
"\x{76DF}$IV0"=>3789, "\x{76DF}$IV1"=>14053, "\x{76F2}$IV0"=>3809,
"\x{76F2}$IV1"=>14057, "\x{76F4}$IV0"=>3034, "\x{76F4}$IV1"=>13934,
"\x{771E}$IV0"=>13357, "\x{771E}$IV1"=>5816, "\x{771F}$IV0"=>2565,
"\x{771F}$IV1"=>13854, "\x{7737}$IV0"=>5820, "\x{7737}$IV1"=>20181,
"\x{773A}$IV0"=>3019, "\x{773A}$IV1"=>13478, "\x{777E}$IV0"=>5829,
"\x{777E}$IV1"=>20182, "\x{778D}$IV0"=>19592, "\x{778D}$IV1"=>22062,
"\x{77A2}$IV0"=>18201, "\x{77A2}$IV1"=>22063, "\x{77A5}$IV0"=>3613,
"\x{77A5}$IV1"=>7790, "\x{77AC}$IV0"=>2400, "\x{77AC}$IV1"=>13458,
"\x{77E9}$IV0"=>1763, "\x{77E9}$IV1"=>13732, "\x{7832}$IV0"=>3666,
"\x{7832}$IV1"=>14023, "\x{783A}$IV0"=>3153, "\x{783A}$IV1"=>13951,
"\x{785D}$IV0"=>2483, "\x{785D}$IV1"=>13837, "\x{786C}$IV0"=>2007,
"\x{786C}$IV1"=>13443, "\x{787C}$IV0"=>5860, "\x{787C}$IV1"=>7845,
"\x{7891}$IV0"=>13379, "\x{7891}$IV1"=>3454, "\x{78D4}$IV0"=>5870,
"\x{78D4}$IV1"=>13570, "\x{78E8}$IV0"=>3727, "\x{78E8}$IV1"=>14042,
"\x{78EF}$IV0"=>1199, "\x{78EF}$IV1"=>13643, "\x{792A}$IV0"=>5855,
"\x{792A}$IV1"=>13569, "\x{7934}$IV0"=>17014, "\x{7934}$IV1"=>14904,
"\x{793A}$IV0"=>19130, "\x{793A}$IV1"=>2260, "\x{793C}$IV0"=>4017,
"\x{793C}$IV1"=>8579, "\x{793E}$IV0"=>2302, "\x{793E}$IV1"=>13348,
"\x{7940}$IV0"=>5886, "\x{7940}$IV1"=>14167, "\x{7941}$IV0"=>1805,
"\x{7941}$IV1"=>7668, "\x{7947}$IV0"=>1626, "\x{7947}$IV1"=>7659,
"\x{7948}$IV0"=>13335, "\x{7948}$IV1"=>1601, "\x{7949}$IV0"=>2225,
"\x{7949}$IV1"=>13345, "\x{7950}$IV0"=>13391, "\x{7950}$IV1"=>3870,
"\x{7953}$IV0"=>5892, "\x{7953}$IV1"=>14168, "\x{7953}$IV2"=>14169,
"\x{7956}$IV0"=>2758, "\x{7956}$IV1"=>13359, "\x{795D}$IV0"=>13351,
"\x{795D}$IV1"=>2389, "\x{795E}$IV0"=>8580, "\x{795E}$IV1"=>2566,
"\x{7962}$IV0"=>3296, "\x{7962}$IV1"=>7977, "\x{7965}$IV0"=>8581,
"\x{7965}$IV1"=>2485, "\x{798D}$IV0"=>13325, "\x{798D}$IV1"=>1362,
"\x{798E}$IV0"=>3091, "\x{798E}$IV1"=>13371, "\x{798F}$IV0"=>3569,
"\x{798F}$IV1"=>8583, "\x{79A7}$IV0"=>5897, "\x{79A7}$IV1"=>20183,
"\x{79AE}$IV0"=>5900, "\x{79AE}$IV1"=>14171, "\x{79B0}$IV0"=>3295,
"\x{79B0}$IV1"=>7769, "\x{79B1}$IV0"=>7758, "\x{79B1}$IV1"=>20184,
"\x{79BA}$IV0"=>5903, "\x{79BA}$IV1"=>13571, "\x{79E4}$IV0"=>3359,
"\x{79E4}$IV1"=>7773, "\x{7A0B}$IV0"=>3092, "\x{7A0B}$IV1"=>13944,
"\x{7A17}$IV0"=>3477, "\x{7A17}$IV1"=>7782, "\x{7A19}$IV0"=>5913,
"\x{7A19}$IV1"=>13572, "\x{7A31}$IV0"=>5917, "\x{7A31}$IV1"=>7846,
"\x{7A40}$IV0"=>13343, "\x{7A40}$IV1"=>2052, "\x{7A60}$IV0"=>20310,
"\x{7A60}$IV1"=>14926, "\x{7A74}$IV0"=>1856, "\x{7A74}$IV1"=>13434,
"\x{7A74}$IV2"=>13745, "\x{7A7A}$IV0"=>1773, "\x{7A7A}$IV1"=>13735,
"\x{7A7F}$IV0"=>2720, "\x{7A7F}$IV1"=>7973, "\x{7A81}$IV0"=>3237,
"\x{7A81}$IV1"=>13373, "\x{7A95}$IV0"=>5933, "\x{7A95}$IV1"=>13573,
"\x{7A97}$IV0"=>5932, "\x{7A97}$IV1"=>7996, "\x{7AAE}$IV0"=>1665,
"\x{7AAE}$IV1"=>13431, "\x{7ABE}$IV0"=>18271, "\x{7ABE}$IV1"=>20185,
"\x{7AC6}$IV0"=>14934, "\x{7AC6}$IV1"=>15399, "\x{7AC8}$IV0"=>5937,
"\x{7AC8}$IV1"=>20285, "\x{7B08}$IV0"=>1666, "\x{7B08}$IV1"=>7967,
"\x{7B08}$IV2"=>20263, "\x{7B51}$IV0"=>2972, "\x{7B51}$IV1"=>13923,
"\x{7B75}$IV0"=>5976, "\x{7B75}$IV1"=>20266, "\x{7B99}$IV0"=>5994,
"\x{7B99}$IV1"=>7848, "\x{7BAD}$IV0"=>2721, "\x{7BAD}$IV1"=>7974,
"\x{7BB8}$IV0"=>3384, "\x{7BB8}$IV1"=>7775, "\x{7BC0}$IV0"=>2693,
"\x{7BC0}$IV1"=>13358, "\x{7BC0}$IV2"=>13879, "\x{7BC7}$IV0"=>3619,
"\x{7BC7}$IV1"=>7979, "\x{7BC9}$IV0"=>2969, "\x{7BC9}$IV1"=>13921,
"\x{7BDD}$IV0"=>6001, "\x{7BDD}$IV1"=>7997, "\x{7BE0}$IV0"=>2288,
"\x{7BE0}$IV1"=>20186, "\x{7C14}$IV0"=>6004, "\x{7C14}$IV1"=>14175,
"\x{7C3E}$IV0"=>4036, "\x{7C3E}$IV1"=>7981, "\x{7C3E}$IV2"=>20265,
"\x{7C3F}$IV0"=>3645, "\x{7C3F}$IV1"=>14018, "\x{7C4D}$IV0"=>2678,
"\x{7C4D}$IV1"=>13878, "\x{7C50}$IV0"=>6028, "\x{7C50}$IV1"=>14177,
"\x{7C50}$IV2"=>20187, "\x{7C58}$IV0"=>6029, "\x{7C58}$IV1"=>14178,
"\x{7C69}$IV0"=>18316, "\x{7C69}$IV1"=>22186, "\x{7C7E}$IV0"=>3822,
"\x{7C7E}$IV1"=>7800, "\x{7C7E}$IV2"=>20293, "\x{7C82}$IV0"=>1791,
"\x{7C82}$IV1"=>20272, "\x{7C89}$IV0"=>3588, "\x{7C89}$IV1"=>13502,
"\x{7C90}$IV0"=>6037, "\x{7C90}$IV1"=>7849, "\x{7CAE}$IV0"=>6047,
"\x{7CAE}$IV1"=>7850, "\x{7CBE}$IV0"=>8590, "\x{7CBE}$IV1"=>2654,
"\x{7CD6}$IV0"=>13956, "\x{7CD6}$IV1"=>3190, "\x{7CF2}$IV0"=>6059,
"\x{7CF2}$IV1"=>13574, "\x{7D04}$IV0"=>3839, "\x{7D04}$IV1"=>14062,
"\x{7D09}$IV0"=>14970, "\x{7D09}$IV1"=>20188, "\x{7D0B}$IV0"=>3826,
"\x{7D0B}$IV1"=>14060, "\x{7D0D}$IV0"=>3314, "\x{7D0D}$IV1"=>13972,
"\x{7D1A}$IV0"=>1667, "\x{7D1A}$IV1"=>13713, "\x{7D1B}$IV0"=>3590,
"\x{7D1B}$IV1"=>13503, "\x{7D42}$IV0"=>2356, "\x{7D42}$IV1"=>13816,
"\x{7D46}$IV0"=>6074, "\x{7D46}$IV1"=>14179, "\x{7D5C}$IV0"=>17041,
"\x{7D5C}$IV1"=>8592, "\x{7D5E}$IV0"=>2012, "\x{7D5E}$IV1"=>13444,
"\x{7D63}$IV0"=>6082, "\x{7D63}$IV1"=>14180, "\x{7D73}$IV0"=>6075,
"\x{7D73}$IV1"=>13575, "\x{7D9B}$IV0"=>6088, "\x{7D9B}$IV1"=>7851,
"\x{7D9F}$IV0"=>6101, "\x{7D9F}$IV1"=>7853, "\x{7DAE}$IV0"=>6090,
"\x{7DAE}$IV1"=>7852, "\x{7DB2}$IV0"=>3810, "\x{7DB2}$IV1"=>20189,
"\x{7DB2}$IV2"=>20190, "\x{7DCB}$IV0"=>3456, "\x{7DCB}$IV1"=>13494,
"\x{7DCF}$IV0"=>2799, "\x{7DCF}$IV1"=>13472, "\x{7DDD}$IV0"=>6104,
"\x{7DDD}$IV1"=>13576, "\x{7DE8}$IV0"=>3620, "\x{7DE8}$IV1"=>14015,
"\x{7DE9}$IV0"=>1543, "\x{7DE9}$IV1"=>13690, "\x{7DEF}$IV0"=>1186,
"\x{7DEF}$IV1"=>13410, "\x{7DF4}$IV0"=>13399, "\x{7DF4}$IV1"=>4037,
"\x{7E09}$IV0"=>6117, "\x{7E09}$IV1"=>18366, "\x{7E1B}$IV0"=>3377,
"\x{7E1B}$IV1"=>13979, "\x{7E22}$IV0"=>6119, "\x{7E22}$IV1"=>14181,
"\x{7E22}$IV2"=>14182, "\x{7E2B}$IV0"=>3667, "\x{7E2B}$IV1"=>14024,
"\x{7E35}$IV0"=>6123, "\x{7E35}$IV1"=>13577, "\x{7E35}$IV2"=>14184,
"\x{7E41}$IV0"=>3423, "\x{7E41}$IV1"=>13376, "\x{7E43}$IV0"=>6125,
"\x{7E43}$IV1"=>14185, "\x{7E6D}$IV0"=>3752, "\x{7E6D}$IV1"=>14049,
"\x{7E8C}$IV0"=>6147, "\x{7E8C}$IV1"=>14186, "\x{7F3E}$IV0"=>18382,
"\x{7F3E}$IV1"=>20191, "\x{7F50}$IV0"=>6162, "\x{7F50}$IV1"=>14187,
"\x{7F61}$IV0"=>15001, "\x{7F61}$IV1"=>15400, "\x{7F6A}$IV0"=>2129,
"\x{7F6A}$IV1"=>13449, "\x{7F6E}$IV0"=>2964, "\x{7F6E}$IV1"=>13920,
"\x{7F72}$IV0"=>13353, "\x{7F72}$IV1"=>2426, "\x{7F80}$IV0"=>19686,
"\x{7F80}$IV1"=>22234, "\x{7F8A}$IV0"=>14078, "\x{7F8A}$IV1"=>3901,
"\x{7FA1}$IV0"=>8598, "\x{7FA1}$IV1"=>13885, "\x{7FAE}$IV0"=>6187,
"\x{7FAE}$IV1"=>13578, "\x{7FBD}$IV0"=>8599, "\x{7FBD}$IV1"=>1227,
"\x{7FC1}$IV0"=>1319, "\x{7FC1}$IV1"=>13418, "\x{7FC1}$IV2"=>13662,
"\x{7FC5}$IV0"=>6191, "\x{7FC5}$IV1"=>14191, "\x{7FC6}$IV0"=>6192,
"\x{7FC6}$IV1"=>14192, "\x{7FCC}$IV0"=>3916, "\x{7FCC}$IV1"=>14081,
"\x{7FD2}$IV0"=>2358, "\x{7FD2}$IV1"=>13817, "\x{7FD4}$IV0"=>6195,
"\x{7FD4}$IV1"=>7854, "\x{7FE0}$IV0"=>2607, "\x{7FE0}$IV1"=>7712,
"\x{7FE1}$IV0"=>6196, "\x{7FE1}$IV1"=>13579, "\x{7FE1}$IV2"=>20192,
"\x{7FE9}$IV0"=>6198, "\x{7FE9}$IV1"=>7998, "\x{7FE9}$IV2"=>14193,
"\x{7FEB}$IV0"=>1569, "\x{7FEB}$IV1"=>7657, "\x{7FF0}$IV0"=>1545,
"\x{7FF0}$IV1"=>7656, "\x{7FFB}$IV0"=>3723, "\x{7FFB}$IV1"=>14040,
"\x{7FFC}$IV0"=>3917, "\x{7FFC}$IV1"=>13512, "\x{7FFC}$IV2"=>14082,
"\x{8000}$IV0"=>3902, "\x{8000}$IV1"=>7806, "\x{8003}$IV0"=>2015,
"\x{8003}$IV1"=>13445, "\x{8005}$IV0"=>2304, "\x{8005}$IV1"=>13349,
"\x{8012}$IV0"=>6205, "\x{8012}$IV1"=>20193, "\x{8015}$IV0"=>2014,
"\x{8015}$IV1"=>13770, "\x{8017}$IV0"=>3811, "\x{8017}$IV1"=>14058,
"\x{8036}$IV0"=>3833, "\x{8036}$IV1"=>13511, "\x{8056}$IV0"=>2655,
"\x{8056}$IV1"=>13869, "\x{805A}$IV0"=>6217, "\x{805A}$IV1"=>13580,
"\x{805F}$IV0"=>6218, "\x{805F}$IV1"=>13581, "\x{8061}$IV0"=>2801,
"\x{8061}$IV1"=>13473, "\x{806F}$IV0"=>4038, "\x{806F}$IV1"=>13517,
"\x{8070}$IV0"=>6223, "\x{8070}$IV1"=>13583, "\x{8071}$IV0"=>15019,
"\x{8071}$IV1"=>15401, "\x{8073}$IV0"=>6221, "\x{8073}$IV1"=>13582,
"\x{8074}$IV0"=>3020, "\x{8074}$IV1"=>13479, "\x{8076}$IV0"=>6224,
"\x{8076}$IV1"=>13584, "\x{8077}$IV0"=>2540, "\x{8077}$IV1"=>13466,
"\x{807E}$IV0"=>4062, "\x{807E}$IV1"=>13518, "\x{8087}$IV0"=>3385,
"\x{8087}$IV1"=>13980, "\x{8089}$IV0"=>3281, "\x{8089}$IV1"=>13967,
"\x{8096}$IV0"=>2491, "\x{8096}$IV1"=>13838, "\x{809E}$IV0"=>15021,
"\x{809E}$IV1"=>15402, "\x{80A9}$IV0"=>1886, "\x{80A9}$IV1"=>13752,
"\x{80BA}$IV0"=>3343, "\x{80BA}$IV1"=>13975, "\x{80D6}$IV0"=>6243,
"\x{80D6}$IV1"=>20195, "\x{80DE}$IV0"=>3668, "\x{80DE}$IV1"=>14025,
"\x{8106}$IV0"=>2668, "\x{8106}$IV1"=>13876, "\x{8108}$IV0"=>3770,
"\x{8108}$IV1"=>13510, "\x{8108}$IV2"=>14051, "\x{8109}$IV0"=>6244,
"\x{8109}$IV1"=>20196, "\x{8129}$IV0"=>6248, "\x{8129}$IV1"=>20197,
"\x{8153}$IV0"=>6255, "\x{8153}$IV1"=>13585, "\x{8154}$IV0"=>2018,
"\x{8154}$IV1"=>13771, "\x{8170}$IV0"=>2058, "\x{8170}$IV1"=>13777,
"\x{8171}$IV0"=>6258, "\x{8171}$IV1"=>20275, "\x{817F}$IV0"=>2876,
"\x{817F}$IV1"=>7728, "\x{818A}$IV0"=>6265, "\x{818A}$IV1"=>13586,
"\x{81B5}$IV0"=>6276, "\x{81B5}$IV1"=>13587, "\x{81CD}$IV0"=>6284,
"\x{81CD}$IV1"=>13588, "\x{81ED}$IV0"=>2359, "\x{81ED}$IV1"=>13350,
"\x{8200}$IV0"=>19722, "\x{8200}$IV1"=>22287, "\x{820C}$IV0"=>2697,
"\x{820C}$IV1"=>20198, "\x{8218}$IV0"=>1560, "\x{8218}$IV1"=>13695,
"\x{821B}$IV0"=>2726, "\x{821B}$IV1"=>20199, "\x{821C}$IV0"=>2402,
"\x{821C}$IV1"=>13459, "\x{821F}$IV0"=>2360, "\x{821F}$IV1"=>13747,
"\x{822E}$IV0"=>6319, "\x{822E}$IV1"=>7855, "\x{8239}$IV0"=>2727,
"\x{8239}$IV1"=>13471, "\x{8239}$IV2"=>13886, "\x{8240}$IV0"=>6308,
"\x{8240}$IV1"=>20200, "\x{8247}$IV0"=>3094, "\x{8247}$IV1"=>13483,
"\x{8258}$IV0"=>6310, "\x{8258}$IV1"=>14196, "\x{8279}$IV0"=>14197,
"\x{8279}$IV1"=>14199, "\x{8279}$IV2"=>14198, "\x{828D}$IV0"=>6324,
"\x{828D}$IV1"=>7856, "\x{8292}$IV0"=>6325, "\x{8292}$IV1"=>20292,
"\x{82A6}$IV0"=>1142, "\x{82A6}$IV1"=>7961, "\x{82B1}$IV0"=>1366,
"\x{82B1}$IV1"=>13666, "\x{82BD}$IV0"=>13670, "\x{82BD}$IV1"=>1386,
"\x{82BD}$IV2"=>13419, "\x{82C5}$IV0"=>1503, "\x{82C5}$IV1"=>13687,
"\x{82D2}$IV0"=>6333, "\x{82D2}$IV1"=>7857, "\x{82E3}$IV0"=>6331,
"\x{82E3}$IV1"=>14200, "\x{8323}$IV0"=>6365, "\x{8323}$IV1"=>7858,
"\x{8328}$IV0"=>1205, "\x{8328}$IV1"=>7962, "\x{8352}$IV0"=>2021,
"\x{8352}$IV1"=>13772, "\x{8375}$IV0"=>6372, "\x{8375}$IV1"=>7859,
"\x{83BD}$IV0"=>6392, "\x{83BD}$IV1"=>14204, "\x{83D3}$IV0"=>1371,
"\x{83D3}$IV1"=>13667, "\x{83D4}$IV0"=>18501, "\x{83D4}$IV1"=>20202,
"\x{83DC}$IV0"=>2122, "\x{83DC}$IV1"=>13786, "\x{83DF}$IV0"=>3147,
"\x{83DF}$IV1"=>7755, "\x{83DF}$IV2"=>7976, "\x{83DF}$IV3"=>20201,
"\x{83F2}$IV0"=>6388, "\x{83F2}$IV1"=>13589, "\x{840C}$IV0"=>3670,
"\x{840C}$IV1"=>14026, "\x{840F}$IV0"=>15060, "\x{840F}$IV1"=>20203,
"\x{8420}$IV0"=>6391, "\x{8420}$IV1"=>14203, "\x{8422}$IV0"=>6390,
"\x{8422}$IV1"=>7999, "\x{8457}$IV0"=>2998, "\x{8457}$IV1"=>13367,
"\x{845B}$IV0"=>1481, "\x{845B}$IV1"=>7652, "\x{845C}$IV0"=>18514,
"\x{845C}$IV1"=>22341, "\x{847A}$IV0"=>3562, "\x{847A}$IV1"=>13498,
"\x{84EA}$IV0"=>18530, "\x{84EA}$IV1"=>20205, "\x{84EC}$IV0"=>3671,
"\x{84EC}$IV1"=>7794, "\x{84EE}$IV0"=>7811, "\x{84EE}$IV1"=>4039,
"\x{84F4}$IV0"=>6428, "\x{84F4}$IV1"=>14205, "\x{8511}$IV0"=>3614,
"\x{8511}$IV1"=>14013, "\x{8517}$IV0"=>6429, "\x{8517}$IV1"=>7860,
"\x{853D}$IV0"=>3603, "\x{853D}$IV1"=>7789, "\x{853D}$IV2"=>13505,
"\x{8543}$IV0"=>3437, "\x{8543}$IV1"=>13990, "\x{8551}$IV0"=>18541,
"\x{8551}$IV1"=>20207, "\x{8555}$IV0"=>6443, "\x{8555}$IV1"=>13590,
"\x{855D}$IV0"=>19750, "\x{855D}$IV1"=>22372, "\x{8563}$IV0"=>6437,
"\x{8563}$IV1"=>20208, "\x{8584}$IV0"=>3372, "\x{8584}$IV1"=>13977,
"\x{8587}$IV0"=>6454, "\x{8587}$IV1"=>14207, "\x{85A9}$IV0"=>2165,
"\x{85A9}$IV1"=>7688, "\x{85AF}$IV0"=>2428, "\x{85AF}$IV1"=>7701,
"\x{85CF}$IV0"=>6461, "\x{85CF}$IV1"=>20209, "\x{85D5}$IV0"=>6464,
"\x{85D5}$IV1"=>13591, "\x{85E4}$IV0"=>3195, "\x{85E4}$IV1"=>13957,
"\x{85F7}$IV0"=>2429, "\x{85F7}$IV1"=>7702, "\x{8612}$IV0"=>15077,
"\x{8612}$IV1"=>8612, "\x{8612}$IV2"=>21073, "\x{862D}$IV0"=>3936,
"\x{862D}$IV1"=>14084, "\x{864E}$IV0"=>1931, "\x{864E}$IV1"=>20210,
"\x{8650}$IV0"=>1646, "\x{8650}$IV1"=>13708, "\x{8654}$IV0"=>6481,
"\x{8654}$IV1"=>20274, "\x{865C}$IV0"=>13394, "\x{865C}$IV1"=>3970,
"\x{865E}$IV0"=>1771, "\x{865E}$IV1"=>13734, "\x{8662}$IV0"=>17107,
"\x{8662}$IV1"=>20211, "\x{868A}$IV0"=>1379, "\x{868A}$IV1"=>20212,
"\x{86DB}$IV0"=>6504, "\x{86DB}$IV1"=>13406, "\x{86F8}$IV0"=>2909,
"\x{86F8}$IV1"=>7733, "\x{8703}$IV0"=>6510, "\x{8703}$IV1"=>20296,
"\x{871A}$IV0"=>6523, "\x{871A}$IV1"=>13592, "\x{8737}$IV0"=>6519,
"\x{8737}$IV1"=>14210, "\x{873B}$IV0"=>6520, "\x{873B}$IV1"=>14211,
"\x{8755}$IV0"=>2544, "\x{8755}$IV1"=>7709, "\x{8759}$IV0"=>6533,
"\x{8759}$IV1"=>8000, "\x{8782}$IV0"=>6540, "\x{8782}$IV1"=>7862,
"\x{87A3}$IV0"=>19767, "\x{87A3}$IV1"=>22442, "\x{87BD}$IV0"=>6543,
"\x{87BD}$IV1"=>14213, "\x{87D2}$IV0"=>6562, "\x{87D2}$IV1"=>7863,
"\x{87D2}$IV2"=>8002, "\x{8803}$IV0"=>20312, "\x{8803}$IV1"=>15107,
"\x{8805}$IV0"=>6537, "\x{8805}$IV1"=>14212, "\x{8805}$IV2"=>20295,
"\x{880E}$IV0"=>6561, "\x{880E}$IV1"=>8001, "\x{8836}$IV0"=>6569,
"\x{8836}$IV1"=>13593, "\x{8836}$IV2"=>14215, "\x{8842}$IV0"=>6574,
"\x{8842}$IV1"=>20213, "\x{8846}$IV0"=>2362, "\x{8846}$IV1"=>13818,
"\x{884B}$IV0"=>19777, "\x{884B}$IV1"=>22467, "\x{8853}$IV0"=>2395,
"\x{8853}$IV1"=>13821, "\x{885B}$IV0"=>1268, "\x{885B}$IV1"=>13414,
"\x{885E}$IV0"=>6577, "\x{885E}$IV1"=>13651, "\x{8863}$IV0"=>1189,
"\x{8863}$IV1"=>13640, "\x{8870}$IV0"=>2608, "\x{8870}$IV1"=>13863,
"\x{8877}$IV0"=>2989, "\x{8877}$IV1"=>20214, "\x{889E}$IV0"=>6582,
"\x{889E}$IV1"=>13594, "\x{88D8}$IV0"=>6601, "\x{88D8}$IV1"=>13595,
"\x{88F4}$IV0"=>6607, "\x{88F4}$IV1"=>13596, "\x{890A}$IV0"=>6612,
"\x{890A}$IV1"=>7864, "\x{8910}$IV0"=>1482, "\x{8910}$IV1"=>13331,
"\x{891C}$IV0"=>8360, "\x{891C}$IV1"=>14283, "\x{892B}$IV0"=>6618,
"\x{892B}$IV1"=>13597, "\x{893B}$IV0"=>6621, "\x{893B}$IV1"=>13598,
"\x{8941}$IV0"=>6619, "\x{8941}$IV1"=>20215, "\x{8956}$IV0"=>1320,
"\x{8956}$IV1"=>7645, "\x{896A}$IV0"=>6631, "\x{896A}$IV1"=>13599,
"\x{896F}$IV0"=>6632, "\x{896F}$IV1"=>13600, "\x{8981}$IV0"=>3905,
"\x{8981}$IV1"=>14079, "\x{8986}$IV0"=>3572, "\x{8986}$IV1"=>14008,
"\x{8987}$IV0"=>3324, "\x{8987}$IV1"=>13973, "\x{8996}$IV0"=>2233,
"\x{8996}$IV1"=>13346, "\x{89AA}$IV0"=>2572, "\x{89AA}$IV1"=>13467,
"\x{89AF}$IV0"=>6645, "\x{89AF}$IV1"=>7865, "\x{89BD}$IV0"=>6648,
"\x{89BD}$IV1"=>14218, "\x{89D2}$IV0"=>13682, "\x{89D2}$IV1"=>1455,
"\x{8A0A}$IV0"=>2588, "\x{8A0A}$IV1"=>13860, "\x{8A0A}$IV2"=>13861,
"\x{8A12}$IV0"=>8616, "\x{8A12}$IV1"=>14295, "\x{8A1D}$IV0"=>6662,
"\x{8A1D}$IV1"=>13601, "\x{8A1D}$IV2"=>20268, "\x{8A1F}$IV0"=>2497,
"\x{8A1F}$IV1"=>13462, "\x{8A3B}$IV0"=>2990, "\x{8A3B}$IV1"=>7740,
"\x{8A55}$IV0"=>3504, "\x{8A55}$IV1"=>13999, "\x{8A6E}$IV0"=>2729,
"\x{8A6E}$IV1"=>7720, "\x{8A8D}$IV0"=>3293, "\x{8A8D}$IV1"=>13970,
"\x{8A95}$IV0"=>2944, "\x{8A95}$IV1"=>13475, "\x{8A95}$IV2"=>13917,
"\x{8AA0}$IV0"=>2659, "\x{8AA0}$IV1"=>13871, "\x{8AA4}$IV0"=>1953,
"\x{8AA4}$IV1"=>13762, "\x{8AB9}$IV0"=>3460, "\x{8AB9}$IV1"=>13495,
"\x{8ABF}$IV0"=>3024, "\x{8ABF}$IV1"=>13933, "\x{8ACB}$IV0"=>2661,
"\x{8ACB}$IV1"=>13872, "\x{8ADB}$IV0"=>6698, "\x{8ADB}$IV1"=>14219,
"\x{8ADE}$IV0"=>6697, "\x{8ADE}$IV1"=>7866, "\x{8AED}$IV0"=>14068,
"\x{8AED}$IV1"=>3851, "\x{8AEE}$IV0"=>2238, "\x{8AEE}$IV1"=>13795,
"\x{8AEE}$IV2"=>13796, "\x{8AF8}$IV0"=>8622, "\x{8AF8}$IV1"=>2430,
"\x{8AFA}$IV0"=>1909, "\x{8AFA}$IV1"=>7678, "\x{8B01}$IV0"=>13321,
"\x{8B01}$IV1"=>1276, "\x{8B04}$IV0"=>3197, "\x{8B04}$IV1"=>13958,
"\x{8B0E}$IV0"=>3262, "\x{8B0E}$IV1"=>7766, "\x{8B19}$IV0"=>1888,
"\x{8B19}$IV1"=>13753, "\x{8B1B}$IV0"=>2024, "\x{8B1B}$IV1"=>13773,
"\x{8B1D}$IV0"=>2305, "\x{8B1D}$IV1"=>13453, "\x{8B2C}$IV0"=>3495,
"\x{8B2C}$IV1"=>7785, "\x{8B39}$IV0"=>13339, "\x{8B39}$IV1"=>1752,
"\x{8B3E}$IV0"=>6711, "\x{8B3E}$IV1"=>14220, "\x{8B41}$IV0"=>6713,
"\x{8B41}$IV1"=>7867, "\x{8B56}$IV0"=>6718, "\x{8B56}$IV1"=>20216,
"\x{8B56}$IV2"=>20217, "\x{8B5A}$IV0"=>6720, "\x{8B5A}$IV1"=>14221,
"\x{8B5C}$IV0"=>3546, "\x{8B5C}$IV1"=>20218, "\x{8B7F}$IV0"=>8625,
"\x{8B7F}$IV1"=>21074, "\x{8C6A}$IV0"=>2045, "\x{8C6A}$IV1"=>20221,
"\x{8C79}$IV0"=>3505, "\x{8C79}$IV1"=>20222, "\x{8C9B}$IV0"=>18713,
"\x{8C9B}$IV1"=>22583, "\x{8CA0}$IV0"=>3547, "\x{8CA0}$IV1"=>14005,
"\x{8CA0}$IV2"=>14006, "\x{8CA7}$IV0"=>3521, "\x{8CA7}$IV1"=>13496,
"\x{8CA8}$IV0"=>1375, "\x{8CA8}$IV1"=>13668, "\x{8CAB}$IV0"=>1551,
"\x{8CAB}$IV1"=>13426, "\x{8CC7}$IV0"=>2239, "\x{8CC7}$IV1"=>13797,
"\x{8CC7}$IV2"=>13798, "\x{8CCA}$IV0"=>2833, "\x{8CCA}$IV1"=>13900,
"\x{8CCA}$IV2"=>20223, "\x{8CD3}$IV0"=>13380, "\x{8CD3}$IV1"=>3522,
"\x{8CED}$IV0"=>3148, "\x{8CED}$IV1"=>7756, "\x{8CFC}$IV0"=>2026,
"\x{8CFC}$IV1"=>13446, "\x{8CFC}$IV2"=>13774, "\x{8D05}$IV0"=>6773,
"\x{8D05}$IV1"=>13602, "\x{8D08}$IV0"=>2819, "\x{8D08}$IV1"=>13364,
"\x{8D0F}$IV0"=>6776, "\x{8D0F}$IV1"=>13603, "\x{8D67}$IV0"=>6784,
"\x{8D67}$IV1"=>20224, "\x{8D70}$IV0"=>2808, "\x{8D70}$IV1"=>13894,
"\x{8D73}$IV0"=>6787, "\x{8D73}$IV1"=>14222, "\x{8D77}$IV0"=>1609,
"\x{8D77}$IV1"=>13704, "\x{8D99}$IV0"=>6789, "\x{8D99}$IV1"=>14223,
"\x{8DDA}$IV0"=>6794, "\x{8DDA}$IV1"=>7868, "\x{8DDD}$IV0"=>1681,
"\x{8DDD}$IV1"=>13716, "\x{8DF3}$IV0"=>3027, "\x{8DF3}$IV1"=>13480,
"\x{8E09}$IV0"=>6805, "\x{8E09}$IV1"=>7869, "\x{8E34}$IV0"=>6814,
"\x{8E34}$IV1"=>14225, "\x{8E4A}$IV0"=>6815, "\x{8E4A}$IV1"=>14226,
"\x{8E8D}$IV0"=>3842, "\x{8E8D}$IV1"=>14063, "\x{8E91}$IV0"=>6837,
"\x{8E91}$IV1"=>13605, "\x{8EA1}$IV0"=>6841, "\x{8EA1}$IV1"=>13606,
"\x{8ECC}$IV0"=>1610, "\x{8ECC}$IV1"=>13430, "\x{8ED4}$IV0"=>20066,
"\x{8ED4}$IV1"=>15178, "\x{8F03}$IV0"=>1457, "\x{8F03}$IV1"=>20226,
"\x{8F13}$IV0"=>6861, "\x{8F13}$IV1"=>7870, "\x{8F29}$IV0"=>3344,
"\x{8F29}$IV1"=>13488, "\x{8F2F}$IV0"=>2366, "\x{8F2F}$IV1"=>13456,
"\x{8F38}$IV0"=>3852, "\x{8F38}$IV1"=>14069, "\x{8F44}$IV0"=>1483,
"\x{8F44}$IV1"=>13685, "\x{8F44}$IV2"=>20227, "\x{8FB6}$IV0"=>15184,
"\x{8FB6}$IV1"=>15403, "\x{8FBB}$IV0"=>3056, "\x{8FBB}$IV1"=>8267,
"\x{8FBC}$IV0"=>2064, "\x{8FBC}$IV1"=>13779, "\x{8FBF}$IV0"=>2919,
"\x{8FBF}$IV1"=>7735, "\x{8FC2}$IV0"=>1228, "\x{8FC2}$IV1"=>7638,
"\x{8FC4}$IV0"=>3750, "\x{8FC4}$IV1"=>7980, "\x{8FC5}$IV0"=>2589,
"\x{8FC5}$IV1"=>13862, "\x{8FC5}$IV2"=>20228, "\x{8FC6}$IV0"=>18759,
"\x{8FC6}$IV1"=>15185, "\x{8FCE}$IV0"=>1844, "\x{8FCE}$IV1"=>13742,
"\x{8FD1}$IV0"=>1753, "\x{8FD1}$IV1"=>13730, "\x{8FD4}$IV0"=>3622,
"\x{8FD4}$IV1"=>14016, "\x{8FD4}$IV2"=>20229, "\x{8FE6}$IV0"=>1376,
"\x{8FE6}$IV1"=>7647, "\x{8FE9}$IV0"=>3278, "\x{8FE9}$IV1"=>7872,
"\x{8FEA}$IV0"=>6891, "\x{8FEA}$IV1"=>7871, "\x{8FEB}$IV0"=>3373,
"\x{8FEB}$IV1"=>13978, "\x{8FED}$IV0"=>3117, "\x{8FED}$IV1"=>13947,
"\x{8FEF}$IV0"=>6892, "\x{8FEF}$IV1"=>14227, "\x{8FF0}$IV0"=>2396,
"\x{8FF0}$IV1"=>13822, "\x{8FF6}$IV0"=>15188, "\x{8FF6}$IV1"=>20230,
"\x{8FF7}$IV0"=>3790, "\x{8FF7}$IV1"=>14054, "\x{8FFA}$IV0"=>6897,
"\x{8FFA}$IV1"=>14229, "\x{8FFD}$IV0"=>3045, "\x{8FFD}$IV1"=>13938,
"\x{9000}$IV0"=>2880, "\x{9000}$IV1"=>13905, "\x{9001}$IV0"=>2809,
"\x{9001}$IV1"=>13895, "\x{9003}$IV0"=>3200, "\x{9003}$IV1"=>13485,
"\x{9003}$IV2"=>13959, "\x{9006}$IV0"=>1647, "\x{9006}$IV1"=>13709,
"\x{900E}$IV0"=>6914, "\x{900E}$IV1"=>13608, "\x{900F}$IV0"=>3201,
"\x{900F}$IV1"=>13960, "\x{9010}$IV0"=>2974, "\x{9010}$IV1"=>13924,
"\x{9014}$IV0"=>3149, "\x{9014}$IV1"=>13950, "\x{9017}$IV0"=>2598,
"\x{9017}$IV1"=>7711, "\x{9019}$IV0"=>3357, "\x{9019}$IV1"=>7772,
"\x{901A}$IV0"=>3048, "\x{901A}$IV1"=>13939, "\x{901D}$IV0"=>2662,
"\x{901D}$IV1"=>7714, "\x{901E}$IV0"=>6902, "\x{901E}$IV1"=>14230,
"\x{901F}$IV0"=>2830, "\x{901F}$IV1"=>13899, "\x{9020}$IV0"=>2820,
"\x{9020}$IV1"=>13897, "\x{9022}$IV0"=>1133, "\x{9022}$IV1"=>8266,
"\x{9022}$IV2"=>13408, "\x{9023}$IV0"=>14097, "\x{9023}$IV1"=>4040,
"\x{902E}$IV0"=>2881, "\x{902E}$IV1"=>13906, "\x{9031}$IV0"=>2367,
"\x{9031}$IV1"=>13819, "\x{9032}$IV0"=>2576, "\x{9032}$IV1"=>13855,
"\x{9035}$IV0"=>6907, "\x{9035}$IV1"=>14231, "\x{9038}$IV0"=>1203,
"\x{9038}$IV1"=>13320, "\x{9038}$IV2"=>8633, "\x{9039}$IV0"=>6908,
"\x{9039}$IV1"=>13912, "\x{903C}$IV0"=>3489, "\x{903C}$IV1"=>7783,
"\x{9041}$IV0"=>3251, "\x{9041}$IV1"=>7763, "\x{9041}$IV2"=>20287,
"\x{9042}$IV0"=>2609, "\x{9042}$IV1"=>13468, "\x{9042}$IV2"=>13864,
"\x{9047}$IV0"=>1776, "\x{9047}$IV1"=>13736, "\x{904A}$IV0"=>3873,
"\x{904A}$IV1"=>14076, "\x{904B}$IV0"=>1249, "\x{904B}$IV1"=>13649,
"\x{904D}$IV0"=>3623, "\x{904D}$IV1"=>14017, "\x{904E}$IV0"=>1377,
"\x{904E}$IV1"=>13669, "\x{9050}$IV0"=>6911, "\x{9050}$IV1"=>14232,
"\x{9052}$IV0"=>6913, "\x{9052}$IV1"=>13607, "\x{9053}$IV0"=>3219,
"\x{9053}$IV1"=>13963, "\x{9054}$IV0"=>2913, "\x{9054}$IV1"=>13912,
"\x{9055}$IV0"=>1191, "\x{9055}$IV1"=>13411, "\x{9055}$IV2"=>13641,
"\x{9058}$IV0"=>6918, "\x{9058}$IV1"=>7873, "\x{905C}$IV0"=>2845,
"\x{905C}$IV1"=>7726, "\x{9060}$IV0"=>1301, "\x{9060}$IV1"=>13658,
"\x{9061}$IV0"=>2766, "\x{9061}$IV1"=>7722, "\x{9063}$IV0"=>1891,
"\x{9063}$IV1"=>13754, "\x{9069}$IV0"=>3110, "\x{9069}$IV1"=>13946,
"\x{906D}$IV0"=>2810, "\x{906D}$IV1"=>13896, "\x{906E}$IV0"=>2307,
"\x{906E}$IV1"=>7694, "\x{9075}$IV0"=>2415, "\x{9075}$IV1"=>13824,
"\x{9075}$IV2"=>13825, "\x{9077}$IV0"=>2733, "\x{9077}$IV1"=>13888,
"\x{9077}$IV2"=>20231, "\x{9077}$IV3"=>20232, "\x{9078}$IV0"=>2732,
"\x{9078}$IV1"=>13887, "\x{907A}$IV0"=>1192, "\x{907A}$IV1"=>13642,
"\x{907C}$IV0"=>3987, "\x{907C}$IV1"=>7808, "\x{907F}$IV0"=>3462,
"\x{907F}$IV1"=>13991, "\x{9081}$IV0"=>6927, "\x{9081}$IV1"=>14234,
"\x{9083}$IV0"=>5943, "\x{9083}$IV1"=>14172, "\x{9084}$IV0"=>1552,
"\x{9084}$IV1"=>13692, "\x{9087}$IV0"=>6893, "\x{9087}$IV1"=>14228,
"\x{9089}$IV0"=>6930, "\x{9089}$IV1"=>13407, "\x{9089}$IV2"=>14241,
"\x{9089}$IV3"=>14242, "\x{9089}$IV4"=>14243, "\x{9089}$IV5"=>14244,
"\x{9089}$IV6"=>14245, "\x{9089}$IV7"=>14246, "\x{9089}$IV8"=>14247,
"\x{9089}$IV9"=>14248, "\x{9089}$IV10"=>14249, "\x{9089}$IV11"=>14250,
"\x{9089}$IV12"=>14251, "\x{9089}$IV13"=>14252, "\x{9089}$IV14"=>20233,
"\x{908A}$IV0"=>6929, "\x{908A}$IV1"=>14235, "\x{908A}$IV2"=>14236,
"\x{908A}$IV3"=>14237, "\x{908A}$IV4"=>14238, "\x{908A}$IV5"=>14239,
"\x{908A}$IV6"=>14240, "\x{908A}$IV7"=>20234, "\x{90A3}$IV0"=>3257,
"\x{90A3}$IV1"=>7765, "\x{90A6}$IV0"=>3676, "\x{90A6}$IV1"=>14027,
"\x{90A6}$IV2"=>14028, "\x{90A8}$IV0"=>6932, "\x{90A8}$IV1"=>20235,
"\x{90AA}$IV0"=>2309, "\x{90AA}$IV1"=>13454, "\x{90AA}$IV2"=>13806,
"\x{90F7}$IV0"=>1719, "\x{90F7}$IV1"=>13725, "\x{90FD}$IV0"=>8636,
"\x{90FD}$IV1"=>3150, "\x{912D}$IV0"=>3100, "\x{912D}$IV1"=>7748,
"\x{9130}$IV0"=>6944, "\x{9130}$IV1"=>13609, "\x{914B}$IV0"=>2368,
"\x{914B}$IV1"=>7698, "\x{914C}$IV0"=>2316, "\x{914C}$IV1"=>13810,
"\x{914D}$IV0"=>3345, "\x{914D}$IV1"=>20236, "\x{9156}$IV0"=>6946,
"\x{9156}$IV1"=>13610, "\x{9158}$IV0"=>6947, "\x{9158}$IV1"=>13611,
"\x{9165}$IV0"=>6949, "\x{9165}$IV1"=>13612, "\x{9172}$IV0"=>6952,
"\x{9172}$IV1"=>13614, "\x{9173}$IV0"=>6951, "\x{9173}$IV1"=>13613,
"\x{9177}$IV0"=>2053, "\x{9177}$IV1"=>13776, "\x{91A2}$IV0"=>6956,
"\x{91A2}$IV1"=>13615, "\x{91AA}$IV0"=>6959, "\x{91AA}$IV1"=>13617,
"\x{91AF}$IV0"=>6958, "\x{91AF}$IV1"=>13616, "\x{91B1}$IV0"=>7777,
"\x{91B1}$IV1"=>13983, "\x{91B4}$IV0"=>6961, "\x{91B4}$IV1"=>13618,
"\x{91BA}$IV0"=>6962, "\x{91BA}$IV1"=>13619, "\x{91C1}$IV0"=>6964,
"\x{91C1}$IV1"=>7875, "\x{91C7}$IV0"=>2115, "\x{91C7}$IV1"=>7685,
"\x{91DC}$IV0"=>1494, "\x{91DC}$IV1"=>20290, "\x{91E3}$IV0"=>3068,
"\x{91E3}$IV1"=>13941, "\x{91FC}$IV0"=>6972, "\x{91FC}$IV1"=>15404,
"\x{9237}$IV0"=>1934, "\x{9237}$IV1"=>13437, "\x{925B}$IV0"=>1302,
"\x{925B}$IV1"=>13417, "\x{925B}$IV2"=>13659, "\x{92E9}$IV0"=>6999,
"\x{92E9}$IV1"=>20237, "\x{9306}$IV0"=>2170, "\x{9306}$IV1"=>7690,
"\x{9335}$IV0"=>7009, "\x{9335}$IV1"=>20238, "\x{9365}$IV0"=>17168,
"\x{9365}$IV1"=>15238, "\x{9375}$IV0"=>1892, "\x{9375}$IV1"=>20276,
"\x{938B}$IV0"=>18858, "\x{938B}$IV1"=>20239, "\x{938C}$IV0"=>1495,
"\x{938C}$IV1"=>13686, "\x{9396}$IV0"=>2095, "\x{9396}$IV1"=>13781,
"\x{939A}$IV0"=>3046, "\x{939A}$IV1"=>7745, "\x{93A1}$IV0"=>18854,
"\x{93A1}$IV1"=>22788, "\x{93AE}$IV0"=>3039, "\x{93AE}$IV1"=>13370,
"\x{93DD}$IV0"=>7027, "\x{93DD}$IV1"=>14254, "\x{943A}$IV0"=>7041,
"\x{943A}$IV1"=>20240, "\x{9453}$IV0"=>3846, "\x{9453}$IV1"=>7801,
"\x{9477}$IV0"=>7053, "\x{9477}$IV1"=>13620, "\x{9592}$IV0"=>8685,
"\x{9592}$IV1"=>13693, "\x{95AB}$IV0"=>20313, "\x{95AB}$IV1"=>15258,
"\x{95BB}$IV0"=>7072, "\x{95BB}$IV1"=>7876, "\x{95BC}$IV0"=>7071,
"\x{95BC}$IV1"=>14255, "\x{95CD}$IV0"=>7078, "\x{95CD}$IV1"=>20241,
"\x{962A}$IV0"=>2133, "\x{962A}$IV1"=>20242, "\x{964D}$IV0"=>2033,
"\x{964D}$IV1"=>13447, "\x{9686}$IV0"=>3964, "\x{9686}$IV1"=>13393,
"\x{9686}$IV2"=>8686, "\x{968A}$IV0"=>2882, "\x{968A}$IV1"=>13907,
"\x{9694}$IV0"=>1460, "\x{9694}$IV1"=>13683, "\x{9698}$IV0"=>7104,
"\x{9698}$IV1"=>13621, "\x{9698}$IV2"=>20243, "\x{9699}$IV0"=>1850,
"\x{9699}$IV1"=>20273, "\x{96A3}$IV0"=>4001, "\x{96A3}$IV1"=>13514,
"\x{96A3}$IV2"=>14091, "\x{96A7}$IV0"=>7108, "\x{96A7}$IV1"=>20244,
"\x{96B2}$IV0"=>7110, "\x{96B2}$IV1"=>14257, "\x{96BB}$IV0"=>2669,
"\x{96BB}$IV1"=>13877, "\x{96C5}$IV0"=>1389, "\x{96C5}$IV1"=>13420,
"\x{96C5}$IV2"=>13671, "\x{96C7}$IV0"=>1935, "\x{96C7}$IV1"=>13758,
"\x{96D9}$IV0"=>4331, "\x{96D9}$IV1"=>13525, "\x{96DA}$IV0"=>18905,
"\x{96DA}$IV1"=>22843, "\x{96E3}$IV0"=>13374, "\x{96E3}$IV1"=>3273,
"\x{96E8}$IV0"=>1229, "\x{96E8}$IV1"=>13645, "\x{96EA}$IV0"=>2695,
"\x{96EA}$IV1"=>13881, "\x{96F0}$IV0"=>3591, "\x{96F0}$IV1"=>13504,
"\x{9721}$IV0"=>19967, "\x{9721}$IV1"=>22849, "\x{9724}$IV0"=>7134,
"\x{9724}$IV1"=>7878, "\x{973D}$IV0"=>7138, "\x{973D}$IV1"=>13622,
"\x{9755}$IV0"=>20314, "\x{9755}$IV1"=>8696, "\x{9756}$IV0"=>3843,
"\x{9756}$IV1"=>8587, "\x{9759}$IV0"=>2665, "\x{9759}$IV1"=>14258,
"\x{975C}$IV0"=>7145, "\x{975C}$IV1"=>13873, "\x{975C}$IV2"=>13874,
"\x{9760}$IV0"=>7146, "\x{9760}$IV1"=>7879, "\x{9760}$IV2"=>13623,
"\x{976D}$IV0"=>2591, "\x{976D}$IV1"=>7880, "\x{976D}$IV2"=>7971,
"\x{9771}$IV0"=>7152, "\x{9771}$IV1"=>7710, "\x{9771}$IV2"=>13624,
"\x{9774}$IV0"=>1786, "\x{9774}$IV1"=>7667, "\x{9784}$IV0"=>1489,
"\x{9784}$IV1"=>7653, "\x{9798}$IV0"=>2508, "\x{9798}$IV1"=>7708,
"\x{97AD}$IV0"=>3628, "\x{97AD}$IV1"=>20291, "\x{97D3}$IV0"=>1558,
"\x{97D3}$IV1"=>13694, "\x{97DE}$IV0"=>15284, "\x{97DE}$IV1"=>15406,
"\x{97F3}$IV0"=>1339, "\x{97F3}$IV1"=>13664, "\x{97FF}$IV0"=>1721,
"\x{97FF}$IV1"=>13337, "\x{97FF}$IV2"=>13726, "\x{97FF}$IV3"=>20245,
"\x{97FF}$IV4"=>20246, "\x{980C}$IV0"=>7180, "\x{980C}$IV1"=>13625,
"\x{9811}$IV0"=>1572, "\x{9811}$IV1"=>13428, "\x{9812}$IV0"=>3430,
"\x{9812}$IV1"=>13490, "\x{9813}$IV0"=>3252, "\x{9813}$IV1"=>7764,
"\x{9824}$IV0"=>7182, "\x{9824}$IV1"=>7881, "\x{983B}$IV0"=>7788,
"\x{983B}$IV1"=>3523, "\x{985E}$IV0"=>13396, "\x{985E}$IV1"=>4008,
"\x{9867}$IV0"=>1936, "\x{9867}$IV1"=>13759, "\x{9873}$IV0"=>7194,
"\x{9873}$IV1"=>13626, "\x{98C3}$IV0"=>7200, "\x{98C3}$IV1"=>13627,
"\x{98DF}$IV0"=>2543, "\x{98DF}$IV1"=>13847, "\x{98E2}$IV0"=>1612,
"\x{98E2}$IV1"=>13705, "\x{98EB}$IV0"=>7203, "\x{98EB}$IV1"=>14260,
"\x{98EF}$IV0"=>8699, "\x{98EF}$IV1"=>3431, "\x{98EF}$IV2"=>20261,
"\x{98F4}$IV0"=>1151, "\x{98F4}$IV1"=>7634, "\x{98FC}$IV0"=>2242,
"\x{98FC}$IV1"=>8700, "\x{98FD}$IV0"=>3678, "\x{98FD}$IV1"=>14029,
"\x{98FE}$IV0"=>2534, "\x{98FE}$IV1"=>13844, "\x{9903}$IV0"=>7204,
"\x{9903}$IV1"=>14261, "\x{9905}$IV0"=>3819, "\x{9905}$IV1"=>7799,
"\x{9909}$IV0"=>7205, "\x{9909}$IV1"=>14262, "\x{990A}$IV0"=>3910,
"\x{990A}$IV1"=>14080, "\x{990C}$IV0"=>1252, "\x{990C}$IV1"=>7643,
"\x{990C}$IV2"=>13413, "\x{990C}$IV3"=>13650, "\x{9910}$IV0"=>2191,
"\x{9910}$IV1"=>7970, "\x{9913}$IV0"=>1390, "\x{9913}$IV1"=>13672,
"\x{9921}$IV0"=>7209, "\x{9921}$IV1"=>20248, "\x{9928}$IV0"=>1559,
"\x{9928}$IV1"=>8702, "\x{9945}$IV0"=>7220, "\x{9945}$IV1"=>14263,
"\x{9945}$IV2"=>14264, "\x{994B}$IV0"=>7222, "\x{994B}$IV1"=>14265,
"\x{9957}$IV0"=>1722, "\x{9957}$IV1"=>7968, "\x{9957}$IV2"=>13727,
"\x{9957}$IV3"=>20249, "\x{99C1}$IV0"=>3379, "\x{99C1}$IV1"=>20288,
"\x{99D0}$IV0"=>2993, "\x{99D0}$IV1"=>13927, "\x{9A19}$IV0"=>7248,
"\x{9A19}$IV1"=>8003, "\x{9A30}$IV0"=>3205, "\x{9A30}$IV1"=>13961,
"\x{9A45}$IV0"=>7251, "\x{9A45}$IV1"=>13628, "\x{9A4A}$IV0"=>15319,
"\x{9A4A}$IV1"=>22920, "\x{9A5F}$IV0"=>7260, "\x{9A5F}$IV1"=>14267,
"\x{9A65}$IV0"=>7262, "\x{9A65}$IV1"=>14268, "\x{9AEF}$IV0"=>7280,
"\x{9AEF}$IV1"=>14269, "\x{9B18}$IV0"=>7288, "\x{9B18}$IV1"=>14270,
"\x{9B2D}$IV0"=>17205, "\x{9B2D}$IV1"=>13372, "\x{9B2E}$IV0"=>7298,
"\x{9B2E}$IV1"=>7882, "\x{9B35}$IV0"=>20010, "\x{9B35}$IV1"=>22948,
"\x{9B4D}$IV0"=>7304, "\x{9B4D}$IV1"=>13629, "\x{9B54}$IV0"=>3728,
"\x{9B54}$IV1"=>14043, "\x{9B58}$IV0"=>7307, "\x{9B58}$IV1"=>13630,
"\x{9B97}$IV0"=>7313, "\x{9B97}$IV1"=>7883, "\x{9BA8}$IV0"=>7316,
"\x{9BA8}$IV1"=>20250, "\x{9BAB}$IV0"=>2171, "\x{9BAB}$IV1"=>20280,
"\x{9BAE}$IV0"=>2737, "\x{9BAE}$IV1"=>20251, "\x{9BB9}$IV0"=>7320,
"\x{9BB9}$IV1"=>20252, "\x{9BC6}$IV0"=>7321, "\x{9BC6}$IV1"=>13631,
"\x{9BD6}$IV0"=>2168, "\x{9BD6}$IV1"=>7689, "\x{9BDB}$IV0"=>2884,
"\x{9BDB}$IV1"=>13908, "\x{9BE1}$IV0"=>7329, "\x{9BE1}$IV1"=>13632,
"\x{9BF1}$IV0"=>7332, "\x{9BF1}$IV1"=>13633, "\x{9BF2}$IV0"=>7331,
"\x{9BF2}$IV1"=>7884, "\x{9C08}$IV0"=>7340, "\x{9C08}$IV1"=>20253,
"\x{9C24}$IV0"=>7347, "\x{9C24}$IV1"=>20254, "\x{9C2F}$IV0"=>1207,
"\x{9C2F}$IV1"=>7636, "\x{9C3B}$IV0"=>1241, "\x{9C3B}$IV1"=>20255,
"\x{9C48}$IV0"=>2923, "\x{9C48}$IV1"=>7737, "\x{9C52}$IV0"=>3742,
"\x{9C52}$IV1"=>7796, "\x{9C57}$IV0"=>4002, "\x{9C57}$IV1"=>14092,
"\x{9CE6}$IV0"=>19068, "\x{9CE6}$IV1"=>20257, "\x{9D07}$IV0"=>3222,
"\x{9D07}$IV1"=>7759, "\x{9D08}$IV0"=>7363, "\x{9D08}$IV1"=>14273,
"\x{9D09}$IV0"=>7362, "\x{9D09}$IV1"=>14272, "\x{9D48}$IV0"=>7379,
"\x{9D48}$IV1"=>13634, "\x{9D60}$IV0"=>2054, "\x{9D60}$IV1"=>7683,
"\x{9D6C}$IV0"=>3680, "\x{9D6C}$IV1"=>14030, "\x{9DB4}$IV0"=>8715,
"\x{9DB4}$IV1"=>3069, "\x{9DBF}$IV0"=>19091, "\x{9DBF}$IV1"=>23006,
"\x{9DC0}$IV0"=>17224, "\x{9DC0}$IV1"=>20258, "\x{9DC2}$IV0"=>7403,
"\x{9DC2}$IV1"=>20259, "\x{9DCF}$IV0"=>7402, "\x{9DCF}$IV1"=>13635,
"\x{9E97}$IV0"=>4023, "\x{9E97}$IV1"=>13516, "\x{9E9F}$IV0"=>4003,
"\x{9E9F}$IV1"=>13515, "\x{9E9F}$IV2"=>14093, "\x{9EA5}$IV0"=>7425,
"\x{9EA5}$IV1"=>14274, "\x{9EAA}$IV0"=>7428, "\x{9EAA}$IV1"=>7885,
"\x{9EAD}$IV0"=>7429, "\x{9EAD}$IV1"=>8004, "\x{9EBB}$IV0"=>3729,
"\x{9EBB}$IV1"=>14044, "\x{9EBF}$IV0"=>3753, "\x{9EBF}$IV1"=>14050,
"\x{9ECC}$IV0"=>7431, "\x{9ECC}$IV1"=>14275, "\x{9EDB}$IV0"=>2883,
"\x{9EDB}$IV1"=>7729, "\x{9F08}$IV0"=>7451, "\x{9F08}$IV1"=>13636,
"\x{9F08}$IV2"=>14276, "\x{9F3B}$IV0"=>3475, "\x{9F3B}$IV1"=>13993,
"\x{9F4A}$IV0"=>7457, "\x{9F4A}$IV1"=>14277, "\x{9F4B}$IV0"=>5898,
"\x{9F4B}$IV1"=>14170, "\x{9F4E}$IV0"=>6779, "\x{9F4E}$IV1"=>13604,
"\x{9F67}$IV0"=>7465, "\x{9F67}$IV1"=>14279, "\x{9F8D}$IV0"=>3966,
"\x{9F8D}$IV1"=>14086, "\x{9F8D}$IV2"=>14087, "\x{9F9C}$IV0"=>7472,
"\x{9F9C}$IV1"=>7886, "\x{9F9D}$IV0"=>5927, "\x{9F9D}$IV1"=>7847,
"\x{FA11}$IV0"=>14290, "\x{FA11}$IV1"=>8443, "\x{FA24}$IV0"=>18760,
"\x{FA24}$IV1"=>8632, "\x{235C4}$IV0"=>16905, "\x{235C4}$IV1"=>15428,
"\x{2363A}$IV0"=>15393, "\x{2363A}$IV1"=>13723, "\x{2363A}$IV2"=>13724,
"\x{2383D}$IV0"=>17885, "\x{2383D}$IV1"=>20262, "\x{242EE}$IV0"=>14282,
"\x{242EE}$IV1"=>14281, "\x{26270}$IV0"=>18385, "\x{26270}$IV1"=>14190,
"\x{29D4B}$IV0"=>13717, "\x{29D4B}$IV1"=>13718, "\x{29E3D}$IV0"=>20315,
"\x{29E3D}$IV1"=>15437, "\x{2A61A}$IV0"=>20316, "\x{2A61A}$IV1"=>14280,
);
# EOF
