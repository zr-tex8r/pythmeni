# checkenv.pl

sub check_pxutil {
  my $r = `pxutil`;
  return (substr($r, 0, 14) eq "This is pxutil");
}

sub check_perl_module {
  my ($mod) = @_;
  foreach my $p (@INC) {
    if (-f "$p/$mod.pm") { return 1; }
  }
  return '';
}

my $pxutil = check_pxutil();
print("pxutil: ", $pxutil ? 'OK' : 'NG', "\n");
my $zrtextor = check_perl_module('ZRTeXtor');
print("zrtextor: ", $zrtextor ? 'OK' : 'NG', "\n");
my $zrgtcode = check_perl_module('ZRGTCode');
print("zrgtcode: ", $zrgtcode ? 'OK' : 'NG', "\n");
unless ($pxutil && $zrtextor && $zrgtcode) {
  print <<'END';
Something missing that is required for the process!!!!
You must get and install following packages which are provided by the
same author as of PXgtfont package.
  - PXutil package
  - ZRTeXtor package
  - ZRTessera package
END
  exit(1);
}

# EOF
