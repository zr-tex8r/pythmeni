@echo off
rem gen-pxgtfont.bat
set TFM_DIR=%ZR_PUBLIC_TEXMF%\fonts\tfm\public
set VF_DIR=%ZR_PUBLIC_TEXMF%\fonts\vf\public
set PKGNAME=PXgtfont
if "%1"=="build" goto build
if "%1"=="install" goto install
echo Usage:
echo gen-pxgtfont build : generate all files
echo gen-pxgtfont install : move files to private texmf tree
goto exit

:build
perl checkenv.pl
if errorlevel 1 goto exit
:ptex
echo Raw JFMs...
for %%a in (jy1 jt1) do ppltotf r-gtmc-r-%%a.pl r-gtmc-r-%%a.tfm
echo JFMs and VFs for base encodings ...
for %%a in (jy1 jt1) do pxutil zvp2vf gtmc-r-%%a
echo JFMs for encodings g02--g13 ...
for %%a in (02 03 04 05 06 07 08 09 10 11 12 13 k1 k2) do copy r-gtmc-r-jy1.tfm gtmc-r-g%%a.tfm >nul
echo JFMs and VFs for encodings zg0--zga...
perl gen-vf.pl
del gtmc-r-zg?.zvp
:uptex
echo JFMs and VFs for upTeX...
for %%a in (jy2 jt2) do uppltotf r-gtmc-r-%%a.pl r-gtmc-r-%%a.tfm
rem for %%a in (jy2 jt2) do pxutil zvp2vf gtmc-r-%%a
for %%a in (v2 v3 v4 v5 v6 v7 v8 v9 w0 w1 w2 w3) do copy r-gtmc-r-jt1.tfm gtmc-r-g%%a.tfm >nul
perl gen-uvf.pl
pxutil zvp2vf gtmc-r-jy2
pxutil zvp2vf gtmc-r-jt2
echo wait for a long time......
pxutil zvp2vf gtmc-r-j48
echo wait for a long time again......
pxutil zvp2vf gtmc-r-j58
echo wait for a long long time.........
pxutil zvp2vf gtmc-r-zgu
echo All done!
del gtmc-r-jy2.zvp gtmc-r-jt2.zvp
del gtmc-r-j48.zvp gtmc-r-j58.zvp gtmc-r-zgu.zvp
goto exit

:install
move *.tfm %TFM_DIR%\%PKGNAME%
move *.vf %VF_DIR%\%PKGNAME%
goto exit

:exit
