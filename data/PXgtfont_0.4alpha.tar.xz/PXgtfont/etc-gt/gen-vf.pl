#!/usr/bin/perl
# gen-vf-gt.pl
#
use strict;
use Encode qw(encode decode);
use ZRTeXtor ':all';
use ZRGTCode;
use Data::Dump 'dump';
#
my $max_gn = 78774;
my $geta = "01-81AC";
my (@fmap, @chars);

sub main {
  my ($sfn, $fn, $tfm, $pl, $vf);
  select(STDOUT); $| = 1;
  print("Now construcring data...");
  gen_table();
  print("Done.\n", "Writing VF...");
  foreach $sfn (0 .. $#chars) {
    print(" $sfn");
    $fn = sprintf("gtmc-r-zg%x", $sfn);
    $pl = gen_zvp($sfn);
    write_whole_file("$fn.zvp", $pl) or die;
    ($vf, $tfm) = vf_form_ex(pl_parse($pl)) or die textool_error();
    write_whole_file("$fn.vf", $vf, 1) or die;
    write_whole_file("$fn.tfm", $tfm, 1) or die;
  }
  print("\nDone.\n");
}

sub gen_table {
  my ($t, $u, $e, $hb, $lb, $sfn, $gn, $vjc, $gfn, $gjc);
  my (@fm, @fid, %chk);
  L1:for ($sfn = 0, $gn = 1; ; $sfn++) {
    for $hb (0x2e .. 0x7e) {
      for $lb (0x21 .. 0x7e) {
        $vjc = sprintf("%04x", $hb * 256 + $lb);
        (($t = sjposition($gn)) =~ m/-/) or $t = $geta;
        ($t =~ m/^(\d\d)-(\w\w\w\w)$/) or die;
        $gfn = $1 - 0; $gjc = sjistojis($2);
        push(@{$chars[$sfn]}, [ $vjc, $gfn, $gjc ]);
        if (++$gn > $max_gn) { last L1; }
      }
    }
  }
  foreach $sfn (0 .. $#chars) {
    %chk = (); @fid = ();
    foreach $e (@{$chars[$sfn]}) { $chk{$e->[1]} = 1; }
    @fm = sort { $a <=> $b } (keys %chk);
    foreach (0 .. $#fm) { $fid[$fm[$_]] = $_; }
    foreach $e (@{$chars[$sfn]}) { $e->[1] = $fid[$e->[1]]; }
    $fmap[$sfn] = [ @fm ];
  }
}

sub sjistojis {
  my ($t) = @_;
  $t = decode('shiftjis', pack('H*', $t));
  $t = encode('jis0208-raw', $t);
  return uc(unpack('H*', $t));
}

sub gen_zvp {
  my ($sfn) = @_; my ($t, $u, $e, $vjc, $fid, $gjc, @cnks);
  push(@cnks, <<"END");
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME )
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.0)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   )
(CODESPACE GL94DB)
(TYPE D 0
   (CHARWD R 1.0)
   (CHARHT R 0.88)
   (CHARDP R 0.12)
   (MAP ) )
END
  push(@cnks, gen_fontmap($fmap[$sfn]));
  foreach $e (@{$chars[$sfn]}) {
    ($vjc, $fid, $gjc) = @$e;
    $t = ($fid == 0) ? "" : "(SELECTFONT D $fid)";
    push(@cnks, <<"END");
(CHARACTER H $vjc
   (CHARWD R 1.0)
   (MAP $t (SETCHAR H $gjc) ) )
END
  }
  return join('', @cnks);
}

sub gen_fontmap {
  my ($fmap) = @_; my ($n, $t, @cnks);
  foreach (0 .. $#$fmap) {
    $n = $fmap->[$_];
    $t = ($n  == 1) ? "r-gtmc-r-jy1" : sprintf("gtmc-r-g%02d", $n);
    push(@cnks, <<"END");
(MAPFONT D $_ (FONTNAME $t) )
END
  }
  return join("", @cnks);
}


main();
