# gen-zgy-vf.pl
# Generates VF t1??-r-zgy.
use strict;
use ZRJCode ':all';
require 'tfwidth.pl';

our %tf_width;
my %width = %tf_width;
for my $uc (0x4E00 .. 0x9FFF) {
  delete $width{$uc};
}
for my $uc (0 .. 0x7F) {
  delete $width{$uc};
}

my %trep;
open(my $hi, '<', "treplacedata.tex") or die;
while (<$hi>) {
  m/\\TReplace (\w+) (\w+) ;/ or next;
  $trep{hex($1)} = hex($2);
}
close($hi);

sub raw_code {
  my ($uc) = @_;
  my $uc1 = $trep{$uc};
  return ($uc1 == 0x3013) ? undef : (defined $uc1) ? $uc1 : $uc;
}

my @row = qw(
  0 1 2 3 4 30 31 32 33 34 35 36 37 38 39
  41 48 49 50 51 224 225 226 247 248 254 255
);
my $rowlen = 94;
my $baseic = 13 * $rowlen;
my %rowid;
for my $i (0 .. $#row) {
  $row[$i] -= 0; $rowid{$row[$i]} = $i;
}
sub shift_code {
  my ($uc) = @_;
  my ($r, $c) = ($uc >> 8, $uc & 0xFF);
  my $ri = $rowid{$r}; (defined $ri) or return;
  my $ic = (($ri << 8) | $c) + $baseic;
  return in_jis($ic);
}

my %map;
for my $uc0 (0 .. 0xFFFF) {
  my $uc1 = raw_code($uc0);
  ($width{$uc1}) or next;
  my $jc = shift_code($uc0) or die;
  #printf("%04X -(%04X)-> %04X\n", $jc, $uc0, $uc1);
  $map{$jc} = $uc1;
}

#---------------------------------------
my $jukibase = 0xE100; # 
my $jukicount = 168;
my $jukibase_vs = 0xF780; # 
my $jukibase_svs = 0xF840; # 
my $acc_ratio = 0.82;
my $bdisp_x = -0.28;
my $bdisp_y = 0.15;
use constant { QA => -21, QB => -16, QC => -14, QD => -15 };
my @disp_adj = (
 [ 0, 2], [ 0, 0], [ 0, 2], [ 0, 0], [ 4, 5], # 000
 [ 3, 1], [ 3, 0], [ 0, 0], [ 4, 4], [ 3, 0], # 005
 [ 0, 0], [ 0, 0], [ 0, 0], [ 3, 1], [ 0, 0], # 010
 [ 0, 0], [-2, 0], [ 0, 0], [ 0, 0], [ 3, 0], # 015
 [ 0, 0], [ 0, 0], [ 5, 5], [ 0, 0], [ 0, 0], # 020
 [ 0, 0], [ 0, 0], [ 0, 0], [ 0, 0], [ 4, 3], # 025
 [ 0, 0], [ 2, 3], [ 0, 0], [-2,-4], [ 0, 0], # 030
 [ 0, 0], [ 3, 4], [ 3, 2], [ 2,QA], [ 4, 5], # 035
 [-2,-2], [ 0, 0], [-2,-1], [ 0, 0], [ 0, 0], # 040
 [ 4, 3], [ 2, 0], [ 5, 5], [ 0, 0], [ 0, 0], # 045
 [ 0, 0], [ 3, 3], [ 0, 0], [ 2, 1], [-1,-2], # 050
 [ 3, 2], [-2, 0], [ 0, 0], [ 0, 0], [ 0,-2], # 055
 [-3,-6], [ 0, 0], [ 0, 0], [ 5, 5], [ 5, 4], # 060
 [ 3, 1], [ 0, 0], [ 0,QB], [ 3, 2], [ 3, 1], # 065
 [ 4, 3], [ 0, 0], [ 0, 0], [-1, 0], [ 0,-2], # 070
 [ 0, 0], [ 4, 3], [ 4, 2], [ 0,-2], [ 0,-2], # 075
 [ 0,-2], [ 1, 3], [ 0, 0], [ 0, 0], [ 0, 0], # 080
 [ 3, 0], [ 0, 0], [ 0, 0], [ 4, 3], [ 0, 0], # 085
 [ 3, 0], [ 2, 0], [ 4, 2], [ 0, 0], [-2,-7], # 090
 [-1,-2], [ 0, 0], [ 0, 0], [ 0, 0], [ 0, 0], # 095
 [ 7,QC], [ 0, 0], [ 0, 0], [ 0, 0], [ 0, 0], # 100
 [ 0, 0], [ 0, 0], [ 0, 0], [ 4, 4], [ 0, 0], # 105
 [ 0, 0], [ 5, 4], [ 0, 0], [ 0, 0], [ 4,QD], # 110
 [ 5,-8], [ 0, 0], [ 0, 0], [ 0, 0], [ 5, 0], # 115
 [ 4, 4], [ 0, 0], [ 0, 0], [ 0, 0], [ 0, 0], # 120
 [ 0, 0], [ 0,-2], [ 0, 0], [ 0, 0], [ 4, 3], # 125
 [ 0, 0], [ 1, 0], [ 5, 4], [ 0, 0], [ 1, 0], # 130
 [ 2, 0], [ 0, 0], [ 0, 0], [ 5, 4], [ 0, 0], # 135
 [ 0,-2], [ 4, 3], [ 0, 0], [ 3, 3], [ 5, 5], # 140
 [ 5, 5], [ 0, 0], [ 5, 5], [ 4, 3], [ 4, 4], # 145
 [ 0, 0], [ 0,-2], [ 1, 0], [ 3, 0], [ 3,-2], # 150
 [ 2, 0], [ 3, 2], [ 0, 0], [ 0,-3], [ 0, 0], # 155
 [ 3, 2], [ 0, 0], [-1,-2], [ 4, 4], [ 5, 5], # 160
 [ 2, 2], [ 0, 0], [ 0, 0]                    # 165
);


#---------------------------------------

my $fnam = "t1mc-r";
open(my $ho, '>', "$fnam-zgy.zvp") or die;

print $ho <<"EOS";
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME SPECIAL)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
(MAPFONT D 0
   (FONTNAME r-$fnam-u)
   (FONTDSIZE R 10.0)
   (FONTAT R 1.0)
   )
(MAPFONT D 1
   (FONTNAME r-$fnam-u)
   (FONTDSIZE R 10.0)
   (FONTAT R $acc_ratio)
   )
(TYPE D 0
   (CHARWD R 1.0)
   (CHARHT R 0.88)
   (CHARDP R 0.12)
   (MAP)
   )
EOS

my  @cspace = sort { $a <=> $b } (
  (keys %map),
  map { shift_code($_) } (
    $jukibase_vs .. $jukibase_vs + $jukicount - 1,
    $jukibase_svs .. $jukibase_svs + $jukicount - 1));
print $ho "(CODESPACE\n";
for my $jc (@cspace) {
  printf $ho ("X%04X\n", $jc);
}
print $ho ")\n";

for my $jc (sort { $a <=> $b } (keys %map)) {
  my $jcx = sprintf("%04X", $jc);
  my $uc = $map{$jc}; my $wd = $width{$uc};
  my $ucx = sprintf("%04X", $uc);
  my $wdx = sprintf("%9.7f", $wd);
  print $ho <<"EOS";
(CHARACTER H $jcx
   (CHARWD R $wdx)
   (MAP
      (SETCHAR H $ucx)
      )
   )
EOS
}

my $uc_vs = 0x309B;
my $uc_svs = 0x309C;
for my $ki (0 .. $jukicount - 1) {
  my $jcv = shift_code($jukibase_vs + $ki);
  my $jcs = shift_code($jukibase_svs + $ki);
  my $ucb = $jukibase + $ki;
  my ($jcvx, $jcsx, $ucbx, $ucvx, $ucsx) = map { sprintf("%04X", $_) }
    ($jcv, $jcs, $ucb, $uc_vs, $uc_svs);
  my ($dxf, $dyf) = map { sprintf("%9.7f", $_) }
   ($bdisp_x + $disp_adj[$ki][0] / 100,
    $bdisp_y + $disp_adj[$ki][1] / 100);
  print $ho <<"EOS";
(CHARACTER H $jcvx
   (CHARWD R 1.0)
   (MAP
      (SETCHAR H $ucbx)
      (PUSH)
      (SELECTFONT D 1)
      (MOVERIGHT R $dxf)
      (MOVEUP R $dyf)
      (SETCHAR H $ucvx)
      (POP)
      )
   )
(CHARACTER H $jcsx
   (CHARWD R 1.0)
   (MAP
      (SETCHAR H $ucbx)
      (PUSH)
      (SELECTFONT D 1)
      (MOVERIGHT R $dxf)
      (MOVEUP R $dyf)
      (SETCHAR H $ucsx)
      (POP)
      )
   )
EOS
}

close($ho);

exit;

my $jukibase_vs = 0xF780; # 
my $jukibase_svs = 0xF840; # 

for my $ki (0 .. $jukicount - 1) {
  my $jc = shift_code($jukibase_vs + $ki);
  printf("\\Test{%04X}%\n", $jc);
}
for my $ki (0 .. $jukicount - 1) {
  my $jc = shift_code($jukibase_svs + $ki);
  printf("\\Test{%04X}%\n", $jc);
}

# EOF
