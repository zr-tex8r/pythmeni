use strict;
use ZRTeXtor ':all';
use ZRJCode ':all';
use ZRGTCode;
use constant { MAXGT => 78774, MAXFN => 13, MAXKFN => 0 };
use constant { GETA => '01-81AC' };
use constant { UGETA => 0x3013 };

sub main {
  zgu_generate();
}

##------ zgu encoding

sub zgu_generate {
  my ($zvp, $vf, $tfm, $map);
  $map = zgu_genmap();
  $zvp = join('', u_zvp_prologue(""), u_mapfont(0),
                  u_type(), zgu_space($map), zgu_character($map));
  write_whole_file("t1mc-r-zgu.zvp", $zvp);
}

sub zgu_genmap {
  my ($t, $uc, $fid, %u2j, %map);
  foreach $t (1410 .. 4374, 4418 .. 7807) {
    $u2j{in_ucs($t)} = in_jis($t);
  }
  foreach $fid (0 .. (MAXFN + MAXKFN - 1)) {
    $t = $fid * 0x10000;
    foreach $uc (keys %u2j) {
      $map{$t + $uc} = sprintf("%d-%04X", $fid, $u2j{$uc});
    }
  }
  return \%map;
}


sub zgu_space {
  my ($map) = @_; my ($t);
  $t = join("\n", map { sprintf("X%04X", $_) }
                     (sort { $a <=> $b } (keys %$map)));
  return "(CODESPACE $t)\n";
}

sub zgu_character {
  my ($map) = @_; my ($t, $fid, $jx, $uc, $ux, @ucs, @cnks);
  @ucs = sort { $a <=> $b } (keys %$map);
  foreach $uc (@ucs) {
    (defined($t = $map->{$uc})) or next;
    ($fid, $jx) = split(m/-/, $t); $ux = in_hex($uc);
    $t = ($fid > 0) ? "(SELECTFONT D $fid)" : "";
    $t = "(CHARACTER H $ux (MAP $t (SETCHAR H $jx) ) )\n";
    push(@cnks, $t);
  }
  return join('', @cnks);
}


##------ common subproc

sub u_zvp_prologue {
  my ($ncs, $swvt) = @_;
  if (!$swvt) {
    return <<"END";
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME $ncs)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
END
  } else {
    return <<"END";
(DIRECTION TATE)
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME $ncs)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
END
  }
}

sub u_mapfont {
  my ($sw) = @_; my ($n, $fid, $fnam, @c, @cnks);
  @c = ($sw) ? ('k1', 'k2') : (); $fid = 0;
  foreach $n (1 .. MAXFN, @c) {
    if ($n =~ m/^k/) {
      $fnam = "t1mc-r-g$n";
    } else {
      $fnam = ($n > 1) ? sprintf("t1mc-r-g%02d", $n) :
                "r-t1mc-r-jy1";
    }
    push(@cnks, <<"END");
(MAPFONT D $fid
   (FONTNAME $fnam)
   (FONTDSIZE R 10.0)
   (FONTAT R 1.0)
   )
END
    $fid++;
  }
  return join('', @cnks);
}

sub u_type {
  return <<"END";
(TYPE D 0
   (CHARWD R 1.0)
   (CHARHT R 0.88)
   (CHARDP R 0.12)
   )
END
}


##------ go to main
main();
## EOF
