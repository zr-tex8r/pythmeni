@echo off
rem -- gen-pxtfont.bat
set TFM_DIR=%ZR_PUBLIC_TEXMF%\fonts\tfm\public
set VF_DIR=%ZR_PUBLIC_TEXMF%\fonts\vf\public
set PKGNAME=PXgtfont
if "%1"=="build" goto build
if "%1"=="install" goto install
echo Usage:
echo gen-pxgtfont build : generate all files
echo gen-pxgtfont install : move files to private texmf tree
exit /B

:build
set TFAM_LIST=t1mc-r t1gt-r t1ks-r
set TMINFAM=t1mc-r
set GTFAM=gtmc-r

call :zguproc
call :zgyproc

for %%f in (%TFAM_LIST%) do (
  call :famproc %%f
)

exit /B

:zguproc
echo Generating %TMINFAM%-zgu
perl gen-zgu-vf.pl
pxutil zvp2vf %TMINFAM%-zgu
del %TMINFAM%-zgu.zvp
exit /B

:zgyproc
echo Generating %TMINFAM%-zgy
perl gen-zgy-vf.pl
pxutil zvp2vf %TMINFAM%-zgy
del %TMINFAM%-zgy.zvp
uptftopl r-%GTFAM%-jy2 r-%TMINFAM%-u
uppltotf r-%TMINFAM%-u r-%TMINFAM%-u
del r-%TMINFAM%-u.pl
exit /B

:famproc
for %%v in (%VF_DIR%\PXgtfont\gtmc*.vf) do (
  call :fonproc %1 %%v
)
if not %1==%TMINFAM% (
  echo %1 - %TMINFAM%-zgu
  pxcopyfont -Z %TMINFAM%-zgu %1
  echo %1 - %TMINFAM%-zgy
  pxcopyfont -Z %TMINFAM%-zgy %1
)
exit /B

:fonproc
set VF=%~n2
if %VF%==%VF:-zgu=-___% (
  echo %1 - %VF%
  pxcopyfont -Z %VF% %1
)
exit /B

:install
if not exist %VF_DIR%\%PKGNAME% mkdir %VF_DIR%\%PKGNAME%
if not exist %TFM_DIR%\%PKGNAME% mkdir %TFM_DIR%\%PKGNAME%
move *.tfm %TFM_DIR%\%PKGNAME%
move *.vf %VF_DIR%\%PKGNAME%
exit /B

:exit
