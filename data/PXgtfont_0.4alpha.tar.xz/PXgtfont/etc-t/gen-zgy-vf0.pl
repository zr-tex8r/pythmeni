# gen-zgy-vf.pl
# Generates VF t1??-r-zgy.
use strict;
use ZRJCode ':all';
require 'tfwidth.pl';

our %tf_width;
my %width = %tf_width;
for my $uc (0x4E00 .. 0x9FFF) {
  delete $width{$uc};
}
for my $uc (0 .. 0x7F) {
  delete $width{$uc};
}

my %trep;
open(my $hi, '<', "treplacedata.tex") or die;
while (<$hi>) {
  m/\\TReplace (\w+) (\w+) ;/ or next;
  $trep{hex($1)} = hex($2);
}
close($hi);

sub raw_code {
  my ($uc) = @_;
  my $uc1 = $trep{$uc};
  return ($uc1 == 0x3013) ? undef : (defined $uc1) ? $uc1 : $uc;
}

my @row = qw(
  0 1 2 3 4 30 31 32 33 34 35 36 37 38 39
  41 48 49 50 51 224 225 226 247 254 255
);
my $rowlen = 94;
my $baseic = 13 * $rowlen;
my %rowid;
for my $i (0 .. $#row) {
  $row[$i] -= 0; $rowid{$row[$i]} = $i;
}
sub shift_code {
  my ($uc) = @_;
  my ($r, $c) = ($uc >> 8, $uc & 0xFF);
  my $ri = $rowid{$r}; (defined $ri) or return;
  my $ic = (($ri << 8) | $c) + $baseic;
  return in_jis($ic);
}

my %map;
for my $uc0 (0 .. 0xFFFF) {
  my $uc1 = raw_code($uc0);
  ($width{$uc1}) or next;
  my $jc = shift_code($uc0) or die;
  #printf("%04X -(%04X)-> %04X\n", $jc, $uc0, $uc1);
  $map{$jc} = $uc1;
}

#---------------------------------------

my $fnam = "t1mc-r";
open(my $ho, '>', "$fnam-zgy.zvp") or die;

print $ho <<"EOS";
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME SPECIAL)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
(MAPFONT D 0
   (FONTNAME r-$fnam-j29)
   (FONTDSIZE R 10.0)
   (FONTAT R 1.0)
   )
(TYPE D 0
   (CHARWD R 1.0)
   (CHARHT R 0.88)
   (CHARDP R 0.12)
   (MAP)
   )
EOS

print $ho "(CODESPACE\n";
for my $jc (sort { $a <=> $b } (keys %map)) {
  printf $ho ("X%04X\n", $jc);
}
print $ho ")\n";

for my $jc (sort { $a <=> $b } (keys %map)) {
  my $jcx = sprintf("%04X", $jc);
  my $uc = $map{$jc}; my $wd = $width{$uc};
  my $ucx = sprintf("%04X", $uc);
  my $wdx = sprintf("%9.7f", $wd);
  print $ho <<"EOS";
(CHARACTER H $jcx
   (CHARWD R $wdx)
   (MAP
      (SETCHAR H $ucx)
      )
   )
EOS
}

close($ho);

# EOF
