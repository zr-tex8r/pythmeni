@echo off
ttf2tfm constan.ttf -p win8r.enc -t 7t.enc -v jk4r7t jk4r8r
vptovf jk4r7t
ttf2tfm constan.ttf -p win8r.enc -t ecwin.enc -v jk4r8t jk4r8r
vptovf jk4r8t
del jk4r??.vpl
:exit
