@echo off
ttf2tfm constan.ttf -p bx-8w.enc -t 7t.enc -v wconstan2-r-ot1 wconstan2-r-8w
vptovf wconstan2-r-ot1
ttf2tfm constan.ttf -p bx-8w.enc -t bx-ly1.enc -v wconstan2-r-ly1 wconstan2-r-8w
vptovf wconstan2-r-ly1
del wconstan2-*.vpl
:exit
