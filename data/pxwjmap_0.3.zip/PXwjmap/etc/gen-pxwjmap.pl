#!/usr/local/bin/perl
# gen-pxwjmap
#
my $prgname = 'gen-pxwjmap';
my $version = '1.11';

my $base_name = 'pdfm-wj';  # map �t�@�C���̖��O�̎n��
  # �t�H���g�����̕\�B�Ⴆ�΁Ajmin0-r/st �̗��ɂ� pdfm-wjst.map ��
  # '$jmin0-r' ��u�����镶������w��B�������A$font_alias_table
  # �̍����ɂ��镶����͉E���̂��̂ɂ���ɒu�������B
my $assign_table = <<'END';
*        no  st     ms      msp     ip      ipp
jmin0-r  JM0 JM0    msmin   JM0     ipam    JM0
jmin1-r  JM  JM     msmin   msmin   ipam    ipam
jmin2-r  JM  JM     msmin   msmin   ipam    ipam
jgth0-r  JG0 JG0    msgoth  JG0     ipag    JG0
jgth1-r  JG  JG     msgoth  msgoth  ipag    ipag
jgth2-r  JG  JG     msgoth  msgoth  ipag    ipag
jmin0-m  JM  JM     msmin   JM      ipam    JM
jmin1-m  JM  JM     msmin   msmin   ipam    ipam
jmin2-m  JM  JM     msmin   msmin   ipam    ipam
jmin0-b  JM  hgrme  hgrme   hgrme   hgrme   hgrme
jmin1-b  JM  hgrme  hgrme   hgrme   hgrme   hgrme
jmin2-b  JM  hgrme  hgrme   hgrme   hgrme   hgrme
jgth0-m  JG  hgrgm  hgrgm   hgrgm   hgrgm   hgrgm
jgth1-m  JG  hgrgm  hgrgm   hgrgm   hgrgm   hgrgm
jgth2-m  JG  hgrgm  hgrgm   hgrgm   hgrgm   hgrgm
jgth0-b  JG  JG     msgoth  JG      ipag    JG
jgth1-b  JG  JG     msgoth  msgoth  ipag    ipag
jgth2-b  JG  JG     msgoth  msgoth  ipag    ipag
jmgt0-r  JG  hgrsmp hgrsmp  hgrsmp  hgrsmp  hgrsmp
jmgt1-r  JG  hgrsmp hgrsmp  hgrsmp  hgrsmp  hgrsmp
jmgt2-r  JG  hgrsmp hgrsmp  hgrsmp  hgrsmp  hgrsmp
jmin0-l  JM  JM     msmin   msmin   ipam    ipam
jmin1-l  JM  JM     msmin   msmin   ipam    ipam
jmin2-l  JM  JM     msmin   msmin   ipam    ipam
jgth0-e  JG  hgrsgu hgrsgu  hgrsgu  hgrsgu  hgrsgu
jgth0-e  JG  hgrsgu hgrsgu  hgrsgu  hgrsgu  hgrsgu
kmin1-r  KM  KM     batang  batang  batang  batang
kmin2-r  KM  KM     batang  batang  batang  batang
kgth1-r  KG  KG     dotum   dotum   dotum   dotum
kgth2-r  KG  KG     dotum   dotum   dotum   dotum
cmin1-r  CM  CM     simsun  simsun  simsun  simsun
cmin2-r  CM  CM     simsun  simsun  simsun  simsun
cgth1-r  CM  simhei simhei  simhei  simhei  simhei
cgth2-r  CM  simhei simhei  simhei  simhei  simhei
tmin1-r  TM  TM     mingliu mingliu mingliu mingliu
tmin2-r  TM  TM     mingliu mingliu mingliu mingliu
tgth1-r  TG  TG     mingliu mingliu mingliu mingliu
tgth2-r  TG  TG     mingliu mingliu mingliu mingliu
END
# S      FFF            R     - W
# j=��   min=����       0=JIS   r=�W��
# k=��   gth=�S�V�b�N   1=UniXX m=��
# c=�Ȓ� mgt=�ۃS�V�b�N 2=CID   b=��
# t=�ɒ�                        l=��
#                               e=�ɑ�
# R �̓T�|�[�g���ׂ�����(�O���t)�͈̔́B1 �� UniJIS, UniKS �����w���B
# W=r �͒P�E�F�C�g���̎w��B

  # assign_table �ŗp����ȗ����̎w��B
my $font_alias_table = <<'END';
JM0     Ryumin-Light
JG0     GothicBBB-Medium
JM      KozMinPro-Regular
JG      KozGoPro-Medium
KM      HYSMyeongJo-Medium
KG      HYGoThic-Medium
CM      STSong-Light
TM      MSung-Light
TG      MHei-Medium
ipam    ipam.ttf                   # IPA����
ipag    ipag.ttf                   # IPA�S�V�b�N
msmin   :0:msmincho.ttc            # �l�r ����
msgoth  :0:msgothic.ttc            # �l�r �S�V�b�N
hgrmb   :0:hgrmb.ttc               # HG����B
hgrme   :0:hgrme.ttc               # HG����E
hgrpre  :0:hgrpre.ttc              # HG�n�p��ھ�ݽEB
hgrgm   :0:hgrgm.ttc               # HG�޼��M
hgrge   :0:hgrge.ttc               # HG�޼��E
hgrsgu  :0:hgrsgu.ttc              # HG�n�p�p�޼��UB
hgrsmp  hgrsmp.ttf                 # HG�ۺ޼��M-PRO
hgrkk   :0:hgrkk.ttc               # HG���ȏ���
hgrskp  hgrskp.ttf                 # HG��������-PRO
hgrgy   :0:hgrgy.ttc               # HG�s����
hgrpp1  :0:hgrpp1.ttc              # HG�n�p�p�߯�ߑ�
batang  :1:batang.ttc              # BatangChe
dotum   :3:gulim.ttc               # DotumChe
simsun  :0:simsun.ttc              # SimSun
simhei  simhei.ttf                 # SimHei
mingliu :0:mingliu.ttc             # MingLiU
END

# dvipdfmx predefined fonts
#  Ryumin-Light                 (Adobe-Japan1-2)
#  GothicBBB-Medium             (Adobe-Japan1-2)
#  MHei-Medium-Acro             (Adobe-CNS1-0)
#  MSung-Light-Acro             (Adobe-CNS1-0)
#  STSong-Light-Acro            (Adobe-GB1-2)
#  HeiseiKakuGo-W5-Acro         (Adobe-Japan1-2)
#  HeiseiMin-W3-Acro            (Adobe-Japan1-2)
#  HYGoThic-Medium-Acro         (Adobe-Korea1-1)
#  HYSMyeongJo-Medium-Acro      (Adobe-Korea1-1)
#  MSungStd-Light-Acro          (Adobe-CNS1-4)
#  STSongStd-Light-Acro         (Adobe-GB1-4)
#  HYSMyeongJoStd-Medium-Acro   (Adobe-Korea1-2)
#  AdobeMingStd-Light-Acro      (Adobe-CNS1-4)
#  AdobeSongStd-Light-Acro      (Adobe-GB1-4)
#  KozMinPro-Regular-Acro       (Adobe-Japan1-4)
#  KozGoPro-Medium-Acro         (Adobe-Japan1-4)
#  AdobeMyungjoStd-Medium-Acro  (Adobe-Korea1-2)
#  KozMinProVI-Regular          (Adobe-Japan1-6)

MAIN:{
  my ($t, $u, $hm, $fn, $map, $lin, @lins, @fons, @pars, @font);
  local ($/);
  foreach $lin (split(/\n/, $font_alias_table)) {
    ($u, $fn) = split(/\s+/, $lin, 3);
    (defined $fn)
      or die "error in font_alias_table, entry $u";
    $ali{$u} = $fn;
  }
  ($lin, @lins) = split(/\n/, $assign_table);
  ($t, @pars) = split(/\s+/, $lin);
  ($t eq '*')
    or die "error in assign_table, header line";
  foreach $lin (@lins) {
    ($fn, @fons) = split(/\s+/, $lin);
    ($#fons == $#pars)
      or die "error in assign_table, entry $fn";
    foreach (0 .. $#pars) {
      $t = $fons[$_];
      if (defined($ali{$t})) { $t = $ali{$t}; }
      $font[$_]{$fn} = $t;
    }
  }
  $map = <DATA>; $map =~ s/^\#.*\n//gm; $map =~ s/\#.*$//gm;
  foreach (0 .. $#pars) {
    $u = $base_name . $pars[$_] . '.map';
    open($hm, '>', $u) or die "failed in opening '$u'";
    ($t = $map) =~ s/\$filename/$u/g;
    $t =~ s[\$([\w\-]+)(/A\w+)?]{
      $fn = $font[$_]{$1}; $u = $2;
      (defined $u && $fn =~ /\.tt[cf]$/i) ? "$fn$u" : $fn
    }ge;
    print $hm ($t);
    close($hm);
  }
}

__DATA__
%%
%% $filename
%%

%%%%%%%%------------
%%%%%%%% ASCII pTeX 
%%%%%%%%------------

%%%% Standard Fonts

% Mincho
rml                 H                   $jmin0-r
rmlv                V                   $jmin0-r
% Gothic
gbm                 H                   $jgth0-r
gbmv                V                   $jgth0-r

%%%% 'utf' Package by S. Saito

% Mincho, \UTF
unijmin-h           UniJIS-UTF16-H      $jmin1-r
unijmin-v           UniJIS-UTF16-V      $jmin1-r
% Mincho, \CID
cidmin-h            Identity-H          $jmin2-r/AJ16
cidmin-v            Identity-V          $jmin2-r/AJ16
% Mincho, direct input
hmr                 H                   $jmin0-r
hmrv                V                   $jmin0-r

% Gothic, \UTF
unijgoth-h          UniJIS-UTF16-H      $jgth1-r
unijgoth-v          UniJIS-UTF16-V      $jgth1-r
% Gothic, \CID
cidgoth-h           Identity-H          $jgth2-r/AJ16
cidgoth-v           Identity-V          $jgth2-r/AJ16
% Gothic, direct input
hkb                 H                   $jgth0-r
hkbv                V                   $jgth0-r


%%%% 'otf' Package by S. Saito

%% JAPANESE

% Mincho, Medium, \UTF
otf-ujmr-h          UniJIS-UTF16-H      $jmin1-m
otf-ujmr-v          UniJIS-UTF16-V      $jmin1-m
% Mincho, Medium, \CID
otf-cjmr-h          Identity-H          $jmin2-m/AJ16
otf-cjmr-v          Identity-V          $jmin2-m/AJ16
% Mincho, Medium, direct input
hminr-h             H                   $jmin0-m
hminr-v             V                   $jmin0-m

% Gothic, Medium, \UTF
otf-ujgr-h          UniJIS-UTF16-H      $jgth1-m
otf-ujgr-v          UniJIS-UTF16-V      $jgth1-m
% Gothic, Medium, \CID
otf-cjgr-h          Identity-H          $jgth2-m/AJ16
otf-cjgr-v          Identity-V          $jgth2-m/AJ16
% Gothic, Medium, direct input
hgothr-h            H                   $jgth0-m
hgothr-v            V                   $jgth0-m

% Mincho, Bold, \UTF
otf-ujmb-h          UniJIS-UTF16-H      $jmin1-b
otf-ujmb-v          UniJIS-UTF16-V      $jmin1-b
% Mincho, Bold, \CID
otf-cjmb-h          Identity-H          $jmin2-b/AJ16
otf-cjmb-v          Identity-V          $jmin2-b/AJ16
% Mincho, Bold, direct input
hminb-h             H                   $jmin0-b
hminb-v             V                   $jmin0-b

% Gothic, Bold, \UTF
otf-ujgb-h          UniJIS-UTF16-H      $jgth1-b
otf-ujgb-v          UniJIS-UTF16-V      $jgth1-b
% Gothic, Bold, \CID
otf-cjgb-h          Identity-H          $jgth2-b/AJ16
otf-cjgb-v          Identity-V          $jgth2-b/AJ16
% Gothic, Bold, direct input
hgothb-h            H                   $jgth0-b
hgothb-v            V                   $jgth0-b

% Maru-Gothic, Regular, \UTF
otf-ujmgr-h         UniJIS-UTF16-H      $jmgt1-r
otf-ujmgr-v         UniJIS-UTF16-V      $jmgt1-r
% Maru-Gothic, Regular, \CID
otf-cjmgr-h         Identity-H          $jmgt2-r/AJ16
otf-cjmgr-v         Identity-V          $jmgt2-r/AJ16
% Maru-Gothic, Regular, direct input
hmgothr-h           H                   $jmgt0-r
hmgothr-v           V                   $jmgt0-r

% Mincho, Light, \UTF
otf-ujml-h          UniJIS-UTF16-H      $jmin1-l
otf-ujml-v          UniJIS-UTF16-V      $jmin1-l
% Mincho, Light, \CID
otf-cjml-h          Identity-H          $jmin2-l/AJ16
otf-cjml-v          Identity-V          $jmin2-l/AJ16
% Mincho, Light, direct input
hminl-h             H                   $jmin0-l
hminl-v             V                   $jmin0-l

% Gothic, Extra-Bold, direct input
hgotheb-h           H                   $jgth0-e
hgotheb-v           V                   $jgth0-e

%% KOREAN

% Mincho(Myeongjo), \UTFK
otf-ukmr-h          UniKS-UCS2-H        $kmin1-r
otf-ukmr-v          UniKS-UCS2-V        $kmin1-r
% Mincho(Myeongjo), \CIDK
otf-ckmr-h          Identity-H          $kmin2-r/AK12
otf-ckmr-v          Identity-V          $kmin2-r/AK12
% Gothic(Gothic), \UTFK
otf-ukgr-h          UniKS-UCS2-H        $kgth1-r
otf-ukgr-v          UniKS-UCS2-V        $kgth1-r
% Gothic(Gothic), \CIDK
otf-ckgr-h          Identity-H          $kgth2-r/AK12
otf-ckgr-v          Identity-V          $kgth2-r/AK12

%% SIMPLIFIED CHINESE

% Mincho(Song), \UTFC
otf-ucmr-h          UniGB-UCS2-H        $cmin1-r
otf-ucmr-v          UniGB-UCS2-V        $cmin1-r
% Mincho(Song), \CIDC
otf-ccmr-h          Identity-H          $cmin2-r/AG14
otf-ccmr-v          Identity-V          $cmin2-r/AG14
% Gothic(Hei), \UTFC
otf-ucgr-h          UniGB-UCS2-H        $cgth1-r
otf-ucgr-v          UniGB-UCS2-V        $cgth1-r
% Gothic(Hei), \CIDC
otf-ccgr-h          Identity-H          $cgth2-r/AG14
otf-ccgr-v          Identity-V          $cgth2-r/AG14

%% TRADITIONAL CHINESE

% Mincho(Song), \UTFT
otf-utmr-h          UniCNS-UCS2-H       $tmin1-r
otf-utmr-v          UniCNS-UCS2-V       $tmin1-r
% Mincho(Song), \CIDT
otf-ctmr-h          Identity-H          $tmin2-r/AC14
otf-ctmr-v          Identity-V          $tmin2-r/AC14
% Gothic(Hei), \UTFT
otf-utgr-h          UniCNS-UCS2-H       $tgth1-r
otf-utgr-v          UniCNS-UCS2-V       $tgth1-r
% Gothic(Hei), \CIDT
otf-ctgr-h          Identity-H          $tgth2-r/AC14
otf-ctgr-v          Identity-V          $tgth2-r/AC14

%%%% 'morisawa' Package by H. Okumura

ryumin-l            H                   $jmin0-m
ryumin-l-v          V                   $jmin0-m
gtbbb-m             H                   $jgth0-m
gtbbb-m-v           V                   $jgth0-m
futomin-b           H                   $jmin0-b
futomin-b-v         V                   $jmin0-b
futogo-b            H                   $jgth0-b
futogo-b-v          V                   $jgth0-b
jun101-l            H                   $jmgt0-r
jun101-l-v          V                   $jmgt0-r

%%%%%%%%--------------------------
%%%%%%%% upTeX  by TANAKA, Takuji
%%%%%%%%--------------------------

%% 'upjis' Series

% Mincho
uprml-h             UniJIS-UTF16-H      $jmin1-r
uprml-v             UniJIS-UTF16-V      $jmin1-r
uprml-hq            UniJIS-UCS2-H       $jmin1-r
% Gothic
upgbm-h             UniJIS-UTF16-H      $jgth1-r
upgbm-v             UniJIS-UTF16-V      $jgth1-r
upgbm-hq            UniJIS-UCS2-H       $jgth1-r

%% 'ujis' Series

% Mincho
urml                UniJIS-UTF16-H      $jmin1-r
urmlv               UniJIS-UTF16-V      $jmin1-r
% Gothic
ugbm                UniJIS-UTF16-H      $jgth1-r
ugbmv               UniJIS-UTF16-V      $jgth1-r

%% Addition for CJK

uphysmjm-h          UniKS-UTF16-H       $kmin1-r
uphysmjm-v          UniKS-UTF16-V       $kmin1-r
uphygt-h            UniKS-UTF16-H       $kgth1-r
uphygt-v            UniKS-UTF16-V       $kgth1-r
upstsl-h            UniGB-UTF16-H       $cmin1-r
upstsl-v            UniGB-UTF16-V       $cmin1-r
upstht-h            UniGB-UTF16-H       $cgth1-r
upstht-v            UniGB-UTF16-V       $cgth1-r
upmsl-h             UniCNS-UTF16-H      $tmin1-r
upmsl-v             UniCNS-UTF16-V      $tmin1-r
upmhm-h             UniCNS-UTF16-H      $tgth1-r
upmhm-v             UniCNS-UTF16-V      $tgth1-r

%%%%%%%%--------
%%%%%%%% LuaTeX
%%%%%%%%--------

luarml              UniJIS-UCS2-H       $jmin0-r
luagbm              UniJIS-UCS2-H       $jgth0-r
luarmlv             UniJIS-UCS2-V       $jmin0-r
luagbmv             UniJIS-UCS2-V       $jgth0-r


%%%% EOF
