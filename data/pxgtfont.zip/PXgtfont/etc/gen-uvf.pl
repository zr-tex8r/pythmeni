use strict;
use ZRTeXtor ':all';
use ZRJCode ':all';
use constant { MAXGT => 78774, MAXFN => 13, MAXKFN => 2 };
use constant { GETA => '01-81AC' };
use constant { UGETA => 0x3013 };
require 'map.pl';
require 'ucmap.pl';

sub main {
  jy2_generate(0);
  jy2_generate(1);
  j48_generate(0);
  j48_generate(1);
  zgu_generate();
}

##------ j48/j58 encoding

sub j48_generate {
  my ($swvt) = @_; my ($zvp, $vf, $tfm, $enc);
  $enc = ($swvt) ? 'j58' : 'j48';
  $zvp = join('', u_zvp_prologue("GT-KANJI", $swvt),
              j48_mapfont($swvt),
              j48_space(), u_type(), j48_character());
  write_whole_file("gtmc-r-$enc.zvp", $zvp);
}

sub j48_mapfont {
  my ($swvt) = @_; my ($n, $fid, $fnm, @cnks);
  foreach $n (1 .. MAXFN) {
    $fid = $n - 1;
    $fnm = ($n > 1) ? ("gtmc-r-" . j48_encname($n, $swvt)) :
           ($swvt) ? "r-gtmc-r-jt1" : "r-gtmc-r-jy1";
    push(@cnks, <<"END");
(MAPFONT D $fid
   (FONTNAME $fnm)
   (FONTDSIZE R 10.0)
   (FONTAT R 1.0)
   )
END
  }
  return join('', @cnks);
}

sub j48_encname {
  my ($n, $swvt) = @_; my ($nam);
  $nam = sprintf("g%02d", $n);
  if ($swvt) {
    $nam =~ s/g0/gv/g; $nam =~ s/g1/gw/g;
  }
  return $nam;
}

sub j48_space {
  my $gc = in_hex(MAXGT);
  return "(CODESPACE (CTRANGE H 1 H $gc))\n";
}

sub j48_character {
  my ($t, $gc, $gx, $ss, $fid, $sx, $jx, @cnks);
  foreach $gc (1 .. MAXGT) {
    (($ss = sjposition($gc)) =~ m/-/) or $ss = GETA;
    (($fid, $sx) = $ss =~ m/^(..)-(....)$/) or die $ss;
    $fid -= 1; $gx = in_hex($gc);
    $jx = in_hex(in_jis(sjis(hex($sx))));
    $t = ($fid > 0) ? "(SELECTFONT D $fid)" : "";
    $t = "(CHARACTER H $gx (MAP $t (SETCHAR H $jx) ) )\n";
    push(@cnks, $t);
  }
  return join('', @cnks);
}

##------ zgu encoding

sub zgu_generate {
  my ($zvp, $vf, $tfm, $map);
  $map = zgu_genmap();
  $zvp = join('', u_zvp_prologue(""), u_mapfont(1),
                  u_type(), zgu_space($map), zgu_character($map));
  write_whole_file("gtmc-r-zgu.zvp", $zvp);
}

sub zgu_genmap {
  my ($t, $uc, $fid, %u2j, %map);
  foreach $t (1410 .. 4374, 4418 .. 7807) {
    $u2j{in_ucs($t)} = in_jis($t);
  }
  foreach $fid (0 .. (MAXFN + MAXKFN - 1)) {
    $t = $fid * 0x10000;
    foreach $uc (keys %u2j) {
      $map{$t + $uc} = sprintf("%d-%04X", $fid, $u2j{$uc});
    }
  }
  return \%map;
}


sub zgu_space {
  my ($map) = @_; my ($t);
  $t = join("\n", map { sprintf("X%04X", $_) }
                     (sort { $a <=> $b } (keys %$map)));
  return "(CODESPACE $t)\n";
}

sub zgu_character {
  my ($map) = @_; my ($t, $fid, $jx, $uc, $ux, @ucs, @cnks);
  @ucs = sort { $a <=> $b } (keys %$map);
  foreach $uc (@ucs) {
    (defined($t = $map->{$uc})) or next;
    ($fid, $jx) = split(m/-/, $t); $ux = in_hex($uc);
    $t = ($fid > 0) ? "(SELECTFONT D $fid)" : "";
    $t = "(CHARACTER H $ux (MAP $t (SETCHAR H $jx) ) )\n";
    push(@cnks, $t);
  }
  return join('', @cnks);
}

##------ jy2/jt2 encoding

sub jy2_generate {
  my ($swvt) = @_; my ($zvp, $vf, $tfm, $enc);
  $enc = ($swvt) ? 'jt2' : 'jy2';
  $zvp = join('', u_zvp_prologue("UNICODE-BMP", $swvt),
              jy2_mapfont($swvt), jy2_gluekern($swvt),
              jy2_space($swvt), jy2_type_character($swvt));
  write_whole_file("gtmc-r-$enc.zvp", $zvp);
}

sub jy2_mapfont {
  my ($swvt) = @_;
  return jy2_select(<<"END", $swvt);
(MAPFONT D 0
Y>   (FONTNAME r-gtmc-r-jy2)
T>   (FONTNAME r-gtmc-r-jt2)
   (FONTCHECKSUM O 0)
   (FONTAT R 1.0)
   (FONTDSIZE R 10.0)
   )
(MAPFONT D 1
Y>   (FONTNAME gtmc-r-j48)
T>   (FONTNAME gtmc-r-j58)
   (FONTCHECKSUM O 0)
   (FONTAT R 1.0)
   (FONTDSIZE R 10.0)
   )
END
}

sub jy2_gluekern {
  my ($swvt) = @_;
  return jy2_select(<<"END", $swvt);
(GLUEKERN
   (LABEL D 0)
   (GLUE D 1 R 0.5 R 0.0 R 0.5)
   (GLUE D 3 R 0.25 R 0.0 R 0.25)
   (STOP)
   (LABEL D 1)
   (GLUE D 3 R 0.25 R 0.0 R 0.25)
   (STOP)
   (LABEL D 2)
   (GLUE D 0 R 0.5 R 0.0 R 0.5)
   (GLUE D 1 R 0.5 R 0.0 R 0.5)
   (GLUE D 3 R 0.25 R 0.0 R 0.25)
   (GLUE D 5 R 0.5 R 0.0 R 0.5)
Y>   (GLUE D 6 R 0.5 R 0.0 R 0.5)
   (STOP)
   (LABEL D 3)
   (GLUE D 0 R 0.25 R 0.0 R 0.25)
   (GLUE D 1 R 0.25 R 0.0 R 0.25)
   (GLUE D 2 R 0.25 R 0.0 R 0.25)
   (GLUE D 3 R 0.5 R 0.0 R 0.25)
   (GLUE D 4 R 0.25 R 0.0 R 0.25)
   (GLUE D 5 R 0.25 R 0.0 R 0.25)
Y>   (GLUE D 6 R 0.25 R 0.0 R 0.25)
   (STOP)
   (LABEL D 4)
   (GLUE D 0 R 0.5 R 0.0 R 0.0)
   (GLUE D 1 R 0.5 R 0.0 R 0.0)
   (GLUE D 3 R 0.75 R 0.0 R 0.25)
   (GLUE D 5 R 0.5 R 0.0 R 0.0)
Y>   (GLUE D 6 R 0.5 R 0.0 R 0.0)
   (STOP)
   (LABEL D 5)
   (GLUE D 1 R 0.5 R 0.0 R 0.5)
   (GLUE D 3 R 0.25 R 0.0 R 0.25)
   (KRN D 5 R 0.0)
   (STOP)
Y>   (LABEL D 6)
Y>   (GLUE D 1 R 0.5 R 0.0 R 0.5)
Y>   (GLUE D 3 R 0.25 R 0.0 R 0.25)
Y>   (STOP)
   )
END
}

sub jy2_space {
  my ($swvt) = @_;
  return jy2_select(<<"END", $swvt);
(CODESPACE
   X00A2 X00A3 X00A7 X00A8 X00AB X00AC X00AF X00B0 X00B1 X00B4 X00B5
   X00B6 X00B7 X00B8 X00BB X00D7 X00F7
   (CTRANGE H 391 H 3A1)
   X03A3 X03A4 X03A5 X03A6 X03A7 X03A8 X03A9
   (CTRANGE H 3B1 H 3C1)
   X03C3 X03C4 X03C5 X03C6 X03C7 X03C8 X03C9 X0401
   (CTRANGE H 410 H 44F)
   X0451 X2010 X2015 X2018 X2019 X201C X201D X2020 X2021 X2025 X2026
   X2030 X2032 X2033 X203B X2103 X2116 X2121 X212B
   (CTRANGE H 2160 H 2169)
   (CTRANGE H 2170 H 2179)
   X2190 X2191 X2192 X2193 X21D2 X21D4 X2200 X2202 X2203 X2207 X2208
   X220B X2211 X221A X221D X221E X221F X2220 X2225 X2227 X2228 X2229
   X222A X222B X222C X222E X2234 X2235 X223D X2252 X2260 X2261 X2266
   X2267 X226A X226B X2282 X2283 X2286 X2287 X22A5 X22BF X2312
   (CTRANGE H 2460 H 2473)
   X2500 X2501 X2502 X2503 X250C X250F X2510 X2513 X2514 X2517 X2518
   X251B X251C X251D X2520 X2523 X2524 X2525 X2528 X252B X252C X252F
   X2530 X2533 X2534 X2537 X2538 X253B X253C X253F X2542 X254B X25A0
   X25A1 X25B2 X25B3 X25BC X25BD X25C6 X25C7 X25CB X25CE X25CF X25EF
   X2605 X2606 X2640 X2642 X266A X266D X266F X3000 X3001 X3002 X3003
   (CTRANGE H 3005 H 3015)
   X301D X301F
   (CTRANGE H 3041 H 3094)
   X309B X309C X309D X309E
   (CTRANGE H 30A1 H 30F6)
   X30FB X30FC X30FD X30FE X3231 X3232 X3239 X32A4 X32A5 X32A6 X32A7
   X32A8 X3303 X330D X3314 X3318 X3322 X3323 X3326 X3327 X332B X3336
   X333B X3349 X334A X334D X3351 X3357 X337B X337C X337D X337E X338E
   X338F X339C X339D X339E X33A1 X33C4 X33CD
   (CTRANGE H 4E00 H 9FA5)
   (CTRANGE H F900 H FA6A)
   (CTRANGE H FF01 H FF5E)
Y>   (CTRANGE H FF61 H FF9F)
   XFFE0 XFFE1 XFFE2 XFFE3 XFFE4 XFFE5
T>   XFDD1
   )
END
}

sub jy2_type_character {
  my ($swvt) = @_; my ($uc, $gt, $ucx, $gtx, @cnks);
  foreach $uc (0x4e00..0x9fa5, 0xf900..0xfa6a) {
    (avail_jis($uc)) and next;
    $ucx = in_hex($uc); $gt = uctogt($uc);
    if (defined $gt) {
      $gtx = in_hex($gt); push(@cnks, <<"END");
(CHARACTER H $ucx (MAP (SELECTFONT D 1) (SETCHAR H $gtx)))
END
    } else {
      $gtx = in_hex(UGETA); push(@cnks, <<"END");
(CHARACTER H $ucx (MAP (SETCHAR H $gtx)))
END
    }
  }
  return join('', jy2_select(<<"END", $swvt), @cnks);
(CHARSINTYPE D 1
   X2018 X201C X3008 X300A X300C X300E X3010 X3014 X301D XFF08 XFF3B
   XFF5B
   )
(CHARSINTYPE D 2
   X2019 X201D X3001 X3009 X300B X300D X300F X3011 X3015 X301F XFF09
   XFF0C XFF3D XFF5D
   )
(CHARSINTYPE D 3
   X30FB XFF1A XFF1B
   )
(CHARSINTYPE D 4
   X3002 XFF0E
   )
(CHARSINTYPE D 5
   X2015 X2025 X2026
   )
Y>(CHARSINTYPE D 6
Y>   (CTRANGE H FF61 H FF9F)
Y>   )
(TYPE D 0
   (CHARWD R 1.0)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (SETCHAR)
      )
   )
(TYPE D 1
   (CHARWD R 0.5)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (MOVERIGHT R -0.5)
      (SETCHAR)
      )
   )
(TYPE D 2
   (CHARWD R 0.5)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (SETCHAR)
      )
   )
(TYPE D 3
   (CHARWD R 0.5)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (MOVERIGHT R -0.25)
      (SETCHAR)
      )
   )
(TYPE D 4
   (CHARWD R 0.5)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (SETCHAR)
      )
   )
(TYPE D 5
   (CHARWD R 1.0)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
T>   (CHARHT R 0.5)
T>   (CHARDP R 0.5)
   (MAP
      (SETCHAR)
      )
   )
Y>(TYPE D 6
Y>   (CHARWD R 0.5)
Y>   (CHARHT R 0.88)
Y>   (CHARDP R 0.12)
Y>   (MAP
Y>      (SETCHAR)
Y>      )
Y>   )
T>(CHARACTER H FDD1
T>   (MAP
T>      (MOVERIGHT R 0.000001)
T>      )
T>   )
END
}

sub jy2_select {
  my ($txt, $swvt) = @_;
  if ($swvt) {
    $txt =~ s/^T>//gm; $txt =~ s/^Y>.*\n//gm;
  } else {
    $txt =~ s/^Y>//gm; $txt =~ s/^T>.*\n//gm;
  }
  return $txt;
}

##------ common subproc

sub u_zvp_prologue {
  my ($ncs, $swvt) = @_;
  if (!$swvt) {
    return <<"END";
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME $ncs)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
END
  } else {
    return <<"END";
(DIRECTION TATE)
(VTITLE GTMINCHO)
(FAMILY GTMINCHO)
(FACE F MRR)
(CODINGSCHEME $ncs)
(DESIGNSIZE R 10.0)
(CHECKSUM O 0)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.1)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.25)
   (EXTRASTRETCH R 0.2)
   (EXTRASHRINK R 0.125)
   )
END
  }
}

sub u_mapfont {
  my ($sw) = @_; my ($n, $fid, $fnam, @c, @cnks);
  @c = ($sw) ? ('k1', 'k2') : (); $fid = 0;
  foreach $n (1 .. MAXFN, @c) {
    if ($n =~ m/^k/) {
      $fnam = "gtmc-r-g$n";
    } else {
      $fnam = ($n > 1) ? sprintf("gtmc-r-g%02d", $n) :
                "r-gtmc-r-jy1";
    }
    push(@cnks, <<"END");
(MAPFONT D $fid
   (FONTNAME $fnam)
   (FONTDSIZE R 10.0)
   (FONTAT R 1.0)
   )
END
    $fid++;
  }
  return join('', @cnks);
}

sub u_type {
  return <<"END";
(TYPE D 0
   (CHARWD R 1.0)
   (CHARHT R 0.88)
   (CHARDP R 0.12)
   )
END
}


##------ go to main
main();
## EOF
