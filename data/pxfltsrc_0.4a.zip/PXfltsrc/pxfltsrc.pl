#!/usr/bin/perl
# pxfltsrc.pl
#
use strict;
use Encode qw(encode decode);
my $prog_name = 'pxfltsrc';
my $version = '0.4a';
my $mod_date = '2009/07/05';

#### globals
my $tempbase = '_pxfl_';
#
my ($mode, $ansfile, $hanswer);
my (%dict, %dictaj, %xcode, @conv, $rxtarget, $rxsip);
my ($swlax, $swuseux, $swuseaj);
my $BC1 = "\x{FDD1}"; # a not-a-char used as flag
my $BC2 = "\x{FDD2}"; # a not-a-char used as flag
use constant {
  EUC => 0, SJIS => 1, CP932 => 2, JIS => 3, UTF8 => 4, 
  THRU => 5, BYTE => 6, AUTO => 7,
};
my @encname = (
  'eucjp', 'shiftjis', 'cp932', 'iso-2022-jp', 'utf-8',
);
my %partable = (
  ultn1   => ['u', 0],
  ugrek   => ['u', 1],
  cgrek   => ['c', 1],
  ucyrl   => ['u', 2],
  ccyrl   => ['c', 2],
  upnct   => ['u', 3],
  umsym   => ['u', 4],
  uxsym   => ['u', 5],
  uhwka   => ['u', 6],
  chwka   => ['c', 6],
  ukanji  => ['u', 7],
  cxkana  => ['c', 10],
  jis     => ['i', JIS],
  sjis    => ['i', SJIS],
  euc     => ['i', EUC],
  utf8    => ['i', UTF8],
  winj    => ['i', CP932],
  byte    => ['i', BYTE],
  thru    => ['i', THRU],
  inauto  => ['i', AUTO],
  outjis  => ['o', JIS],
  outsjis => ['o', SJIS],
  outeuc  => ['o', EUC],
  oututf8 => ['o', UTF8],
  lax     => ['s', \$swlax],
  useux   => ['s', \$swuseux],
  useaj   => ['s', \$swuseaj],
);
# 
my @checkdbc = (
  qr/^[\x8e\xa1-\xfe][\xa1-\xfe]/,                #EUC
  qr/^[\x81-\x9f\xe0-\xfc][\x40-\x7e\x80-\xfc]/,  #SJIS
  qr/^[\x81-\x9f\xe0-\xfc][\x40-\x7e\x80-\xfc]/,  #CP932
);
my @range = (
  [ 0x0080, 0x00FF ],  # 0: ltn1: Latin-1 Supplement
  [ 0x0370, 0x03FF ],  # 1: grek: Greek and Coptic
  [ 0x0400, 0x04FF ],  # 2: cyrl: Cyrillic
  [ 0x2000, 0x206F ],  # 3: pnct: General Punctuation
  [ 0x2190, 0x23FF ],  # 4: msym: (mathmatical symbols)
  [ 0x2100, 0x214F, 0x25A0, 0x26FF ], # 5: xsym: (other symbols)
  [ 0xFF60, 0xFF9F ],  # 6: hwka: (halfwidth katakana)
  [ 0x4E00, 0x9FA5 ],  # 7: kanji: CJK Unified Ideograph (3.2)
);
my @namegen = (
  undef,
  ['ZTSgrk', (undef) x 33, qw(Alpha Beta Gamma Delta Epsilon Zeta),
   qw(Eta Theta Iota Kappa Lambda Mu Nu Xi Omicron Pi Rho), undef,
   qw(Sigma Tau Upsilon Phi Chi Psi Omega), (undef) x 7,
   qw(alpha beta gamma delta epsilon zeta eta theta iota kappa),
   qw(lambda mu nu xi omicron pi rho), undef, qw(sigma tau upsilon),
   qw(phi chi psi omega) ],
  ['ZTScyr', undef, qw(Yo), (undef) x 14, qw(A B V G D E Zh Z I),
   qw(Ishrt K L M N O P R S T U F H C Ch Sh Shch Hrdsn Ery Sftsn),
   qw(Erev Yu Ya a b v g d e zh z i ishrt k l m n o p r s t u),
   qw(f h c ch sh shch hrdsn ery sftsn), undef, qw(yo) ],
  undef, undef, undef,
  ['ZTShwk', undef, qw( period bracketleft bracketright comma),
    qw(middledot wo asmall ismall usmall esmall osmall yasmall),
    qw(yusmall yosmall tusmall prolongmark a i u e o ka ki ku ke),
    qw(ko sa si su se so ta ti tu te to na ni nu ne no ha hi hu he),
    qw(ho ma mi mu me mo ya yu yo ra ri ru re ro wa n voicedmark),
    qw(semivoicedmark) ],
);
my %cchrgen = (
  10 => [
  ["hirkasvd",        0x82F5, 0xA4F7, 0x304B, 0x309A], # 1-04-87
  ["hirkisvd",        0x82F6, 0xA4F8, 0x304D, 0x309A], # 1-04-88
  ["hirkusvd",        0x82F7, 0xA4F9, 0x304F, 0x309A], # 1-04-89
  ["hirkesvd",        0x82F8, 0xA4FA, 0x3051, 0x309A], # 1-04-90
  ["hirkosvd",        0x82F9, 0xA4FB, 0x3053, 0x309A], # 1-04-91
  ["katkasvd",        0x8397, 0xA5F7, 0x30AB, 0x309A], # 1-05-87
  ["katkisvd",        0x8398, 0xA5F8, 0x30AD, 0x309A], # 1-05-88
  ["katkusvd",        0x8399, 0xA5F9, 0x30AF, 0x309A], # 1-05-89
  ["katkesvd",        0x839A, 0xA5FA, 0x30B1, 0x309A], # 1-05-90
  ["katkosvd",        0x839B, 0xA5FB, 0x30B3, 0x309A], # 1-05-91
  ["katsesvd",        0x839C, 0xA5FC, 0x30BB, 0x309A], # 1-05-92
  ["kattusvd",        0x839D, 0xA5FD, 0x30C4, 0x309A], # 1-05-93
  ["kattosvd",        0x839E, 0xA5FE, 0x30C8, 0x309A], # 1-05-94
  ["katsmallhusvd",   0x83F6, 0xA6F8, 0x31F7, 0x309A], # 1-06-88
  ],
  11 => [
  ["lataegrave"   ,   0x8663, 0xABC4, 0x00E6, 0x0300], # 1-11-36
  ["latopenograve",   0x8667, 0xABC8, 0x0254, 0x0300], # 1-11-40
  ["latopenoacute",   0x8668, 0xABC9, 0x0254, 0x0301], # 1-11-41
  ["latturnvgrave",   0x8669, 0xABCA, 0x028C, 0x0300], # 1-11-42
  ["latturnvacute",   0x866A, 0xABCB, 0x028C, 0x0301], # 1-11-43
  ["latschwagrave",   0x866B, 0xABCC, 0x0259, 0x0300], # 1-11-44
  ["latschwaacute",   0x866C, 0xABCD, 0x0259, 0x0301], # 1-11-45
  ["latschwahkgrave", 0x866D, 0xABCE, 0x025A, 0x0300], # 1-11-46
  ["latschwahkacute", 0x866E, 0xABCF, 0x025A, 0x0301], # 1-11-47
  ["symrising",       0x8685, 0xABE5, 0x02E9, 0x02E5], # 1-11-69
  ["symfalling",      0x8686, 0xABE6, 0x02E5, 0x02E9], # 1-11-70
  ],
);
my %ucs2aj = (
  0x2000b=>13839, 0x20089=>17233, 0x2008a=>14108, 0x200a2=>17240,
  0x200a4=>17243, 0x200b0=>14209, 0x200f5=>20057, 0x20158=>20075,
  0x201a2=>13857, 0x20213=>17259, 0x2032b=>17282, 0x20371=>17291,
  0x20381=>17289, 0x203f9=>17295, 0x2044a=>17297, 0x20509=>17299,
  0x205b1=>20080, 0x205d6=>17308, 0x20611=>14294, 0x20628=>14105,
  0x206ec=>20083, 0x2074f=>17312, 0x20807=>17319, 0x2083a=>17321,
  0x208b9=>17327, 0x2090e=>13523, 0x2097c=>17331, 0x2099d=>17332,
  0x20a64=>13755, 0x20ad3=>17337, 0x20b1d=>17340, 0x20b9f=>13803,
  0x20bb7=>13706, 0x20d45=>17359, 0x20d58=>20090, 0x20de1=>17373,
  0x20e64=>17388, 0x20e6d=>17380, 0x20e95=>17379, 0x20f5f=>17391,
  0x21201=>17414, 0x2123d=>13953, 0x21255=>17415, 0x21274=>17421,
  0x2127b=>17417, 0x212d7=>17429, 0x212e4=>17428, 0x212fd=>17435,
  0x2131b=>16816, 0x21336=>17437, 0x21344=>17438, 0x213c4=>17449,
  0x2146d=>17462, 0x2146e=>16821, 0x215d7=>17472, 0x21647=>17480,
  0x216b4=>16838, 0x21706=>17492, 0x21742=>17493, 0x218bd=>16833,
  0x219c3=>17525, 0x21a1a=> 7825, 0x21c56=>17539, 0x21d2d=>17544,
  0x21d45=>17545, 0x21d62=>17547, 0x21d78=>17546, 0x21d92=>17556,
  0x21d9c=>17552, 0x21da1=>17551, 0x21db7=>17559, 0x21de0=>17561,
  0x21e33=>17562, 0x21e34=>16845, 0x21f1e=>17575, 0x21f76=>17582,
  0x21ffa=>17585, 0x2217b=>17599, 0x22218=>19105, 0x2231e=>17605,
  0x223ad=>17608, 0x22609=>15443, 0x226f3=>17632, 0x2285b=>17647,
  0x228ab=>17653, 0x2298f=>17657, 0x22ab8=>17667, 0x22b46=>17680,
  0x22ba6=>17683, 0x22c1d=>17682, 0x22c24=>17686, 0x22de1=>17710,
  0x22e42=>20124, 0x22feb=>20130, 0x231b6=>17744, 0x231c3=>17742,
  0x231c4=>16888, 0x231f5=>17743, 0x23372=>17761, 0x233d0=>17768,
  0x233d2=>17764, 0x233d3=>17763, 0x233d5=>17770, 0x233da=>17772,
  0x233df=>17774, 0x233e4=>17769, 0x233fe=>15422, 0x2344a=>17782,
  0x2344b=>17784, 0x23451=>17783, 0x23465=>17788, 0x234e4=>17814,
  0x2355a=>17815, 0x23594=>17827, 0x235c4=>16905, 0x23638=>17843,
  0x23639=>17841, 0x2363a=>15393, 0x23647=>17842, 0x2370c=>17863,
  0x2371c=>17854, 0x2373f=>16914, 0x23763=>16916, 0x23764=>17867,
  0x237e7=>17875, 0x237ff=>17874, 0x23824=>17880, 0x2383d=>17885,
  0x23a98=>17897, 0x23c7f=>17910, 0x23cbe=>14293, 0x23cfe=>13904,
  0x23d00=>17925, 0x23d0e=>18394, 0x23d40=>17942, 0x23dd3=>17945,
  0x23df9=>17944, 0x23dfa=>17943, 0x23f7e=>17983, 0x2404b=>20168,
  0x24096=>17998, 0x24103=>18003, 0x241c6=>18015, 0x241fe=>18018,
  0x242ee=>14282, 0x243bc=>18039, 0x243d0=> 7838, 0x24629=>18049,
  0x246a5=>18055, 0x247f1=>16970, 0x24896=>18077, 0x24a4d=>18104,
  0x24b56=>18117, 0x24b6f=>18119, 0x24c16=>18124, 0x24d14=>13995,
  0x24e04=>20058, 0x24e0e=>18158, 0x24e37=>18162, 0x24e6a=>18167,
  0x24e8b=>18170, 0x24ff2=>20059, 0x2504a=>18181, 0x25055=>18183,
  0x25122=>18185, 0x251a9=>18190, 0x251cd=>18193, 0x251e5=>18192,
  0x2521e=>18195, 0x2524c=>18197, 0x2542e=>18209, 0x2548e=>17005,
  0x254d9=>18217, 0x2550e=>17009, 0x255a7=>18229, 0x2567f=>14075,
  0x25771=>17018, 0x257a9=>18248, 0x257b4=>18249, 0x25874=> 7670,
  0x259c4=>17024, 0x259cc=>20112, 0x259d4=>18268, 0x25ae3=>18277,
  0x25ae4=>18276, 0x25af1=>18278, 0x25bb2=>18293, 0x25c4b=>18302,
  0x25c64=>18303, 0x25da1=>17033, 0x25e2e=>18318, 0x25e56=>18319,
  0x25e62=>18322, 0x25e65=>18320, 0x25ec2=>18327, 0x25ed8=>18325,
  0x25ee8=>18329, 0x25f23=>18330, 0x25f5c=>18332, 0x25fd4=>18339,
  0x25fe0=>18338, 0x25ffb=>18345, 0x2600c=>18344, 0x26017=>18352,
  0x26060=>18355, 0x260ed=>18365, 0x26270=>18385, 0x26286=>18386,
  0x2634c=>20311, 0x26402=>18398, 0x2667e=>18416, 0x266b0=>14100,
  0x2671d=>18430, 0x268dd=>18444, 0x268ea=>18446, 0x26951=>13646,
  0x2696f=>18450, 0x26999=>14134, 0x269dd=>18452, 0x26a1e=>18455,
  0x26a58=>18459, 0x26a8c=>18463, 0x26ab7=>18466, 0x26aff=>17063,
  0x26c29=>17478, 0x26c73=>18506, 0x26c9e=>20206, 0x26cdd=>18515,
  0x26e40=>17089, 0x26e65=>18528, 0x26f94=>18544, 0x26ff8=>18553,
  0x270f4=>17103, 0x2710d=>18571, 0x27139=>18574, 0x273da=>18611,
  0x273db=>18610, 0x273fe=>18617, 0x27410=>18620, 0x27449=>18624,
  0x27614=>18638, 0x27615=>18637, 0x27631=>18640, 0x27684=>17117,
  0x27693=>18645, 0x2770e=>18650, 0x27723=>18652, 0x27752=>18656,
  0x27985=>18672, 0x279b4=>20133, 0x27a84=>18684, 0x27bb3=>18699,
  0x27bbe=>18701, 0x27bc7=>18702, 0x27c3c=>20220, 0x27cb8=>18708,
  0x27d73=>20060, 0x27da0=>18716, 0x27e10=>18718, 0x27fb7=>13898,
  0x2808a=>18727, 0x280bb=>18733, 0x28277=>17140, 0x28282=>18745,
  0x282f3=>18747, 0x283cd=>17146, 0x2840c=>18754, 0x28455=>18757,
  0x2856b=>18770, 0x286d7=>18784, 0x286fa=>18787, 0x28946=>18812,
  0x28949=>18811, 0x2896b=>18817, 0x28987=>14253, 0x28988=>18824,
  0x28a1e=>18843, 0x28a29=>18844, 0x28a43=>18848, 0x28a71=>18847,
  0x28a99=>18855, 0x28acd=>18856, 0x28add=>18863, 0x28ae4=>18862,
  0x28bc1=>18874, 0x28bef=>18875, 0x28cdd=> 7641, 0x28d10=>18882,
  0x28d71=>18883, 0x28dfb=>18885, 0x28e17=>14256, 0x28e1f=>18886,
  0x28e36=>18890, 0x28e89=>18893, 0x28eeb=>18895, 0x28ef6=> 7673,
  0x28f32=>18897, 0x28ff8=>18903, 0x292a0=>18917, 0x292b1=>18918,
  0x29490=>18935, 0x295cf=>18944, 0x2967f=>13849, 0x296f0=>18959,
  0x29719=>18962, 0x29750=>18966, 0x298c6=>18983, 0x29a72=>19001,
  0x29d4b=>13717, 0x29ddb=>19026, 0x29e15=>19036, 0x29e3d=>20315,
  0x29e49=>19038, 0x29e8a=>19037, 0x29ec4=>19046, 0x29edb=>19054,
  0x29ee9=>19051, 0x29fce=>19071, 0x29fd7=>19071, 0x2a01a=>19077,
  0x2a02f=>19075, 0x2a082=>19084, 0x2a0f9=>19083, 0x2a190=>17227,
  0x2a2b2=>20072, 0x2a38c=>19109, 0x2a437=>19111, 0x2a5f1=>19123,
  0x2a602=>19125, 0x2a61a=>20316, 0x2a6b2=>19129, 0x2f804=>15388,
  0x2f80f=> 7814, 0x2f815=>20061, 0x2f818=> 7817, 0x2f81a=>13954,
  0x2f822=>13684, 0x2f828=>13807, 0x2f82c=>14109, 0x2f833=>13719,
  0x2f83f=>13815, 0x2f846=>20062, 0x2f852=>13841, 0x2f862=>13998,
  0x2f86d=>14121, 0x2f873=>13832, 0x2f877=> 7754, 0x2f884=> 7734,
  0x2f899=>20063, 0x2f89a=>13928, 0x2f8a6=>20064, 0x2f8ac=>13750,
  0x2f8b2=>13867, 0x2f8b6=>14129, 0x2f8d3=> 7816, 0x2f8db=>14140,
  0x2f8dc=> 7695, 0x2f8e1=>14291, 0x2f8e5=>20065, 0x2f8ea=>13679,
  0x2f8ed=> 7665, 0x2f8fc=>13656, 0x2f903=>13768, 0x2f90b=>13801,
  0x2f90f=>13932, 0x2f91a=>13916, 0x2f920=> 7839, 0x2f921=>13809,
  0x2f945=>13357, 0x2f947=>13854, 0x2f96c=>14180, 0x2f995=>13670,
  0x2f9d0=>14068, 0x2f9de=>20066, 0x2f9df=>14069, 0x2f9f4=>15269,
);

####------------------------------------ main procedure

sub main {
  read_option();
  if ($mode eq 'start') { proc_start(); }
  elsif ($mode eq 'dobase') { proc_do(1); }
  elsif ($mode eq 'do') { proc_do(0); }
  elsif ($mode eq 'end') { proc_end(); }
  elsif ($mode eq 'clean') { proc_clean(); }
}

####------------------------------------ 'start'

sub proc_start {
  find_encoding();
  finish("*OK");
}

sub find_encoding {
  my ($f); my ($lin, $r, $hin, $hout);
  if (!-f($f = "${tempbase}_0.tex")) { return; }
  open($hin, '<', $f)
    or error("cannot open input file: $f");
  $lin = <$hin>; chomp($lin);
  $r = ($lin eq "\x1b\x24\x42\x30\x6c\x1b\x28\x42") ? 'jis' :
       ($lin eq "\x88\xea") ? 'sjis' :
       ($lin eq "\xb0\xec") ? 'euc' :
       ($lin eq "\xe4\xb8\x80") ? 'utf8' : 
       error("unknown source encoding");
  close($hin);
  open($hout, '>', $f)
    or error("cannot open output file: $f");
  print $hout ('\filterinencoding', "{$r}\n");
  close($hout);
}

####------------------------------------ 'do'

sub proc_do {
  my ($swbas) = @_; local ($_);
  my ($t, $lin, $ofn, $ifn, $par, $swskp, $hin, $hout, @lins); 
  ($ofn, $ifn, $par) = @ARGV; $ofn = "${tempbase}_$ofn.tex";
  if (($t) = $ifn =~ m/^\*(.*)/) {
    undef $ifn;
    open($hin, '<', "$t.log")
      or error("cannot open log file: $t.log");
    foreach (1 .. 10) {
      if (!defined($lin = <$hin>)) { finish("*DK"); }
      if ($lin =~ m/^\((\S+)/ && -f $t) { $ifn = $t; last; }
    }
    (defined $ifn) or error("cannot find source file name");
    close($hin);
  } else {
    if ($ifn =~ m/\.tex$/i && !-f $ifn) { $ifn .= ".tex"; }
  }
  open($hin, '<', $ifn)
    or error("cannot open input file: $ifn");
  $swskp = $swbas;
  while ($lin = <$hin>) {
    if ($swskp) {
      if ($lin =~ m/^\s*\\(pxflstart|filterstart)[^A-Za-z]/) {
        $swskp = 0; push(@lins, $lin);
      }
    } elsif ($swbas && $lin =~ m/^\s*\\end\s*{document}/) {
      $t = '\csname pxfl@enddoctrue\endcsname';
      push(@lins, "$t\n"); last;
    } else { push(@lins, $lin); }
  }
  close($hin);
  $t = convert(join('', @lins), $par);
  open($hout, '>', $ofn)
    or error("cannot open output file: $ofn");
  print $hout ($t);
  close($hout);
  finish("*OK");
}

sub convert {
  my ($txt, $par) = @_; my ($e, $c, $t, $u, @v, $es, $us);
  my ($rxdb, $enc, $oenc, @ext);
  #
  $enc = BYTE; $oenc = JIS; @conv = ();
  @v = split(/,/, $par);
  foreach (@v) {
    if (($t) = m/^\+(.*)/) {
      push(@ext, $t);
    } elsif (defined($e = $partable{$_})) {
      $t = $e->[0];
      if ($t eq 'u' || $t eq 'c') { $conv[$e->[1]] = $t; }
      elsif ($t eq 'i') { $enc = $e->[1]; }
      elsif ($t eq 'o') { $oenc = $e->[1]; }
      elsif ($t eq 's') { ${$e->[1]} = 1; }
    } else { alert("invalid parameter: $_"); }
  }
  if ($enc == AUTO) { $enc = judge_encode($txt); }
  $rxdb = $checkdbc[$enc]; @v = ();
  make_xcode_table($enc);
  if (@conv) { make_conv_table(); }
  if ($swuseaj) { make_convaj_table(); }
  L1:{
    # step 1 : decode input text
    if ($enc == BYTE || $enc == JIS) {
      $txt =~ s/([\x80-\xff])/texesc($1)/ge;
    } 
    if ($enc == BYTE || $enc == THRU) { last L1; }
    while (1) {
      push(@v, decode($encname[$enc], $txt, Encode::FB_QUIET));
      if ($txt eq '') { last; }
      $u = (defined $rxdb && $txt =~ $rxdb) ? 2 : 1;
      $es = substr($txt, 0, $u);
      if (!defined($us = decode_ex($enc, $es))) {
        $us = ($swlax) ? texesc($es) : texwarn($es);
      }
      push(@v, $us); $txt = substr($txt, $u);
    }
    $txt = join('', @v); @v = ();
    # step 2 : replace target characters
    if (@conv) {
      $txt =~ s/$rxtarget/$dict{$1}/ge;
    }
    if ($swuseaj) {
      $txt =~ s/$rxsip/$dictaj{$1}/ge;
    }
    # step 3 : convert to output encoding
    if ($oenc == JIS || $oenc == SJIS || $oenc == EUC) {
                  # avoid buggy behaviour of Perl
      $txt =~ s/^\x{FEFF}?/\x80\x01\x02\x03/;
      $txt =~ s[([^\x00-\x7f$BC1$BC2])]{
        (length(encode($encname[SJIS], $1)) == 2) ? $1 : # in JISX0208
          format_utf8($1)
      }ge;
      $txt =~ s/^(.*?)\x02\x03//;
    }
      # process blocker characters
    $txt =~ s[$BC1(\s*[\r\n]|.|\z)]{
      (($t = $1) =~ m/[\x21-\x3f\x5b-\x60\x7b-\x7f\r\n]/) ? $t :
        "\\pxflI{}$t"
    }ges;
    $txt =~ s/$BC2(\s*[\r\n])/\%$1/g; $txt =~ s/$BC2//g;
    $txt = encode($encname[$oenc], $txt);
  }
  # step 4 : apply external filters
  if (@ext) { $txt = ext_filter($txt, \@ext); }
  return $txt;
}

sub judge_encode {
  my ($txt) = @_;
  my ($sc, $sh, $sb, $e, $s, $os, $oe, $t, @v);
  if ($txt =~ /^\xef\xbb\xbf/) { return UTF8; }
  if ($txt =~ /\x1b\x24[\x40\x42]/) { return JIS; }
  if ($txt !~ /[\x80-\xff]/) { return BYTE; }
  $os = 0; $oe = BYTE;
  foreach $e (UTF8, EUC, SJIS) {
    for (@v = (), $sb = 0, $t = $txt; ; ) {
      push(@v, decode($encname[$e], $t, Encode::FB_QUIET));
      if ($t eq '') { last; }
      $t = substr($t, 1); ++$sb;
    }
    $t = join('', @v);
    $t =~ s/[\x{FF61}-\x{FF9F}]//g; $sc = length($t);
    $t =~ s/[^\x{3041}-\x{3093}]//g; $sh = length($t);
    $s = $sc + $sh * 4 - $sb * 10;
    #alert("$e = $s ($sc,$sh,$sb)");
    if ($s >= $os) { $os = $s; $oe = $e; }
  }
  return $oe;
}

sub ext_filter {
  my ($txt, $ext) = @_; local ($/);
  my ($hin, $hout, $ifn, $ofn, @v, $cmd);
  $ifn = "${tempbase}_ti.tex"; $ofn = "${tempbase}_to.tex";
  @v = @$ext; $v[0] .= " < $ifn"; $v[$#v] .= " > $ofn";
  foreach (@v) {
    if (m/^((\S+)\.(pl|perl))(\s|$)/ && !-x $1)
    { $_ = "perl -S $_"; }
  }
  $cmd = join(" | ", @v);
  L1: {
    open($hin, '>', $ifn) or last L1;
    print $hin ($txt); close($hin);
    (system($cmd) == 0) or last L1;
    open($hout, '<', $ofn) or last L1;
    $txt = <$hout>; close($hout);
    unlink($ifn, $ofn);
    return $txt;
  }
  error("failed in processing external filters");
}

# Here shiftjisx0213 strings are decoded via eucjisx0213. Note
# that Encode::decode('eucjp') can handle JISX0213 (and 0212)
# whereas Encode::decode('shiftjis') cannot.

# $euchb[N] is high byte of euc-jisx0213 strings corresponding to
# plane 2 row N+1 characters.
my @euchb = (
  0xa1, 0xa8, 0xa3, 0xa4, 0xa5, 0xac, 0xad, 0xae,
  0xaf, 0xee .. 0xfe
);
## sjisx_to_eucx($bstr)
# Convert a shiftjisx0213 encoded string $bstr to eucjisx0213.
sub sjisx_to_eucx {
  my ($t) = @_; my ($h, $l, $s);
  ($h, $l) = unpack("CC", $t);
  $l += ($l >= 128) ? 96 : 97;
  $h = ($h - (($h >= 224) ? 193 : 129)) * 2 + 161;
  if ($l >= 255) { $l -= 94; ++$h; }
  if ($h >= 255) { $s = 1; $h = $euchb[$h - 255]; }
  $t = pack("C*", ($s) ? (143) : (), $h, $l);
  return $t;
}

## make_xcode_table($enc)
# Make table %xcode for decoding JIS-composite characters.
sub make_xcode_table {
  my ($enc) = @_; my ($k, $e, $s);
  $s = ($enc == SJIS) ? 1 : ($enc == EUC) ? 2 : return;
  foreach $k (keys %cchrgen) {
    foreach $e (@{$cchrgen{$k}}) {
      $xcode{pack('n', $e->[$s])} = chr($e->[3]) . chr($e->[4]);
    }
  }
}

## decode_ex($enc, $bstr)
# Decodes nonstandard characters (including JISX0213 chars).
sub decode_ex {
  my ($enc, $str) = @_; my ($t);
  if ($enc == SJIS) {
    $t = decode($encname[EUC], sjisx_to_eucx($str));
    if ($t ne "\x{FFFD}") { return $t; }
  }
  if (%xcode) {
    if (defined($t = $xcode{$str})) { return $t; }
  }
  return;
}

sub make_conv_table {
  my ($j, $k, $t, $u, $swu, $pfx, @v, @us, @ns);
  %dict = ($BC1, '', $BC2, '');
  foreach $k (0 .. $#conv) {
    ($conv[$k]) or next;
    @us = @ns = (); $swu = ($conv[$k] eq 'u'); undef $pfx;
    if (defined($t = $range[$k])) {
      for (@v = @$t; @v; ) {
        ($t, $u) = splice(@v, 0, 2);
        push(@us, map { chr($_) } ($t .. $u));
      }
      if (defined($t = $namegen[$k])) { ($pfx, @ns) = @$t; }
    } elsif (defined($t = $cchrgen{$k})) {
      $pfx = "ZTS";
      foreach $u (@$t) {
        push(@us, chr($u->[3]) . chr($u->[4]));
        push(@ns, $u->[0]);
      }
    }
    ($swu || @ns) or error("*INTERNAL10*");
    foreach $j (0 .. $#us) {
      $dict{$us[$j]} = ($swu || !defined $ns[$j]) ? 
        format_utf8($us[$j]) :
        ("\\" . $pfx . $ns[$j] . $BC1);
    }
  }
  @v = sort { $a cmp $b } (keys %dict);
  $t = join('|', grep { length($_) > 1 } (@v));
  $u = join('', grep { length($_) == 1 } (@v));
  $rxtarget = qr/([$u]|$t)/;
}

sub make_convaj_table {
  my ($uc, $u, @v);
  foreach $uc (keys %ucs2aj) {
    $dictaj{chr($uc)} = sprintf("\\AJ{%d}$BC2", $ucs2aj{$uc});
  }
  @v = sort { $a cmp $b } (keys %dictaj); $u = join('', @v);
  $rxsip = qr/([$u])/;
}

sub format_utf8 {
  my ($txt) = @_;
  if (!$swuseux) { return texesc(encode($encname[UTF8], $txt)); }
  $txt  = join('', map { sprintf("\\Ux{%04X}$BC2", ord($_)) }
                       (split(m//, $txt)));
  return $txt;
}

# texesc($bstr)
# Turns a binary string into tex-escaped (^^ab) form.
sub texesc {
  return join('', map { sprintf("^^%02x", ord($_)) }
                      (split(//, $_[0])));
}

## texwarn($bstr)
# Turns each byte in $bstr into \pxflWarn.
sub texwarn {
  return join('', map { sprintf("\\pxflWarn{%02X}", ord($_)) }
                      (split(//, $_[0])));
}

####------------------------------------ 'end'

sub proc_end {
  my ($no); $no = shift(@ARGV);
  foreach (0 .. $no) { unlink("${tempbase}_$_.tex"); }
  close($hanswer); unlink($ansfile); exit;
}

####------------------------------------ 'clean'

sub proc_clean {
  my ($t, $rx, @v);
  $rx = qr/^\Q$tempbase\E\d+(\.out|_(\d+|ti|to)\.tex)/;
  @v = grep { /$rx/ } (glob("${tempbase}*.*"));
  foreach $t (@v) {
    (unlink($t)) or next;
    alert("temporary file removed: $t");
  }
}

####------------------------------------

sub manual_main {
  my ($par) = @_; my ($t); local ($_, $/);
  $t = <>; print(convert($t, $par));
}

sub read_option {
  my ($par);
  if (!@ARGV) {
    show_usage();
  } elsif ($ARGV[0] =~ m/^\::(.*)/) { # called from TeX
    $tempbase = $1; $ansfile = "$tempbase.out";
    shift(@ARGV); $mode = shift(@ARGV);
    open($hanswer, '>', $ansfile)
      or error("cannot open output file: $ansfile");
  } elsif ($ARGV[0] =~ m/^\+(.*)/) {
    $par = $1; shift(@ARGV);
    if ($par eq 'clean') {
      if (@ARGV) { $tempbase = shift(@ARGV); }
      proc_clean();
    } else { manual_main($par); }
  } else { show_usage(); }
}

sub show_usage {
  my ($t); $t = join(' ', sort(keys %partable));
  print(<<"END");
This is $prog_name v$version <$mod_date> by 'ZR'
Usage: $prog_name +<option>,...     (filter)
       $prog_name +clean [<prefix>]
Available options:
$t
END
}

sub uni_dump {
  my ($t, $n) = @_;
  if (!defined $n) { $n = 40; }
  $t = substr($t, 0, $n);
  $t = join(',', map { sprintf("%X", ord($_)) } (split(//, $t)));
  if (length($t) >= $n - 2) { $t = substr($t, 0, $n - 2) . ".."; }
  return $t;
}

sub finish {
  print $hanswer ($_[0], "\n"); exit;
}

sub alert {
  print STDERR (join(": ", $prog_name, "warning", @_), "\n");
}

sub error {
  print STDERR (join(": ", $prog_name, @_), "\n");
  if ($hanswer) { finish("*NG"); } else { exit; }
}

#### go to main
main();
# EOF
