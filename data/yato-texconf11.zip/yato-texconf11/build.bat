@echo off
setlocal
set target=yato-texconf11
xelatex -no-pdf %target%.tex
xelatex %target%.tex
for %%a in (aux log nav out snm toc xdv) do (
del %target%.%%a
)
endlocal
:exit
