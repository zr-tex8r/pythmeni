#!/usr/bin/perl
# gen_vf.pl :
#
use strict;
use Data::Dump 'dump';
BEGIN { $_ = $0; s|^(.*)/.*$|$1|; unshift(@INC, $_); }
use ZRTeXtor ':all';
my $prog_name = "gen_vf";
my $version = "1.00";

# globals
our (%u_cmap, %u_jis);
require "toucs.pl";
my ($list_file, $op_verb);
my (%vfdata, @tfmdata, %outfile);

# main procedure

sub main
{
  my ($t); local ($_);
  read_options();
  if (defined $list_file) {
    $t = read_whole_file($list_file) or error();
    foreach (split(m/\n/, $t)) {
      ($t = $_) =~ s/^\s+//; $t =~ s/\#.*//;
      ($t =~ /^\w/) or next;
      process(split(m/\s+/, $t));
    }
  } else {
    process(@ARGV);
  }
  show_info("Writing files...");
  write_out();
  show_info("Done.");
}

#### subprocedures

my %mode_sym = (
  jis  => [ 'jis',  '',       0 ],
  ucs  => [ 'ucs',  'p',      1 ],
  ucsc => [ 'ucs',  'm',      0 ],
  aj1  => [ 'cmap', 'Japan1', 1 ],
  ak1  => [ 'cmap', 'Korea1', 0 ],
  ag1  => [ 'cmap', 'GB1',    0 ],
  ac1  => [ 'cmap', 'CNS1',   0 ],
);
my %uwidth;
foreach (0xff61..0xffdc, 0xffe8..0xffee)
{ $uwidth{$_} = 1; }

sub process {
  my ($njfm, $mod, $ntfm) = @_;
  my ($t, $k, $si, $swpr, $ms, $tf, $vf, $plc, $sid, %fid, @cnks);
  show_info("Processing for '$njfm'...");
  # make vf
  shortinfo("<vf>");
  (defined($ms = $mode_sym{lc($mod)}))
    or error("invalid mode: $mod");
  if (!defined $ntfm) { $ntfm = "$njfm-u"; }
  $vf = get_vf(@$ms); ($plc, $sid) = @$vf;
  push(@cnks, <<"END");
(VTITLE )
(DESIGNSIZE R 10.0)
END
  foreach (0 .. $#$sid) { $fid{$sid->[$_]} = $_; }
  foreach $k (0 .. $#$sid) {
    $tf = sprintf("%s%02x", $ntfm, $sid->[$k]);
    push(@cnks, <<"END");
(MAPFONT D $k
   (FONTNAME $tf)
   (FONTDSIZE R 10.0)
   )
END
  }
  $t = pl_parse(join('', @cnks)) or error();
  push(@$t, @$plc);
  $vf = vf_form($t) or error();
  write_file_buf("$njfm.vf", $vf);
  # make tfm
  $swpr = $ms->[2];
  foreach $si (@$sid) {
    $t = sprintf("%02x", $si); shortinfo("<$t>");
    $k = ($swpr) ? $si : 256;
    write_file_buf("$ntfm$t.tfm", get_tfm($k));
  }
  shortinfo("ok\n");
}

sub get_vf {
  my ($mod, $var, $swpr) = @_;
  my ($t, $uc, $c, @ar, %hs, @cnks, $tc, $tw, $fi, $fc);
  my (@sid, @ucs, %fid, $vf);
  if (defined($vf = $vfdata{"$mod/$var"})){ return $vf; }
  #
  if ($mod eq 'jis') {
    foreach $c (keys %u_jis) { $ucs[$c] = $u_jis{$c}; }
  } elsif ($mod eq 'ucs') {
    @ucs = (0 .. 0xffff);
  } elsif ($mod eq 'cmap') {
    @ucs = @{$u_cmap{$var}};
  }
  foreach $c (@ucs) { $hs{$c >> 8} = 1; }
  @sid = sort { $a <=> $b } (keys %hs);
  foreach (0 .. $#sid) { $fid{$sid[$_]} = $_; }
  foreach $c (0 .. 0xffff) {
    (($uc = $ucs[$c]) > 0) or next;
    $tc = sprintf("%04X", $c);
    $tw = ($swpr && $uwidth{$uc}) ? "0.5" : "1.0";
    $fi = $fid{$uc >> 8}; $fc = $uc & 255;
    push(@cnks, <<"END");
(CHARACTER H $tc
   (CHARWD R $tw)
   (MAP
      (SELECTFONT D $fi)
      (SETCHAR D $fc)
      )
   )
END
  }
  $t = pl_parse(join('', @cnks)) or error();
  # 
  $vfdata{"$mod/$var"} = $vf = [$t, \@sid];
  return $vf;
}

sub get_tfm {
  my ($si) = @_; my (@w, @cnks);
  my ($sw, $t, $u, $c, $tw, $tc);
  if (defined $tfmdata[$si]) { return $tfmdata[$si]; }
  if ($si < 256) {
    if (!defined $tfmdata[256]) { get_tfm(256); }
    foreach $c (0 .. 255) {
      if (($w[$c] = $uwidth{$si << 8 | $c})) { $sw = 1; }
    }
    if (!$sw) {
      $tfmdata[$si] = $t = $tfmdata[256];
      return $t;
    }
  }
  $tc = ($si == 256) ? "T0" : sprintf("%02X", $si);
  @cnks = (<<"END");
(FAMILY GENERIC)
(CODINGSCHEME UNICODE-$tc)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.0)
   (SHRINK R 0.0)
   (XHEIGHT R 1.0)
   (QUAD R 1.0)
   (EXTRASPACE R 0.0)
   )
END
  foreach $c (0 .. 255) {
    $tw = ($w[$c]) ? "0.5" : "1.0";
    push(@cnks, <<"END");
(CHARACTER D $c
   (CHARWD R $tw)
   (CHARHT R 0.9)
   (CHARDP R 0.1)
   )
END
  }
  $t = join('', @cnks); $t = x_pltotf($t) or error();
  $tfmdata[$si] = $t;
  return $t;
}

sub write_file_buf {
  $outfile{$_[0]} = $_[1];
}

sub write_out {
  my ($f);
  foreach $f (keys %outfile) {
    write_whole_file($f, $outfile{$f}, 1) or error();
  }
}

sub read_options
{
  my ($opt);
  if (!@ARGV) { show_usage(); }
  $op_verb = 0;
  while (($opt = $ARGV[0]) =~ /^-/) {
    shift(@ARGV);
    if ($opt eq '-h' || $opt eq '--help') {
      show_usage();
    } elsif ($opt eq '-v' || $opt eq '--verbose') {
      $op_verb = 1;
    } else {
      error("invalid option: $opt");
    }
  }
  if ($#ARGV == 0) { $list_file = shift(@ARGV); }
  elsif ($#ARGV > 2) { error("wrong number of arguments"); }
}

sub show_usage {
  print <<"END";
Usage: $prog_name <jfm_file> <mode> [<tfm_base>]
       $prog_name <list_file>
END
  exit;
}

sub shortinfo {
  if ($op_verb) { print STDERR (join('', @_)); }
}

sub show_info {
  print STDERR (join(": ", $prog_name, @_), "\n");
}
sub alert {
  show_info("warning", @_);
}
sub error
{
  if (!@_) { push(@_, textool_error()); }
  show_info(@_); exit;
}

#### go to main
main();
# EOF
